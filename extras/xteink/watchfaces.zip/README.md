# Watchfaces for Xteink X4 Pro

This pack contains 34 native Xtensa watchfaces. For phone-side JavaScript, send the entire PBW through CoreApp’s developer connection. USB installation loads the watch binary and its resources. See the Xteink section of the [PebbleOS README](https://github.com/ericmigi/PebbleOS/blob/codex/xteink-combined/README.md) for the bulk commands.

WATCHFACES.csv lists the authors’ upstream projects, original UUIDs and layouts. The corresponding ported source is in watchface-sources.zip in the same release. Live Space Missions accepts your personal N2YO key in its settings for Tiangong tracking. Other weather and map integrations use the permissions and providers that you choose in CoreApp.
