// Send phone location to the watch so it can compute real sun shadows.
function sendLocation(pos) {
  Pebble.sendAppMessage({
    LAT: Math.round(pos.coords.latitude * 100),
    LON: Math.round(pos.coords.longitude * 100),
  });
}

Pebble.addEventListener('ready', function() {
  navigator.geolocation.getCurrentPosition(sendLocation, function() {}, {
    enableHighAccuracy: false,
    timeout: 15000,
    maximumAge: 6 * 60 * 60 * 1000,
  });
});
