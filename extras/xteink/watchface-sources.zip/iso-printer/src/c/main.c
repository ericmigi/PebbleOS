// Iso Printer — isometric 3D printer watchface for emery (Pebble Time 2) and
// gabbro (round 260x260). The printer reprints all digits every minute:
// shredder swallows the old ones at :46, all digits print together layer by
// layer (one nozzle sweep per layer, bottom-up), finishing at the minute flip.
//
// Geometry is in "q" units = quarter-voxels (1 font cell = 2 voxels = 8 q).
// Isometric projection: sx = (x-y)*SVN/256, sy = (x+y)*SVN/512 - z*HZN/256.

#include <pebble.h>
#include "message_keys.auto.h"

// Demo/capture aid: shift the wall clock by a whole number of minutes so a
// chosen time can be replayed. Must stay a multiple of 60 so real minute
// ticks stay aligned with the fake minute. 0 in production.
#define FAKE_OFFSET 0
static time_t now_fx(void) { return time(NULL) + FAKE_OFFSET; }

// ---- projection scale per platform (SVN: px per q * 256, HZN: z px per q * 256)
#if defined(PBL_PLATFORM_GABBRO)
  #define SVN 230
  #define HZN 288
#else
  #define SVN 205
  #define HZN 256
#endif

// ---- world geometry (q units) ----
#define GH_VOX    10          // glyph height in 4q cells (mask resolution)
#define LAYERS    20          // print layers; each brick is 2q tall
#define BED_H     8
#define DIGIT_Y   16
#define DEPTH     8
#define FRM_X0    (-32)
#define FRM_X1    200
// bed island: 17 voxels deep, symmetric around the digit slab (center y=20)
#define BED_X0    (-40)
#define BED_X1    208
#define BED_Y0    (-14)
#define BED_Y1    54
// (legacy fixed-height beam removed; see COL_Z_TOP / s_beam_z)
#define TEXT_X0   16
#define TEXT_X1   160

// animation window (all times ms before the minute flip)
#define ANIM_LEAD_MS   6000    // animation starts :54
#define SHRED_MS       2000
#define PRINT_TOTAL_MS 3600    // print runs until 400ms before flip
#define PRINT_MS       3200
#define FRAME_MS       40

typedef struct { GColor top, left, right, line; } Shades;

static Window *s_window;
static Layer *s_layer;
static GPoint s_quad_pts[4];
static GPath s_quad = { .num_points = 4, .points = s_quad_pts };

static int s_ox, s_oy;

// display state
static uint8_t s_digits[4];      // digits being shown/printed
static uint8_t s_old_digits[4];  // digits being shredded
typedef enum { PHASE_STATIC, PHASE_SHRED, PHASE_PRINT } Phase;
static Phase s_phase = PHASE_STATIC;
static int s_shred_off;      // q the old digits have sunk
static int s_layers_done;    // fully printed 2q layers, 0..LAYERS
static int s_head_x;         // q, carriage position
static int s_head_dir;
static bool s_frontier_on;      // a layer is actively being deposited
static bool s_sweep_right;
static int s_pass;              // depth pass within the layer: 0 back, 1 front

// precomputed toolpath: one entry per brick, in true print order
#define COLS_N 36               // 4q brick columns across the text (x 16..160)
#define MAX_STEPS (LAYERS * 2 * COLS_N)
static uint16_t s_order[LAYERS][2][COLS_N];  // brick -> step index (0xFFFF: none)
static uint8_t s_path_col[MAX_STEPS];        // step -> column
static uint8_t s_path_lp[MAX_STEPS];         // step -> layer*2 + pass
static int s_nsteps, s_step_ms, s_step, s_cur_layer;
static int s_elapsed;           // monotonic ms since the cycle started
static bool s_item_changed[5];  // items being reprinted this minute

static bool deposited(int ci, int layer, int pass) {
  if (ci < 0 || ci >= COLS_N) return false;
  uint16_t o = s_order[layer][pass][ci];
  return o != 0xFFFF && (int)o < s_step;
}

// has the nozzle already passed x on the current sweep?
static bool frontier_passed(int xq) {
  int hx = s_head_x + 5;  // hot end center (nozzle at tx+3..tx+8)
  return s_sweep_right ? (xq <= hx) : (xq >= hx);
}
static time_t s_flip_epoch;  // epoch second of the upcoming minute flip
static AppTimer *s_anim_timer;
static AppTimer *s_start_timer;

// ---- palette (RGB222 levels) ----
static Shades SH_BED, SH_FRAME, SH_SUPPORT, SH_CARRIAGE, SH_ACCENT, SH_SLOT;
static Shades SH_DIGIT[4], SH_COLON;
static GColor C_SKY, C_BEDTOP, C_GRID, C_SHADOW, C_OBJSHADOW;

// ---- solar position (BACK of bed = north = -y, east = -x) ----
#define PERSIST_LAT 1
#define PERSIST_LON 2
static int32_t s_lat100 = 3777;    // degrees*100; default San Francisco
static int32_t s_lon100 = -12242;  // east positive
static int s_shx, s_shy;           // ground shadow offset per q of height, 8.8 fixed
static bool s_sun_up;

#define TA(a) ((int32_t)(a) & 0xFFFF)  // wrap any angle into trig range

// NOAA solar position, fixed point. Angles in Pebble trig units
// (TRIG_MAX_ANGLE = 65536 per turn); series coefficients pre-scaled.
static void compute_sun(void) {
  time_t now = now_fx();
  struct tm *g = gmtime(&now);
  int32_t min_utc = g->tm_hour * 60 + g->tm_min;
  int64_t day_min = (int64_t)g->tm_yday * 1440 + min_utc - 720;
  int32_t ga = (int32_t)((day_min << 16) / (365 * 1440));  // fractional year
  int32_t cg = cos_lookup(TA(ga)),     sg = sin_lookup(TA(ga));
  int32_t cg2 = cos_lookup(TA(2*ga)),  sg2 = sin_lookup(TA(2*ga));
  int32_t cg3 = cos_lookup(TA(3*ga)),  sg3 = sin_lookup(TA(3*ga));
  // declination (trig units; rad coeffs * 65536/2pi)
  int32_t decl = 72 - ((4171*cg)>>16) + ((733*sg)>>16) - ((70*cg2)>>16)
               + ((9*sg2)>>16) - ((28*cg3)>>16) + ((15*sg3)>>16);
  // equation of time (centi-minutes; coeffs * 229.18 * 100)
  int32_t eq = 2 + ((43*cg)>>16) - ((735*sg)>>16) - ((335*cg2)>>16) - ((936*sg2)>>16);
  // true solar time -> hour angle
  int32_t tst = min_utc * 100 + (g->tm_sec * 5) / 3 + eq + s_lon100 * 4;
  int32_t h100 = tst / 4 - 18000;  // degrees*100 from solar noon
  int32_t ha  = (int32_t)(((int64_t)h100 << 16) / 36000);
  int32_t phi = (int32_t)(((int64_t)s_lat100 << 16) / 36000);
  int32_t sd = sin_lookup(TA(decl)), cd = cos_lookup(TA(decl));
  int32_t sp = sin_lookup(TA(phi)),  cp = cos_lookup(TA(phi));
  int32_t sh = sin_lookup(TA(ha)),   ch = cos_lookup(TA(ha));
  int32_t cdch = (int32_t)(((int64_t)cd * ch) >> 16);
  int32_t E = -(int32_t)(((int64_t)cd * sh) >> 16);                  // sun east
  int32_t N = (int32_t)(((int64_t)cp*sd - (int64_t)sp*cdch) >> 16);  // sun north
  int32_t U = (int32_t)(((int64_t)sp*sd + (int64_t)cp*cdch) >> 16);  // sun up
  s_sun_up = U > 1500;  // ~1.3 degrees above horizon
  if (s_sun_up) {
    // shadow points opposite the sun; north = -y and east = -x here
    int32_t sx = (int32_t)(((int64_t)E << 8) / U);
    int32_t sy = (int32_t)(((int64_t)N << 8) / U);
    if (sx > 768) sx = 768;      // clamp shadow length to 3x height
    if (sx < -768) sx = -768;
    if (sy > 768) sy = 768;
    if (sy < -768) sy = -768;
    s_shx = sx;
    s_shy = sy;
  }
}

static GColor col_lv(int r, int g, int b) {
  if (r < 0) r = 0;
  if (r > 3) r = 3;
  if (g < 0) g = 0;
  if (g > 3) g = 3;
  if (b < 0) b = 0;
  if (b > 3) b = 3;
  return GColorFromRGB(r * 85, g * 85, b * 85);
}

static Shades make_shades(int r, int g, int b) {
  return (Shades) {
    .top   = col_lv(r + 1, g + 1, b + 1),
    .left  = col_lv(r, g, b),
    .right = col_lv(r - 1, g - 1, b - 1),
    .line  = col_lv(r - 1, g - 1, b - 1),
  };
}

// ---- 3x5 font -> per-voxel-column bitmasks (bit z set = voxel at height z) ----
static const char *FONT[10][5] = {
  {"111","101","101","101","111"}, {"010","110","010","010","111"},
  {"111","001","111","100","111"}, {"111","001","011","001","111"},
  {"101","101","111","001","001"}, {"111","100","111","001","111"},
  {"111","100","111","101","111"}, {"111","001","001","010","010"},
  {"111","101","111","101","111"}, {"111","101","111","001","111"},
};
static uint16_t s_glyph_cols[10][6];
#define COLON_MASK 0x00CC   // voxels at z 2,3,6,7

// items: 4 digits + colon, x offsets in q
static const int ITEM_X[5] = { 16, 48, 88, 104, 136 };  // slots 0,1,colon,2,3
#define ITEM_IS_COLON(i) ((i) == 2)
#define ITEM_DIGIT_SLOT(i) ((i) < 2 ? (i) : (i) - 1)

static void build_font(void) {
  for (int d = 0; d < 10; d++) {
    for (int c = 0; c < 6; c++) s_glyph_cols[d][c] = 0;
    for (int r = 0; r < 5; r++) {
      for (int c = 0; c < 3; c++) {
        if (FONT[d][r][c] == '1') {
          int zbase = (4 - r) * 2;
          uint16_t bits = (uint16_t)(0x3 << zbase);
          s_glyph_cols[d][c * 2]     |= bits;
          s_glyph_cols[d][c * 2 + 1] |= bits;
        }
      }
    }
  }
}

// ---- projection ----
static GPoint pt(int x, int y, int z) {
  return GPoint(s_ox + (((x - y) * SVN) >> 8),
                s_oy + (((x + y) * SVN) >> 9) - ((z * HZN) >> 8));
}

static void fill_quad(GContext *ctx, GPoint a, GPoint b, GPoint c, GPoint d,
                      GColor fill, const GColor *line) {
  s_quad_pts[0] = a; s_quad_pts[1] = b; s_quad_pts[2] = c; s_quad_pts[3] = d;
  graphics_context_set_fill_color(ctx, fill);
  gpath_draw_filled(ctx, &s_quad);
  if (line) {
    graphics_context_set_stroke_color(ctx, *line);
    gpath_draw_outline(ctx, &s_quad);
  }
}

static void draw_box(GContext *ctx, int x, int y, int z, int dx, int dy, int dz,
                     const Shades *sh, bool outline) {
  int z1 = z + dz;
  const GColor *line = outline ? &sh->line : NULL;
  // right (+x) face
  fill_quad(ctx, pt(x+dx,y,z1), pt(x+dx,y+dy,z1), pt(x+dx,y+dy,z), pt(x+dx,y,z),
            sh->right, line);
  // left (+y) face
  fill_quad(ctx, pt(x,y+dy,z1), pt(x+dx,y+dy,z1), pt(x+dx,y+dy,z), pt(x,y+dy,z),
            sh->left, line);
  // top
  fill_quad(ctx, pt(x,y,z1), pt(x+dx,y,z1), pt(x+dx,y+dy,z1), pt(x,y+dy,z1),
            sh->top, line);
}

// ---- solar object shadows, cast onto the bed plane ----
// h = height above bed top in q. Shadow offsets clamp at the bed edges.
static GPoint spt(int x, int y, int h) {
  int wx = x + ((s_shx * h) >> 8);
  int wy = y + ((s_shy * h) >> 8);
  if (wx < BED_X0 + 2) wx = BED_X0 + 2;
  if (wx > BED_X1 - 2) wx = BED_X1 - 2;
  if (wy < BED_Y0 + 2) wy = BED_Y0 + 2;
  if (wy > BED_Y1 - 2) wy = BED_Y1 - 2;
  return pt(wx, wy, BED_H);
}

// shadow of a box footprint (x,y,dx,dy) spanning heights h0..h1:
// two end caps + the two sun-silhouette edge sweeps = exact swept hull
static void draw_shadow_rect(GContext *ctx, int x, int y, int dx, int dy,
                             int h0, int h1) {
  if (!s_sun_up || h1 <= h0) return;
  fill_quad(ctx, spt(x,y,h0), spt(x+dx,y,h0), spt(x+dx,y+dy,h0), spt(x,y+dy,h0),
            C_OBJSHADOW, NULL);
  fill_quad(ctx, spt(x,y,h1), spt(x+dx,y,h1), spt(x+dx,y+dy,h1), spt(x,y+dy,h1),
            C_OBJSHADOW, NULL);
  int xe = (s_shx >= 0) ? x + dx : x;
  fill_quad(ctx, spt(xe,y,h0), spt(xe,y+dy,h0), spt(xe,y+dy,h1), spt(xe,y,h1),
            C_OBJSHADOW, NULL);
  int ye = (s_shy >= 0) ? y + dy : y;
  fill_quad(ctx, spt(x,ye,h0), spt(x+dx,ye,h0), spt(x+dx,ye,h1), spt(x,ye,h1),
            C_OBJSHADOW, NULL);
}

// ---- scene pieces ----
static void draw_bed(GContext *ctx) {
  // drop shadow on the sky, offset down-right (floating island look)
  fill_quad(ctx, pt(BED_X0+3, BED_Y0+3, 0), pt(BED_X1+7, BED_Y0+3, 0),
            pt(BED_X1+7, BED_Y1+7, 0), pt(BED_X0+3, BED_Y1+7, 0),
            C_SHADOW, NULL);
  draw_box(ctx, BED_X0, BED_Y0, 0, BED_X1 - BED_X0, BED_Y1 - BED_Y0, BED_H,
           &SH_BED, false);
  // white build surface
  fill_quad(ctx, pt(BED_X0+2, BED_Y0+2, BED_H), pt(BED_X1-2, BED_Y0+2, BED_H),
            pt(BED_X1-2, BED_Y1-2, BED_H), pt(BED_X0+2, BED_Y1-2, BED_H),
            C_BEDTOP, NULL);
  graphics_context_set_stroke_color(ctx, C_GRID);
  for (int gx = BED_X0 + 8; gx < BED_X1; gx += 16) {
    graphics_draw_line(ctx, pt(gx, BED_Y0+2, BED_H), pt(gx, BED_Y1-2, BED_H));
  }
  for (int gy = BED_Y0 + 8; gy < BED_Y1 - 2; gy += 16) {
    graphics_draw_line(ctx, pt(BED_X0+2, gy, BED_H), pt(BED_X1-2, gy, BED_H));
  }
}

static void draw_slot(GContext *ctx) {
  // shredder mouths: only under the digits being replaced
  for (int i = 0; i < 5; i++) {
    if (!s_item_changed[i]) continue;
    int x0 = ITEM_X[i] - 4, x1 = ITEM_X[i] + 28;
    fill_quad(ctx, pt(x0, DIGIT_Y-4, BED_H), pt(x1, DIGIT_Y-4, BED_H),
              pt(x1, DIGIT_Y+DEPTH+4, BED_H), pt(x0, DIGIT_Y+DEPTH+4, BED_H),
              SH_SLOT.right, NULL);
    draw_box(ctx, x0, DIGIT_Y-4, BED_H, x1 - x0, 2, 2, &SH_SLOT, false);
    draw_box(ctx, x0, DIGIT_Y+DEPTH+2, BED_H, x1 - x0, 2, 2, &SH_SLOT, false);
  }
}

// Organic tree supports (Bambu tree-organic style): each overhang contact
// grows a branch that tapers from a thin tip to a thick base while leaning
// along a smoothstep S-curve toward the glyph's shared trunk line — branches
// from different contacts overlap there and read as one merged trunk with a
// flared foot on the bed. Branches steer around the model and rest on it
// when boxed in. grow_h = printed height in q so supports grow with the
// print; y/row = depth face for this pass (front and back rows).
static void draw_supports(GContext *ctx, int item_x, const uint16_t *cols, int ncols,
                          int grow_h, int sink, int y, int row) {
  int tx = item_x + (ncols == 2 ? 4 : 12);  // shared trunk line: item center
  for (int cell = 0; cell < ncols / 2; cell++) {
    uint16_t m = cols[cell * 2];
    for (int zb = 1; zb < GH_VOX; zb++) {
      if (!(m & (1 << zb)) || (m & (1 << (zb - 1)))) continue;  // not overhang bottom
      int tip_x = item_x + cell * 8 + 3;
      // walk down first (S-curve + collision), then draw bottom-up
      int path_bx[GH_VOX];
      int nseg = 0;
      bool on_bed = false;
      for (int z = zb - 1; z >= 0; z--) {
        int drop = zb - z;                     // 1..zb
        int e = 256 * drop / zb;               // 0..256 linear
        e = (int)(((int32_t)e * e * (768 - 2 * e)) >> 16);  // smoothstep
        int bx = tip_x + (((tx - tip_x) * e) >> 8);
        int cc = (bx - item_x) >> 2;
        if (cc >= 0 && cc < ncols && (cols[cc] & (1 << z))) {
          bx = nseg ? path_bx[nseg - 1] : tip_x;  // curve blocked: go straight
          cc = (bx - item_x) >> 2;
          if (cc >= 0 && cc < ncols && (cols[cc] & (1 << z))) break;  // rest on model
        }
        path_bx[nseg++] = bx;
        if (z == 0) on_bed = true;
      }
      for (int i = nseg - 1; i >= 0; i--) {
        int z = zb - 1 - i;
        int seg_bot = z * 4 - sink;
        int seg_top = seg_bot + 4;
        if (seg_top <= 0) continue;
        int st = seg_top < grow_h ? seg_top : grow_h;
        if (st < seg_top && s_frontier_on &&
            (s_pass < row || (s_pass == row && !frontier_passed(path_bx[i]))))
          st -= 2;  // this brick not deposited yet
        if (st <= seg_bot) continue;
        seg_top = st;
        if (seg_bot < 0) seg_bot = 0;
        int w = 1 + 2 * (zb - z) / zb;         // taper: 1q tip -> 3q base
        if (on_bed && z == 0 && sink == 0) {   // flared foot
          draw_box(ctx, path_bx[i] - w / 2 - 2, y - 1, BED_H, w + 4, 4, 1,
                   &SH_SUPPORT, false);
          draw_box(ctx, path_bx[i] - w / 2 - 1, y - 1, BED_H + 1, w + 2, 3, 1,
                   &SH_SUPPORT, false);
        }
        draw_box(ctx, path_bx[i] - w / 2, y, BED_H + seg_bot,
                 w, 2, seg_top - seg_bot, &SH_SUPPORT, false);
      }
      // contact tip pad touching the supported run
      int tip_top = zb * 4 - sink;
      if (tip_top > 0 && tip_top - 2 < grow_h && nseg > 0) {
        draw_box(ctx, item_x + cell * 8 + 1, y, BED_H + tip_top - 2,
                 6, 2, 2, &SH_SUPPORT, false);
      }
    }
  }
}

static void draw_item_voxels(GContext *ctx, int item_x, const uint16_t *cols, int ncols,
                             const Shades *sh, int layers, int sink) {
  int hq = layers * 2;  // completed print height in q
  for (int c = 0; c < ncols; c++) {
    uint16_t m = cols[c];
    int x = item_x + c * 4;
    for (int zb = 0; zb < GH_VOX; zb++) {
      if (!(m & (1 << zb)) || (zb > 0 && (m & (1 << (zb - 1))))) continue;
      int zt = zb;
      while (zt + 1 < GH_VOX && (m & (1 << (zt + 1)))) zt++;
      int bot = zb * 4, top = (zt + 1) * 4;
      int vb = bot > sink ? bot : sink;   // shredder clip (bottom)
      int vt = top < hq ? top : hq;       // completed-print clip (top)
      if (vt > vb) {
        draw_box(ctx, x, DIGIT_Y, BED_H + vb - sink, 4, DEPTH, vt - vb, sh, true);
        // brick grid: 2q layer lines on both faces, depth joint on top
        graphics_context_set_stroke_color(ctx, sh->line);
        for (int g = vb + ((vb & 1) ? 1 : 2); g < vt; g += 2) {
          int wz = BED_H + g - sink;
          graphics_draw_line(ctx, pt(x, DIGIT_Y + DEPTH, wz),
                             pt(x + 4, DIGIT_Y + DEPTH, wz));
          graphics_draw_line(ctx, pt(x + 4, DIGIT_Y, wz),
                             pt(x + 4, DIGIT_Y + DEPTH, wz));
        }
        graphics_draw_line(ctx, pt(x, DIGIT_Y + 4, BED_H + vt - sink),
                           pt(x + 4, DIGIT_Y + 4, BED_H + vt - sink));
        graphics_draw_line(ctx, pt(x + 4, DIGIT_Y + 4, BED_H + vt - sink),
                           pt(x + 4, DIGIT_Y + 4, BED_H + vb - sink));
      }
      // bricks on the layer being deposited: each one appears exactly when
      // its toolpath step has been extruded (back row pass 0, front pass 1)
      if (sink == 0 && s_frontier_on && hq >= bot && hq < top) {
        int ci = (x - TEXT_X0) / 4;
        int L = hq / 2;
        if (deposited(ci, L, 0)) {
          draw_box(ctx, x, DIGIT_Y, BED_H + hq, 4, 4, 2, sh, true);
        }
        if (deposited(ci, L, 1)) {
          draw_box(ctx, x, DIGIT_Y + 4, BED_H + hq, 4, 4, 2, sh, true);
        }
      }
    }
  }
}

static const uint16_t COLON_COLS[2] = { COLON_MASK, COLON_MASK };

static const uint16_t *item_cols(int i, const uint8_t *digits, int *ncols) {
  if (ITEM_IS_COLON(i)) {
    *ncols = 2;
    return COLON_COLS;
  }
  *ncols = 6;
  return s_glyph_cols[digits[ITEM_DIGIT_SLOT(i)]];
}

static void draw_text(GContext *ctx, const uint8_t *digits, int layers, int sink) {
  for (int i = 0; i < 5; i++) {
    int ncols;
    const uint16_t *cols = item_cols(i, digits, &ncols);
    const Shades *sh = ITEM_IS_COLON(i) ? &SH_COLON : &SH_DIGIT[ITEM_DIGIT_SLOT(i)];
    // only changed items shred and reprint; the rest stand complete
    int il = s_item_changed[i] ? layers : LAYERS;
    int isink = s_item_changed[i] ? sink : 0;
    int grow = il >= LAYERS ? 1000 : il * 2;
    draw_supports(ctx, ITEM_X[i], cols, ncols, grow, isink, DIGIT_Y - 2, 0);
    draw_item_voxels(ctx, ITEM_X[i], cols, ncols, sh, il, isink);
    draw_supports(ctx, ITEM_X[i], cols, ncols, grow, isink, DIGIT_Y + DEPTH, 1);
  }
}

// solar shadows of the text voxels (per glyph column run) onto the bed
static void draw_text_shadows(GContext *ctx, const uint8_t *digits, int layers, int sink) {
  if (!s_sun_up) return;
  for (int i = 0; i < 5; i++) {
    int ncols;
    const uint16_t *cols = item_cols(i, digits, &ncols);
    int il = s_item_changed[i] ? layers : LAYERS;
    int isink = s_item_changed[i] ? sink : 0;
    for (int cell = 0; cell < ncols / 2; cell++) {  // voxel col pairs share a mask
      uint16_t m = cols[cell * 2];
      for (int zb = 0; zb < GH_VOX; zb++) {
        if (!(m & (1 << zb)) || (zb > 0 && (m & (1 << (zb - 1))))) continue;
        int zt = zb;
        while (zt + 1 < GH_VOX && (m & (1 << (zt + 1)))) zt++;
        int h0 = zb * 4 - isink;
        int h1 = (zt + 1) * 4 - isink;
        if (h1 > il * 2) h1 = il * 2;
        if (h0 < 0) h0 = 0;
        if (h1 <= h0) continue;
        draw_shadow_rect(ctx, ITEM_X[i] + cell * 8, DIGIT_Y, 8, DEPTH, h0, h1);
      }
    }
  }
}

// Gantry: an X rail on the platform behind the print row; the whole Z tower
// slides along it (X axis). A short arm cantilevers forward over the print
// (Y axis) and climbs the tower (Z axis); the hot end weaves along the arm.
#define TOWER_PARK_X (FRM_X0 + 6)
#define TOWER_Y   (BED_Y0 + 4)
#define COL_Z_TOP 64            // top of the Z tower
#define BEAM_PARK_Z 54          // arm parked high when idle
#define RAIL_X0   (FRM_X0 - 2)
#define RAIL_X1   (TEXT_X1 + 24)
static int s_beam_z = BEAM_PARK_Z;

static int tower_x(void) {
  return s_phase == PHASE_PRINT ? s_head_x : TOWER_PARK_X;
}

// rail + tower: behind the print row, drawn before the text
static void draw_tower(GContext *ctx) {
  draw_box(ctx, RAIL_X0, TOWER_Y + 2, BED_H, RAIL_X1 - RAIL_X0, 8, 2,
           &SH_CARRIAGE, false);
  int tx = tower_x();
  draw_box(ctx, tx - 2, TOWER_Y - 2, BED_H + 2, 14, 18, 3, &SH_FRAME, false);
  draw_box(ctx, tx, TOWER_Y, BED_H + 5, 10, 14, COL_Z_TOP - BED_H - 5,
           &SH_FRAME, false);
  draw_box(ctx, tx - 1, TOWER_Y - 1, COL_Z_TOP, 12, 16, 3, &SH_FRAME, false);
}

// Y rail + build head: the rail is suspended from the tower and rides up
// and down it (Z); the head traverses along the rail (Y), drawn after text
static void draw_beam_and_head(GContext *ctx) {
  int tx = tower_x();
  int hy = DIGIT_Y - 4 + (s_phase == PHASE_PRINT ? 4 * s_pass : 0);
  draw_box(ctx, tx + 2, TOWER_Y + 4, s_beam_z, 8, (DIGIT_Y + DEPTH + 6) - (TOWER_Y + 4), 4, &SH_FRAME, false);
  draw_box(ctx, tx + 1, hy, s_beam_z - 3, 10, 8, 3, &SH_CARRIAGE, false);
  draw_box(ctx, tx + 3, hy + 3, s_beam_z - 6, 5, 5, 3, &SH_ACCENT, false);
}

static void draw_gantry_shadows(GContext *ctx) {
  if (!s_sun_up) return;
  int tx = tower_x();
  draw_shadow_rect(ctx, tx, TOWER_Y, 10, 14, 2, COL_Z_TOP - BED_H + 3);
  draw_shadow_rect(ctx, tx + 2, TOWER_Y + 4, 8,
                   (DIGIT_Y + DEPTH + 6) - (TOWER_Y + 4),
                   s_beam_z - BED_H, s_beam_z - BED_H + 4);
}

static void layer_update(Layer *layer, GContext *ctx) {
  GRect b = layer_get_bounds(layer);
  graphics_context_set_fill_color(ctx, C_SKY);
  graphics_fill_rect(ctx, b, 0, GCornerNone);
  graphics_context_set_stroke_width(ctx, 1);

  draw_bed(ctx);
  // solar shadows paint on the bed before anything stands on it
  draw_gantry_shadows(ctx);
  if (s_phase == PHASE_SHRED) {
    draw_text_shadows(ctx, s_old_digits, LAYERS, s_shred_off);
  } else if (s_phase == PHASE_PRINT) {
    draw_text_shadows(ctx, s_digits, s_layers_done, 0);
  } else {
    draw_text_shadows(ctx, s_digits, LAYERS, 0);
  }
  if (s_phase == PHASE_SHRED) draw_slot(ctx);

  draw_tower(ctx);

  if (s_phase == PHASE_SHRED) {
    draw_text(ctx, s_old_digits, LAYERS, s_shred_off);
  } else if (s_phase == PHASE_PRINT) {
    draw_text(ctx, s_digits, s_layers_done, 0);
  } else {
    draw_text(ctx, s_digits, LAYERS, 0);
  }

  draw_beam_and_head(ctx);
}

// ---- time / animation control ----
static void set_digits_from(struct tm *t, uint8_t *out) {
  int h = t->tm_hour;
  if (!clock_is_24h_style()) {
    h = h % 12;
    if (h == 0) h = 12;
  }
  out[0] = h / 10; out[1] = h % 10;
  out[2] = t->tm_min / 10; out[3] = t->tm_min % 10;
}

static void anim_timer_cb(void *data);
static void start_timer_cb(void *data);

static void schedule_anim_start(void) {
  time_t now = now_fx();
  int sec = now % 60;
  int delay_ms = (60 - (int)(ANIM_LEAD_MS / 1000) - sec) * 1000;
  if (s_start_timer) app_timer_cancel(s_start_timer);
  s_start_timer = NULL;
  if (delay_ms <= 0) return;  // opened mid-window; stay static until next minute
  if (battery_state_service_peek().charge_percent <= 20) return;  // save power
  s_start_timer = app_timer_register(delay_ms, start_timer_cb, NULL);
}

static int ms_to_flip(void) {
  time_t s;
  uint16_t ms;
  time_ms(&s, &ms);
  s += FAKE_OFFSET;
  return (int)(s_flip_epoch - s) * 1000 - ms;
}

static void build_path(void) {
  // only the digits that changed reprint; colon and unchanged digits stand
  uint16_t pres[COLS_N];
  memset(pres, 0, sizeof(pres));
  int ci_min = COLS_N, ci_max = -1;
  for (int i = 0; i < 5; i++) {
    if (!s_item_changed[i]) continue;
    int ncols;
    const uint16_t *cols = item_cols(i, s_digits, &ncols);
    for (int c = 0; c < ncols; c++) {
      int ci = (ITEM_X[i] + c * 4 - TEXT_X0) / 4;
      if (ci < 0 || ci >= COLS_N) continue;
      pres[ci] = cols[c];
      if (ci < ci_min) ci_min = ci;
      if (ci > ci_max) ci_max = ci;
    }
  }
  // columns of items that stay standing this cycle (head must hop them)
  uint16_t pres_stand[COLS_N];
  memset(pres_stand, 0, sizeof(pres_stand));
  for (int i = 0; i < 5; i++) {
    if (s_item_changed[i]) continue;
    int ncols;
    const uint16_t *cols = item_cols(i, s_digits, &ncols);
    for (int c = 0; c < ncols; c++) {
      int ci = (ITEM_X[i] + c * 4 - TEXT_X0) / 4;
      if (ci >= 0 && ci < COLS_N) pres_stand[ci] = cols[c];
    }
  }
  memset(s_order, 0xFF, sizeof(s_order));
  s_nsteps = 0;
  if (ci_max < 0) { s_step_ms = PRINT_MS; return; }
  // serpentine over the whole span: every column is a step so the head
  // travels through gaps instead of teleporting; bit 7 marks extrusion
  // (ponytail: travel is same-speed and same-height as extrusion — real
  // printers dash and z-hop, but one step is sub-frame here)
  for (int L = 0; L < LAYERS; L++) {
    int zc = L / 2;
    for (int p = 0; p < 2; p++) {
      int lp = L * 2 + p;
      int n = ci_max - ci_min + 1;
      for (int k = 0; k < n; k++) {
        int ci = (lp & 1) ? ci_max - k : ci_min + k;
        bool ext = (pres[ci] & (1 << zc)) != 0;
        if (ext) s_order[L][p][ci] = (uint16_t)s_nsteps;
        s_path_col[s_nsteps] = (uint8_t)ci;
        s_path_lp[s_nsteps] = (uint8_t)(lp | (ext ? 0x80 : 0));
        s_nsteps++;
      }
    }
  }
  // z-hop: any travel run crossing a standing digit lifts to the top for
  // the whole run so the head never drags through existing prints (bit 6)
  int k = 0;
  while (k < s_nsteps) {
    if (s_path_lp[k] & 0x80) { k++; continue; }
    int lp = s_path_lp[k] & 0x3F;
    int e = k;
    bool hit = false;
    while (e < s_nsteps && !(s_path_lp[e] & 0x80) &&
           (s_path_lp[e] & 0x3F) == lp) {
      if (pres_stand[s_path_col[e]]) hit = true;
      e++;
    }
    if (hit) {
      for (int j = k; j < e; j++) s_path_lp[j] |= 0x40;
    }
    k = e;
  }
  s_step_ms = s_nsteps > 0 ? PRINT_MS / s_nsteps : PRINT_MS;
  if (s_step_ms < 1) s_step_ms = 1;
}

static void start_timer_cb(void *data) {
  s_start_timer = NULL;
  if (s_anim_timer) { app_timer_cancel(s_anim_timer); s_anim_timer = NULL; }
  time_t now = now_fx();
  s_flip_epoch = now - (now % 60) + 60;
  time_t target = s_flip_epoch;
  struct tm *t = localtime(&target);
  memcpy(s_old_digits, s_digits, 4);
  set_digits_from(t, s_digits);
  for (int i = 0; i < 5; i++) {
    s_item_changed[i] = !ITEM_IS_COLON(i) &&
        s_old_digits[ITEM_DIGIT_SLOT(i)] != s_digits[ITEM_DIGIT_SLOT(i)];
  }
  build_path();
  s_phase = PHASE_SHRED;
  s_shred_off = 0;
  s_layers_done = 0;
  s_head_dir = 1;
  s_elapsed = 0;
  s_anim_timer = app_timer_register(FRAME_MS, anim_timer_cb, NULL);
}

static void anim_timer_cb(void *data) {
  s_anim_timer = NULL;
  int rem = ms_to_flip();
  // clock can be stepped backward by time sync mid-cycle; a printer only
  // goes up — clamp progress monotonic (hold position, never rewind)
  int el = ANIM_LEAD_MS - rem;
  if (el < s_elapsed) el = s_elapsed;
  s_elapsed = el;
  rem = ANIM_LEAD_MS - el;

  if (rem <= 400) {
    // done: glide the tower home, then rest (minute tick will confirm)
    s_layers_done = LAYERS;
    s_cur_layer = LAYERS;
    s_frontier_on = false;
    s_step = s_nsteps + 1;
    if (rem > 60 && s_nsteps > 0) {
      s_phase = PHASE_PRINT;  // keep following s_head_x while gliding
      int t = 400 - rem;
      int lx = TEXT_X0 + s_path_col[s_nsteps - 1] * 4 - 3;
      int lz = BED_H + LAYERS * 2 + 6;
      s_head_x = lx + (TOWER_PARK_X - lx) * t / 400;
      s_beam_z = lz + (BEAM_PARK_Z - lz) * t / 400;
      layer_mark_dirty(s_layer);
      s_anim_timer = app_timer_register(FRAME_MS, anim_timer_cb, NULL);
      return;
    }
    s_phase = PHASE_STATIC;
    s_beam_z = BEAM_PARK_Z;
    layer_mark_dirty(s_layer);
    return;
  }

  if (rem > ANIM_LEAD_MS - SHRED_MS) {
    // shredding: sink 48q over SHRED_MS; beam retreats along Y rails
    s_phase = PHASE_SHRED;
    int t = ANIM_LEAD_MS - rem;  // 0..SHRED_MS
    s_shred_off = 48 * t / SHRED_MS;
    s_beam_z = BEAM_PARK_Z;
    s_frontier_on = false;
  } else if (rem > PRINT_TOTAL_MS) {
    // pause: beam slides back to the print row over the empty bed
    s_phase = PHASE_PRINT;
    s_layers_done = 0;
    s_frontier_on = false;
    int t = (ANIM_LEAD_MS - SHRED_MS) - rem;  // 0..400
    // tower glides from park straight to the first brick of the toolpath
    int target = s_nsteps > 0 ? TEXT_X0 + s_path_col[0] * 4 - 3 : TOWER_PARK_X;
    s_head_x = TOWER_PARK_X + (target - TOWER_PARK_X) * t / 400;
    s_beam_z = BEAM_PARK_Z + ((BED_H + 6) - BEAM_PARK_Z) * t / 400;  // descend
  } else {
    s_phase = PHASE_PRINT;
    int t = PRINT_TOTAL_MS - rem;      // 0..PRINT_MS
    if (t > PRINT_MS) t = PRINT_MS;
    s_step = t / s_step_ms;
    if (s_step >= s_nsteps) {
      // toolpath done: everything deposited, park pose until the flip
      s_step = s_nsteps;
      s_layers_done = LAYERS;
      s_cur_layer = LAYERS;
      s_frontier_on = false;
      s_beam_z = BED_H + LAYERS * 2 + 6;
    } else {
      int fm = t % s_step_ms;
      uint8_t raw = s_path_lp[s_step];
      int lp = raw & 0x3F;
      s_cur_layer = lp / 2;
      s_pass = lp & 1;
      s_sweep_right = !(lp & 1);
      s_layers_done = s_cur_layer;   // layers below the current one are done
      s_frontier_on = true;
      // travel over a standing digit: hop to the top, else ride the layer
      s_beam_z = (raw & 0x40) ? BEAM_PARK_Z : BED_H + s_cur_layer * 2 + 6;
      // hot end sits exactly over the current toolpath column
      s_head_x = TEXT_X0 + s_path_col[s_step] * 4 - 3;
      if (fm >= s_step_ms / 2) s_step++;  // brick lands mid-dwell
    }
  }

  layer_mark_dirty(s_layer);
  s_anim_timer = app_timer_register(FRAME_MS, anim_timer_cb, NULL);
}

static void tick_handler(struct tm *tick_time, TimeUnits changed) {
  // clock-sync ticks arrive mid-minute; never let them kill a running print
  if (s_anim_timer && tick_time->tm_sec != 0) return;
  if (s_anim_timer) { app_timer_cancel(s_anim_timer); s_anim_timer = NULL; }
  time_t fx = now_fx();
  set_digits_from(localtime(&fx), s_digits);
  s_phase = PHASE_STATIC;
  s_layers_done = LAYERS;
  s_beam_z = BEAM_PARK_Z;
  s_frontier_on = false;
  compute_sun();
  layer_mark_dirty(s_layer);
  schedule_anim_start();
}

// ---- setup ----
static void compute_origin(GRect bounds) {
  // center the "core" (frame + back bed strip), like the approved mockup
  const int core[8][3] = {
    {FRM_X0, BED_Y0, 0}, {FRM_X1, BED_Y0, 0},
    {FRM_X0, BED_Y1, 0}, {FRM_X1, BED_Y1, 0},
    {FRM_X0, BED_Y0, COL_Z_TOP + 6}, {FRM_X1, BED_Y0, COL_Z_TOP + 6},
    {FRM_X0, BED_Y1, COL_Z_TOP + 6}, {FRM_X1, BED_Y1, COL_Z_TOP + 6},
  };
  int minx = 32767, maxx = -32768, miny = 32767, maxy = -32768;
  s_ox = 0; s_oy = 0;
  for (int i = 0; i < 8; i++) {
    GPoint p = pt(core[i][0], core[i][1], core[i][2]);
    if (p.x < minx) minx = p.x;
    if (p.x > maxx) maxx = p.x;
    if (p.y < miny) miny = p.y;
    if (p.y > maxy) maxy = p.y;
  }
  s_ox = bounds.size.w / 2 - (minx + maxx) / 2;
  s_oy = bounds.size.h / 2 - (miny + maxy) / 2;
}

static void window_load(Window *window) {
  Layer *root = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(root);
  compute_origin(bounds);

  C_SKY    = col_lv(1, 2, 3);
  C_BEDTOP = col_lv(3, 3, 3);
  C_GRID   = col_lv(2, 3, 3);
  C_SHADOW = col_lv(1, 2, 2);
  C_OBJSHADOW = col_lv(2, 2, 2);
  SH_BED      = make_shades(2, 2, 2);
  SH_FRAME    = make_shades(2, 2, 2);
  // "transparent" support material: barely-there pale faces
  SH_SUPPORT = (Shades) {
    .top = col_lv(3, 3, 3), .left = col_lv(2, 3, 3),
    .right = col_lv(2, 2, 3), .line = col_lv(2, 2, 3),
  };
  SH_CARRIAGE = make_shades(1, 1, 1);
  SH_ACCENT   = make_shades(3, 1, 0);
  SH_SLOT     = make_shades(1, 1, 1);
  SH_DIGIT[0] = make_shades(2, 3, 2);
  SH_DIGIT[1] = make_shades(1, 2, 1);
  SH_DIGIT[2] = make_shades(3, 2, 1);
  SH_DIGIT[3] = make_shades(3, 1, 1);
  SH_COLON    = make_shades(1, 2, 2);

  build_font();

  if (persist_exists(PERSIST_LAT)) s_lat100 = persist_read_int(PERSIST_LAT);
  if (persist_exists(PERSIST_LON)) s_lon100 = persist_read_int(PERSIST_LON);
  compute_sun();

  time_t now = now_fx();
  set_digits_from(localtime(&now), s_digits);

  s_layer = layer_create(bounds);
  layer_set_update_proc(s_layer, layer_update);
  layer_add_child(root, s_layer);

  tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
  schedule_anim_start();

  // demo on first launch: reprint the last digit as if it just ticked over
  time_t demo_now = now_fx();
  int sec = (int)(demo_now % 60);
  if (sec < 47 && battery_state_service_peek().charge_percent > 20) {
    memcpy(s_old_digits, s_digits, 4);
    s_old_digits[3] = (uint8_t)((s_digits[3] + 9) % 10);
    for (int i = 0; i < 5; i++) {
      s_item_changed[i] = !ITEM_IS_COLON(i) &&
          s_old_digits[ITEM_DIGIT_SLOT(i)] != s_digits[ITEM_DIGIT_SLOT(i)];
    }
    build_path();
    s_flip_epoch = demo_now + ANIM_LEAD_MS / 1000;
    s_phase = PHASE_SHRED;
    s_shred_off = 0;
    s_elapsed = 0;
    s_anim_timer = app_timer_register(FRAME_MS, anim_timer_cb, NULL);
  }
}

static void inbox_received(DictionaryIterator *iter, void *context) {
  Tuple *lat = dict_find(iter, MESSAGE_KEY_LAT);
  Tuple *lon = dict_find(iter, MESSAGE_KEY_LON);
  if (lat && lon) {
    s_lat100 = lat->value->int32;
    s_lon100 = lon->value->int32;
    persist_write_int(PERSIST_LAT, s_lat100);
    persist_write_int(PERSIST_LON, s_lon100);
    compute_sun();
    if (s_layer) layer_mark_dirty(s_layer);
  }
}

static void window_unload(Window *window) {
  tick_timer_service_unsubscribe();
  if (s_anim_timer) app_timer_cancel(s_anim_timer);
  if (s_start_timer) app_timer_cancel(s_start_timer);
  layer_destroy(s_layer);
}

static void init(void) {
  app_message_register_inbox_received(inbox_received);
  app_message_open(64, 16);
  s_window = window_create();
  window_set_window_handlers(s_window, (WindowHandlers) {
    .load = window_load, .unload = window_unload,
  });
  window_stack_push(s_window, true);
}

static void deinit(void) {
  window_destroy(s_window);
}

int main(void) {
  init();
  app_event_loop();
  deinit();
}
