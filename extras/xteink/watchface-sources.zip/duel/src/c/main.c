#include <pebble.h>

// ============================================================================
// COLORS
// ============================================================================

#ifdef PBL_COLOR
  #define COLOR_BG              GColorBlack
  #define COLOR_STARS           GColorWhite
  #define COLOR_STARS_DIM       GColorLightGray
  #define COLOR_SABER_RED       GColorRed
  #define COLOR_SABER_RED_GLOW  GColorDarkCandyAppleRed
  #define COLOR_SABER_GREEN     GColorGreen
  #define COLOR_SABER_GREEN_GLOW GColorIslamicGreen
  #define COLOR_SABER_CORE      GColorWhite
  #define COLOR_HILT            GColorLightGray
  #define COLOR_HILT_DARK       GColorDarkGray
  #define COLOR_VADER_CAPE      GColorDarkGray
  #define COLOR_VADER_OUTLINE   GColorDarkGray
  #define COLOR_LUKE_BODY       GColorDarkGray
  #define COLOR_LUKE_SKIN       GColorMelon
  #define COLOR_TIME_TEXT       GColorYellow
  #define COLOR_DATE_TEXT       GColorCeleste
  #define COLOR_HOUR_MARKERS    GColorDarkGray
  #define COLOR_CENTER_DOT      GColorYellow
  #define COLOR_BATTERY_GOOD    GColorGreen
  #define COLOR_BATTERY_MED     GColorYellow
  #define COLOR_BATTERY_LOW     GColorRed
#else
  #define COLOR_BG              GColorBlack
  #define COLOR_STARS           GColorWhite
  #define COLOR_STARS_DIM       GColorWhite
  #define COLOR_SABER_RED       GColorWhite
  #define COLOR_SABER_RED_GLOW  GColorWhite
  #define COLOR_SABER_GREEN     GColorWhite
  #define COLOR_SABER_GREEN_GLOW GColorWhite
  #define COLOR_SABER_CORE      GColorWhite
  #define COLOR_HILT            GColorWhite
  #define COLOR_HILT_DARK       GColorWhite
  #define COLOR_VADER_CAPE      GColorWhite
  #define COLOR_VADER_OUTLINE   GColorWhite
  #define COLOR_LUKE_BODY       GColorWhite
  #define COLOR_LUKE_SKIN       GColorWhite
  #define COLOR_TIME_TEXT       GColorWhite
  #define COLOR_DATE_TEXT       GColorWhite
  #define COLOR_HOUR_MARKERS    GColorWhite
  #define COLOR_CENTER_DOT      GColorWhite
  #define COLOR_BATTERY_GOOD    GColorWhite
  #define COLOR_BATTERY_MED     GColorWhite
  #define COLOR_BATTERY_LOW     GColorWhite
#endif

// ============================================================================
// CONSTANTS
// ============================================================================

#define HOUR_BLADE_LEN   50
#define MINUTE_BLADE_LEN 70
#define HILT_LEN         11
#define CHAR_OFFSET      34
#define MARKER_RADIUS    88
#define NUM_STARS_DEFAULT 30
#define NUM_STARS_MAX     36  // 20% more for larger screens

// Animation
#define ANIM_INTERVAL_MS   50    // 20 FPS
#define ANIM_MAX           1024  // fixed-point scale for easing
#define SWING_FRAMES       20    // 1.0s — sabers swing toward clash
#define CLASH_FRAMES       16    // 0.8s — impact, sparks, arcs
#define SETTLE_FRAMES      14    // 0.7s — ease to final positions
#define REBOUND_AMPLITUDE  (TRIG_MAX_ANGLE / 30)  // ~12 deg oscillation
#define REBOUND_DECAY      2     // frames per half-cycle (faster vibration)

// Spark particles
#define MAX_SPARKS 12

// ============================================================================
// DATA STRUCTURES
// ============================================================================

typedef struct {
    int32_t angle;    // radial angle from screen center
    int16_t dist;     // distance from center
    uint8_t streak;   // streak length (2-6px)
    bool dim;
} Star;

typedef enum {
    ANIM_IDLE,
    ANIM_SWING,
    ANIM_CLASH,
    ANIM_SETTLE
} AnimState;

typedef struct {
    int16_t x, y;     // position (4x sub-pixel coords)
    int16_t vx, vy;   // velocity (4x sub-pixel per frame)
    int8_t life;      // frames remaining
} Spark;

// ============================================================================
// SETTINGS (Clay-managed, persisted to flash)
// ============================================================================

#define SETTINGS_KEY 1

typedef enum {
    ANIMATE_NEVER = 0,
    ANIMATE_HOUR  = 1,
    ANIMATE_MINUTE = 2,
} AnimateMode;

typedef struct ClaySettings {
    AnimateMode AnimateEvery;
    bool        PlaySounds;
    uint8_t     Volume;     // 0-100
} ClaySettings;

static ClaySettings settings;

static void prv_default_settings(void) {
    settings.AnimateEvery = ANIMATE_MINUTE;
    settings.PlaySounds   = true;
    settings.Volume       = 75;
}

static void prv_save_settings(void) {
    persist_write_data(SETTINGS_KEY, &settings, sizeof(settings));
}

static void prv_load_settings(void) {
    prv_default_settings();
    persist_read_data(SETTINGS_KEY, &settings, sizeof(settings));
}

// ============================================================================
// GLOBAL STATE
// ============================================================================

static Window *s_main_window;
static Layer *s_canvas_layer;
static TextLayer *s_time_layer;
static TextLayer *s_date_layer;

static GPoint s_center;
static int s_battery_level = 100;

static Star s_stars[NUM_STARS_MAX];
static int s_num_stars = NUM_STARS_DEFAULT;

static char s_time_buf[8];
static char s_date_buf[16];

// GPath objects for lightsaber blades and hilts
static GPath *s_hour_blade_path = NULL;
static GPath *s_min_blade_path = NULL;
static GPath *s_hour_hilt_path = NULL;
static GPath *s_min_hilt_path = NULL;

// Animation state
static AppTimer *s_anim_timer = NULL;
static int s_anim_frame = 0;
static AnimState s_anim_state = ANIM_IDLE;
static int32_t s_old_hour_angle, s_old_min_angle;
static int32_t s_new_hour_angle, s_new_min_angle;
static int32_t s_clash_angle;
static int32_t s_cur_hour_angle, s_cur_min_angle;

// Spark particles
static Spark s_sparks[MAX_SPARKS];
static bool s_sparks_active = false;

// Platform scaling (set at runtime in window_load)
static int s_hour_blade_len = HOUR_BLADE_LEN;
static int s_min_blade_len = MINUTE_BLADE_LEN;
static int s_char_offset = CHAR_OFFSET;
static int s_marker_radius = MARKER_RADIUS;
static int s_cs = 100; // character scale percentage

// Hour blade shape: narrow trapezoid extending upward
static GPoint s_hour_blade_pts[] = {
    {-3,  5}, { 3,  5}, { 2, -48}, {-2, -48}
};
static GPathInfo s_hour_blade_info = {
    .num_points = 4, .points = s_hour_blade_pts
};

// Minute blade shape: longer trapezoid
static GPoint s_min_blade_pts[] = {
    {-3,  5}, { 3,  5}, { 2, -68}, {-2, -68}
};
static GPathInfo s_min_blade_info = {
    .num_points = 4, .points = s_min_blade_pts
};

// Hour hilt
static GPoint s_hour_hilt_pts[] = {
    {-4,  5}, { 4,  5}, { 4, 16}, {-4, 16}
};
static GPathInfo s_hour_hilt_info = {
    .num_points = 4, .points = s_hour_hilt_pts
};

// Minute hilt
static GPoint s_min_hilt_pts[] = {
    {-4,  5}, { 4,  5}, { 4, 16}, {-4, 16}
};
static GPathInfo s_min_hilt_info = {
    .num_points = 4, .points = s_min_hilt_pts
};

// ============================================================================
// UTILITY
// ============================================================================

static int random_in_range(int min, int max) {
    if (max <= min) return min;
    return min + (rand() % (max - min + 1));
}

// ============================================================================
// ANIMATION MATH
// ============================================================================

// Ease-in: quadratic (slow start, fast end)
static int32_t ease_in(int32_t t) {
    return (t * t) / ANIM_MAX;
}

// Ease-out: inverse quadratic (fast start, slow end)
static int32_t ease_out(int32_t t) {
    int32_t inv = ANIM_MAX - t;
    return ANIM_MAX - (inv * inv) / ANIM_MAX;
}

// Normalize angle to [0, TRIG_MAX_ANGLE)
static int32_t norm_angle(int32_t a) {
    a = a % TRIG_MAX_ANGLE;
    if (a < 0) a += TRIG_MAX_ANGLE;
    return a;
}

// Interpolate between two angles along the shortest arc
static int32_t interp_angle(int32_t from, int32_t to, int32_t progress) {
    from = norm_angle(from);
    to = norm_angle(to);
    int32_t diff = to - from;
    if (diff > TRIG_MAX_ANGLE / 2)  diff -= TRIG_MAX_ANGLE;
    if (diff < -TRIG_MAX_ANGLE / 2) diff += TRIG_MAX_ANGLE;
    return norm_angle(from + (diff * progress) / ANIM_MAX);
}

// Midpoint of the shorter arc between two angles
static int32_t compute_clash_angle(int32_t a, int32_t b) {
    a = norm_angle(a);
    b = norm_angle(b);
    int32_t diff = b - a;
    if (diff > TRIG_MAX_ANGLE / 2)  diff -= TRIG_MAX_ANGLE;
    if (diff < -TRIG_MAX_ANGLE / 2) diff += TRIG_MAX_ANGLE;
    return norm_angle(a + diff / 2);
}

// ============================================================================
// SOUND EFFECTS
// ============================================================================

#if defined(PBL_SPEAKER)
// 5 real lightsaber clash recordings, stored as 16kHz/16-bit signed mono PCM
// in raw resources. Picked at random on each clash.
static const uint32_t s_clash_resource_ids[] = {
    RESOURCE_ID_CLASH1, RESOURCE_ID_CLASH2, RESOURCE_ID_CLASH3,
    RESOURCE_ID_CLASH4, RESOURCE_ID_CLASH5,
};
#define NUM_CLASH_SOUNDS (sizeof(s_clash_resource_ids) / sizeof(s_clash_resource_ids[0]))

// Streaming state: clash PCM is fed to the speaker in chunks via a timer so
// the watchface stays responsive. Buffer freed when feeder finishes.
#define CLASH_FEED_INTERVAL_MS 30
#define CLASH_FEED_CHUNK       2048

static uint8_t *s_clash_buffer = NULL;
static uint32_t s_clash_total = 0;
static uint32_t s_clash_offset = 0;
static AppTimer *s_clash_feed_timer = NULL;
static bool s_clash_stream_open = false;

static void clash_cleanup(void) {
    if (s_clash_feed_timer) { app_timer_cancel(s_clash_feed_timer); s_clash_feed_timer = NULL; }
    if (s_clash_stream_open) { speaker_stream_close(); s_clash_stream_open = false; }
    if (s_clash_buffer) { free(s_clash_buffer); s_clash_buffer = NULL; }
    s_clash_total = 0;
    s_clash_offset = 0;
}

static void clash_feed_timer_cb(void *ctx);

static void schedule_clash_feed(uint32_t delay_ms) {
    s_clash_feed_timer = app_timer_register(delay_ms, clash_feed_timer_cb, NULL);
}

static void clash_feed_timer_cb(void *ctx) {
    (void)ctx;
    s_clash_feed_timer = NULL;
    if (!s_clash_buffer || !s_clash_stream_open) { clash_cleanup(); return; }

    uint32_t remaining = s_clash_total - s_clash_offset;
    if (remaining == 0) {
        // All data delivered — close the stream so buffered audio drains.
        speaker_stream_close();
        s_clash_stream_open = false;
        free(s_clash_buffer);
        s_clash_buffer = NULL;
        return;
    }

    uint32_t want = remaining < CLASH_FEED_CHUNK ? remaining : CLASH_FEED_CHUNK;
    uint32_t accepted = speaker_stream_write(s_clash_buffer + s_clash_offset, want);
    s_clash_offset += accepted;

    schedule_clash_feed(CLASH_FEED_INTERVAL_MS);
}

static void play_clash_sound(void) {
    if (!settings.PlaySounds) return;
    if (quiet_time_is_active()) return;

    clash_cleanup();

    uint32_t res_id = s_clash_resource_ids[rand() % NUM_CLASH_SOUNDS];
    ResHandle h = resource_get_handle(res_id);
    size_t size = resource_size(h);
    if (size == 0) return;

    s_clash_buffer = (uint8_t *)malloc(size);
    if (!s_clash_buffer) return;

    if (resource_load(h, s_clash_buffer, size) != size) {
        free(s_clash_buffer);
        s_clash_buffer = NULL;
        return;
    }

    // Scale samples in software so volume control is independent of any
    // hardware/driver behavior. PCM is 16-bit signed little-endian.
    if (settings.Volume < 100) {
        int16_t *samples = (int16_t *)s_clash_buffer;
        size_t nsamples = size / sizeof(int16_t);
        int32_t scale = settings.Volume;  // 0-100
        for (size_t i = 0; i < nsamples; i++) {
            samples[i] = (int16_t)(((int32_t)samples[i] * scale) / 100);
        }
    }

    s_clash_total = (uint32_t)size;
    s_clash_offset = 0;

    if (!speaker_stream_open(SpeakerPcmFormat_16kHz_16bit, settings.Volume)) {
        free(s_clash_buffer);
        s_clash_buffer = NULL;
        return;
    }
    s_clash_stream_open = true;

    schedule_clash_feed(0);
}
#else
static void play_clash_sound(void) {}
#endif

// ============================================================================
// SPARK PARTICLES
// ============================================================================

static void init_sparks(void) {
    for (int i = 0; i < MAX_SPARKS; i++) {
        // Spawn at center (clash point)
        s_sparks[i].x = s_center.x * 4;
        s_sparks[i].y = s_center.y * 4;
        // Random radial velocity
        int32_t angle = random_in_range(0, (int)(TRIG_MAX_ANGLE - 1));
        int speed = random_in_range(6, 16);
        s_sparks[i].vx = (int16_t)((sin_lookup(angle) * speed) / TRIG_MAX_RATIO);
        s_sparks[i].vy = (int16_t)(-(cos_lookup(angle) * speed) / TRIG_MAX_RATIO);
        s_sparks[i].life = (int8_t)random_in_range(8, 14);
    }
    s_sparks_active = true;
}

static void update_sparks(void) {
    bool any_alive = false;
    for (int i = 0; i < MAX_SPARKS; i++) {
        if (s_sparks[i].life > 0) {
            s_sparks[i].x += s_sparks[i].vx;
            s_sparks[i].y += s_sparks[i].vy;
            s_sparks[i].vy += 1; // gravity
            s_sparks[i].life--;
            any_alive = true;
        }
    }
    if (!any_alive) s_sparks_active = false;
}

static void draw_sparks(GContext *ctx) {
    for (int i = 0; i < MAX_SPARKS; i++) {
        if (s_sparks[i].life <= 0) continue;

        int16_t sx = s_sparks[i].x / 4;
        int16_t sy = s_sparks[i].y / 4;
        // Trail behind the spark
        int16_t tx = (s_sparks[i].x - s_sparks[i].vx * 2) / 4;
        int16_t ty = (s_sparks[i].y - s_sparks[i].vy * 2) / 4;

        #ifdef PBL_COLOR
        if (s_sparks[i].life > 8) {
            graphics_context_set_stroke_color(ctx, GColorWhite);
        } else if (s_sparks[i].life > 4) {
            graphics_context_set_stroke_color(ctx, GColorYellow);
        } else {
            graphics_context_set_stroke_color(ctx, GColorChromeYellow);
        }
        #else
        graphics_context_set_stroke_color(ctx, GColorWhite);
        #endif
        graphics_context_set_stroke_width(ctx, 1);
        graphics_draw_line(ctx, GPoint(tx, ty), GPoint(sx, sy));

        // Bright dot at head
        if (s_sparks[i].life > 6) {
            graphics_context_set_fill_color(ctx, GColorWhite);
            graphics_fill_circle(ctx, GPoint(sx, sy), 1);
        }
    }
}

// ============================================================================
// ELECTRIC ARCS
// ============================================================================

static void draw_electric_arc(GContext *ctx, int32_t blade_angle,
                               int start_dist, int end_dist) {
    int segments = 6;
    int seg_len = (end_dist - start_dist) / segments;
    if (seg_len < 2) return;

    int32_t perp = blade_angle + TRIG_MAX_ANGLE / 4;

    int16_t prev_x = s_center.x + (sin_lookup(blade_angle) * start_dist) / TRIG_MAX_RATIO;
    int16_t prev_y = s_center.y - (cos_lookup(blade_angle) * start_dist) / TRIG_MAX_RATIO;

    for (int s = 1; s <= segments; s++) {
        int dist = start_dist + s * seg_len;
        int16_t bx = s_center.x + (sin_lookup(blade_angle) * dist) / TRIG_MAX_RATIO;
        int16_t by = s_center.y - (cos_lookup(blade_angle) * dist) / TRIG_MAX_RATIO;

        // Random lateral zigzag (except at endpoint)
        int offset = 0;
        if (s < segments) {
            offset = random_in_range(-7, 7);
        }
        int16_t nx = bx + (sin_lookup(perp) * offset) / TRIG_MAX_RATIO;
        int16_t ny = by - (cos_lookup(perp) * offset) / TRIG_MAX_RATIO;

        // Outer glow
        #ifdef PBL_COLOR
        graphics_context_set_stroke_color(ctx, GColorCyan);
        #else
        graphics_context_set_stroke_color(ctx, GColorWhite);
        #endif
        graphics_context_set_stroke_width(ctx, 3);
        graphics_draw_line(ctx, GPoint(prev_x, prev_y), GPoint(nx, ny));

        // White core
        graphics_context_set_stroke_color(ctx, GColorWhite);
        graphics_context_set_stroke_width(ctx, 1);
        graphics_draw_line(ctx, GPoint(prev_x, prev_y), GPoint(nx, ny));

        prev_x = nx;
        prev_y = ny;
    }
}

static void draw_electric_arcs(GContext *ctx) {
    // 3 arcs along each blade, from center outward
    for (int i = 0; i < 3; i++) {
        draw_electric_arc(ctx, s_cur_hour_angle, 5, s_hour_blade_len - 5);
    }
    for (int i = 0; i < 3; i++) {
        draw_electric_arc(ctx, s_cur_min_angle, 5, s_min_blade_len - 5);
    }
}

// ============================================================================
// STAR BACKGROUND
// ============================================================================

static void init_stars(int screen_w, int screen_h) {
    // Denser starfield on larger screens
    s_num_stars = (screen_w >= 260) ? NUM_STARS_MAX : NUM_STARS_DEFAULT;
    int max_dist = 140;
    for (int i = 0; i < s_num_stars; i++) {
        // Place stars at random x,y positions, then convert to polar
        // This gives even spatial distribution (no center clustering)
        int16_t sx, sy;
        do {
            sx = random_in_range(0, screen_w);
            sy = random_in_range(0, screen_h);
        } while (sy < 32 || sy > screen_h - 28);  // avoid text zones

        int16_t dx = sx - screen_w / 2;
        int16_t dy = sy - screen_h / 2;
        s_stars[i].angle = atan2_lookup(dx, -dy);
        // Integer distance approximation (avoid float sqrt)
        int adx = abs(dx);
        int ady = abs(dy);
        s_stars[i].dist = (adx > ady) ? adx + ady / 2 : ady + adx / 2;

        // Longer streaks for stars farther from center
        s_stars[i].streak = (uint8_t)(12 + (s_stars[i].dist * 30) / max_dist);
        s_stars[i].dim = (random_in_range(0, 2) == 0);
    }
}

static void draw_stars(GContext *ctx) {
    graphics_context_set_antialiased(ctx, true);

    for (int i = 0; i < s_num_stars; i++) {
        // Inner point (closer to center)
        int16_t x1 = s_center.x + (sin_lookup(s_stars[i].angle) * s_stars[i].dist) / TRIG_MAX_RATIO;
        int16_t y1 = s_center.y - (cos_lookup(s_stars[i].angle) * s_stars[i].dist) / TRIG_MAX_RATIO;

        // Outer point (streak extends outward from center)
        int outer_dist = s_stars[i].dist + s_stars[i].streak;
        int16_t x2 = s_center.x + (sin_lookup(s_stars[i].angle) * outer_dist) / TRIG_MAX_RATIO;
        int16_t y2 = s_center.y - (cos_lookup(s_stars[i].angle) * outer_dist) / TRIG_MAX_RATIO;

        graphics_context_set_stroke_color(ctx,
            s_stars[i].dim ? COLOR_STARS_DIM : COLOR_STARS);
        graphics_context_set_stroke_width(ctx, 1);
        graphics_draw_line(ctx, GPoint(x1, y1), GPoint(x2, y2));
    }
}

// ============================================================================
// HOUR MARKERS
// ============================================================================

static void draw_hour_markers(GContext *ctx) {
    graphics_context_set_stroke_color(ctx, COLOR_HOUR_MARKERS);
    graphics_context_set_stroke_width(ctx, 1);

    for (int i = 0; i < 12; i++) {
        int32_t angle = (i * TRIG_MAX_ANGLE) / 12;
        int inner_r = s_marker_radius - 5;
        int outer_r = s_marker_radius;

        // Longer ticks at 12, 3, 6, 9
        if (i % 3 == 0) {
            inner_r = s_marker_radius - 10;
            graphics_context_set_stroke_width(ctx, 2);
        } else {
            graphics_context_set_stroke_width(ctx, 1);
        }

        GPoint inner = {
            s_center.x + (sin_lookup(angle) * inner_r) / TRIG_MAX_RATIO,
            s_center.y - (cos_lookup(angle) * inner_r) / TRIG_MAX_RATIO
        };
        GPoint outer = {
            s_center.x + (sin_lookup(angle) * outer_r) / TRIG_MAX_RATIO,
            s_center.y - (cos_lookup(angle) * outer_r) / TRIG_MAX_RATIO
        };

        graphics_draw_line(ctx, inner, outer);
    }
}

// ============================================================================
// LIGHTSABER DRAWING
// ============================================================================

static void draw_saber_glow(GContext *ctx, int32_t angle, int length, GColor glow_color) {
    int16_t tip_x = s_center.x + (sin_lookup(angle) * length) / TRIG_MAX_RATIO;
    int16_t tip_y = s_center.y - (cos_lookup(angle) * length) / TRIG_MAX_RATIO;

    graphics_context_set_stroke_color(ctx, glow_color);
    graphics_context_set_stroke_width(ctx, 7);
    graphics_context_set_antialiased(ctx, true);
    graphics_draw_line(ctx, s_center, GPoint(tip_x, tip_y));
}

static void draw_saber_blade(GContext *ctx, GPath *blade_path, int32_t angle,
                              GColor blade_color) {
    gpath_rotate_to(blade_path, angle);
    gpath_move_to(blade_path, s_center);

    // Blade fill
    graphics_context_set_fill_color(ctx, blade_color);
    gpath_draw_filled(ctx, blade_path);

    // White core line for glow effect
    int core_len = (blade_path == s_hour_blade_path) ? s_hour_blade_len - 5 : s_min_blade_len - 5;
    int16_t core_x = s_center.x + (sin_lookup(angle) * core_len) / TRIG_MAX_RATIO;
    int16_t core_y = s_center.y - (cos_lookup(angle) * core_len) / TRIG_MAX_RATIO;

    graphics_context_set_stroke_color(ctx, COLOR_SABER_CORE);
    graphics_context_set_stroke_width(ctx, 1);
    graphics_draw_line(ctx, s_center, GPoint(core_x, core_y));
}

static void draw_saber_hilt(GContext *ctx, GPath *hilt_path, int32_t angle) {
    gpath_rotate_to(hilt_path, angle);
    gpath_move_to(hilt_path, s_center);

    graphics_context_set_fill_color(ctx, COLOR_HILT);
    gpath_draw_filled(ctx, hilt_path);
    graphics_context_set_stroke_color(ctx, COLOR_HILT_DARK);
    gpath_draw_outline(ctx, hilt_path);

    // Crossguard: short perpendicular line at the blade/hilt junction
    int32_t perp = angle + TRIG_MAX_ANGLE / 4;
    int16_t cg1_x = s_center.x + (sin_lookup(angle) * 5) / TRIG_MAX_RATIO
                   + (sin_lookup(perp) * 6) / TRIG_MAX_RATIO;
    int16_t cg1_y = s_center.y - (cos_lookup(angle) * 5) / TRIG_MAX_RATIO
                   - (cos_lookup(perp) * 6) / TRIG_MAX_RATIO;
    int16_t cg2_x = s_center.x + (sin_lookup(angle) * 5) / TRIG_MAX_RATIO
                   - (sin_lookup(perp) * 6) / TRIG_MAX_RATIO;
    int16_t cg2_y = s_center.y - (cos_lookup(angle) * 5) / TRIG_MAX_RATIO
                   + (cos_lookup(perp) * 6) / TRIG_MAX_RATIO;

    graphics_context_set_stroke_width(ctx, 2);
    graphics_draw_line(ctx, GPoint(cg1_x, cg1_y), GPoint(cg2_x, cg2_y));
}

// ============================================================================
// CHARACTER SILHOUETTES
// ============================================================================

// Scale macro: applies s_cs (character scale percentage) to pixel offsets
#define S(v) ((int16_t)((v) * s_cs / 100))

static void draw_vader(GContext *ctx, int16_t x, int16_t y) {
    // --- Cape (wide, flowing shape) ---
    GPoint cape[] = {
        {x, y - S(14)},
        {x - S(18), y + S(20)},
        {x - S(14), y + S(22)},
        {x, y + S(18)},
        {x + S(14), y + S(22)},
        {x + S(18), y + S(20)}
    };
    GPathInfo cape_info = { .num_points = 6, .points = cape };
    GPath *cape_path = gpath_create(&cape_info);
    graphics_context_set_fill_color(ctx, COLOR_VADER_CAPE);
    gpath_draw_filled(ctx, cape_path);
    gpath_destroy(cape_path);

    // --- Body / armor torso ---
    GPoint body[] = {
        {x - S(10), y - S(14)},
        {x + S(10), y - S(14)},
        {x + S(9), y + S(2)},
        {x + S(11), y + S(18)},
        {x + S(4), y + S(18)},
        {x, y + S(8)},
        {x - S(4), y + S(18)},
        {x - S(11), y + S(18)},
        {x - S(9), y + S(2)}
    };
    GPathInfo body_info = { .num_points = 9, .points = body };
    GPath *body_path = gpath_create(&body_info);
    graphics_context_set_fill_color(ctx, COLOR_VADER_OUTLINE);
    gpath_draw_filled(ctx, body_path);
    gpath_destroy(body_path);

    // --- Belt ---
    graphics_context_set_fill_color(ctx, COLOR_HILT);
    graphics_fill_rect(ctx, GRect(x - S(9), y, S(18), S(3)), 0, GCornerNone);
    // Belt buckle
    graphics_context_set_fill_color(ctx, COLOR_SABER_CORE);
    graphics_fill_rect(ctx, GRect(x - S(2), y, S(4), S(3)), 0, GCornerNone);

    // --- Chest panel (iconic control box) ---
    #ifdef PBL_COLOR
    graphics_context_set_fill_color(ctx, GColorDarkGray);
    graphics_fill_rect(ctx, GRect(x - S(4), y - S(10), S(8), S(6)), 1, GCornersAll);
    // Colored buttons on chest panel
    graphics_context_set_stroke_color(ctx, GColorRed);
    graphics_draw_pixel(ctx, GPoint(x - S(2), y - S(8)));
    graphics_context_set_stroke_color(ctx, GColorBlue);
    graphics_draw_pixel(ctx, GPoint(x, y - S(8)));
    graphics_context_set_stroke_color(ctx, GColorGreen);
    graphics_draw_pixel(ctx, GPoint(x + S(2), y - S(8)));
    #endif

    // --- Helmet ---
    graphics_context_set_fill_color(ctx, COLOR_VADER_OUTLINE);
    GPoint helmet[] = {
        {x - S(9), y - S(17)},
        {x - S(7), y - S(26)},
        {x, y - S(29)},
        {x + S(7), y - S(26)},
        {x + S(9), y - S(17)}
    };
    GPathInfo helmet_info = { .num_points = 5, .points = helmet };
    GPath *helmet_path = gpath_create(&helmet_info);
    gpath_draw_filled(ctx, helmet_path);
    gpath_destroy(helmet_path);

    // Face plate (darker inset)
    graphics_context_set_fill_color(ctx, COLOR_BG);
    GPoint faceplate[] = {
        {x - S(5), y - S(17)},
        {x - S(4), y - S(23)},
        {x + S(4), y - S(23)},
        {x + S(5), y - S(17)}
    };
    GPathInfo face_info = { .num_points = 4, .points = faceplate };
    GPath *face_path = gpath_create(&face_info);
    gpath_draw_filled(ctx, face_path);
    gpath_destroy(face_path);

    // Triangular mouth grill
    graphics_context_set_stroke_color(ctx, COLOR_VADER_CAPE);
    graphics_context_set_stroke_width(ctx, 1);
    GPoint mouth[] = {
        {x - S(3), y - S(19)},
        {x, y - S(17)},
        {x + S(3), y - S(19)}
    };
    GPathInfo mouth_info = { .num_points = 3, .points = mouth };
    GPath *mouth_path = gpath_create(&mouth_info);
    gpath_draw_outline(ctx, mouth_path);
    gpath_destroy(mouth_path);

    // Eye lenses
    #ifdef PBL_COLOR
    graphics_context_set_fill_color(ctx, GColorRed);
    #else
    graphics_context_set_fill_color(ctx, GColorWhite);
    #endif
    graphics_fill_rect(ctx, GRect(x - S(4), y - S(22), S(3), S(2)), 0, GCornerNone);
    graphics_fill_rect(ctx, GRect(x + S(1), y - S(22), S(3), S(2)), 0, GCornerNone);
}

static void draw_luke(GContext *ctx, int16_t x, int16_t y) {
    // --- Tunic / body ---
    GPoint tunic[] = {
        {x - S(8), y - S(12)},
        {x + S(8), y - S(12)},
        {x + S(7), y + S(2)},
        {x + S(10), y + S(18)},
        {x + S(3), y + S(18)},
        {x, y + S(8)},
        {x - S(3), y + S(18)},
        {x - S(10), y + S(18)},
        {x - S(7), y + S(2)}
    };
    GPathInfo tunic_info = { .num_points = 9, .points = tunic };
    GPath *tunic_path = gpath_create(&tunic_info);
    graphics_context_set_fill_color(ctx, COLOR_LUKE_BODY);
    gpath_draw_filled(ctx, tunic_path);
    gpath_destroy(tunic_path);

    // --- Tunic overlap / vest ---
    #ifdef PBL_COLOR
    GPoint vest[] = {
        {x - S(3), y - S(12)},
        {x + S(3), y - S(12)},
        {x + S(2), y + S(4)},
        {x - S(2), y + S(4)}
    };
    GPathInfo vest_info = { .num_points = 4, .points = vest };
    GPath *vest_path = gpath_create(&vest_info);
    graphics_context_set_fill_color(ctx, GColorDarkGray);
    gpath_draw_filled(ctx, vest_path);
    gpath_destroy(vest_path);
    #endif

    // --- Belt ---
    graphics_context_set_fill_color(ctx, COLOR_HILT);
    graphics_fill_rect(ctx, GRect(x - S(7), y + S(1), S(14), S(2)), 0, GCornerNone);

    // --- Neck ---
    graphics_context_set_fill_color(ctx, COLOR_LUKE_SKIN);
    graphics_fill_rect(ctx, GRect(x - S(2), y - S(14), S(4), S(3)), 0, GCornerNone);

    // --- Head ---
    graphics_context_set_fill_color(ctx, COLOR_LUKE_SKIN);
    graphics_fill_circle(ctx, GPoint(x, y - S(19)), S(6));

    // --- Hair (blond, fuller) ---
    #ifdef PBL_COLOR
    graphics_context_set_fill_color(ctx, GColorRajah);
    #else
    graphics_context_set_fill_color(ctx, GColorWhite);
    #endif
    graphics_fill_rect(ctx, GRect(x - S(6), y - S(26), S(12), S(6)), S(4), GCornersTop);
    graphics_fill_rect(ctx, GRect(x - S(7), y - S(23), S(3), S(5)), 1, GCornersLeft);
    graphics_fill_rect(ctx, GRect(x + S(4), y - S(23), S(3), S(5)), 1, GCornersRight);

    // --- Eyes ---
    graphics_context_set_fill_color(ctx, COLOR_BG);
    graphics_fill_rect(ctx, GRect(x - S(3), y - S(20), S(2), S(2)), 0, GCornerNone);
    graphics_fill_rect(ctx, GRect(x + S(1), y - S(20), S(2), S(2)), 0, GCornerNone);

    // --- Mouth ---
    graphics_context_set_stroke_color(ctx, COLOR_BG);
    graphics_context_set_stroke_width(ctx, 1);
    graphics_draw_line(ctx, GPoint(x - S(2), y - S(16)), GPoint(x + S(2), y - S(16)));
}

#undef S

// ============================================================================
// BATTERY
// ============================================================================

static void draw_battery(GContext *ctx, GRect bounds) {
    int bar_w = 20;
    int bar_h = 6;
    int bar_x = bounds.size.w - bar_w - 5;
    int bar_y = 5;

    // Outline
    graphics_context_set_stroke_color(ctx, COLOR_HOUR_MARKERS);
    graphics_draw_rect(ctx, GRect(bar_x, bar_y, bar_w, bar_h));

    // Fill
    int fill_w = (s_battery_level * bar_w) / 100;
    #ifdef PBL_COLOR
    GColor fill_color = COLOR_BATTERY_GOOD;
    if (s_battery_level <= 20) fill_color = COLOR_BATTERY_LOW;
    else if (s_battery_level <= 40) fill_color = COLOR_BATTERY_MED;
    graphics_context_set_fill_color(ctx, fill_color);
    #else
    graphics_context_set_fill_color(ctx, GColorWhite);
    #endif
    graphics_fill_rect(ctx, GRect(bar_x, bar_y, fill_w, bar_h), 0, GCornerNone);

    // Tip
    graphics_fill_rect(ctx, GRect(bar_x + bar_w, bar_y + 1, 2, bar_h - 2), 0, GCornerNone);
}

// ============================================================================
// MAIN CANVAS UPDATE
// ============================================================================

static void canvas_update_proc(Layer *layer, GContext *ctx) {
    GRect bounds = layer_get_bounds(layer);

    // 1. Clear background
    graphics_context_set_fill_color(ctx, COLOR_BG);
    graphics_fill_rect(ctx, bounds, 0, GCornerNone);

    // 2. Draw stars
    draw_stars(ctx);

    // 3. Draw hour markers
    draw_hour_markers(ctx);

    // Get saber angles — animated or static
    int32_t hour_angle, min_angle;
    if (s_anim_state != ANIM_IDLE) {
        hour_angle = s_cur_hour_angle;
        min_angle = s_cur_min_angle;
    } else {
        time_t temp = time(NULL);
        struct tm *t = localtime(&temp);
        if (!t) return;
        hour_angle = ((t->tm_hour % 12) * TRIG_MAX_ANGLE / 12) +
                     (t->tm_min * TRIG_MAX_ANGLE / 12 / 60);
        min_angle = (t->tm_min * TRIG_MAX_ANGLE / 60);
    }

    // 4. Calculate character positions
    // Compute "behind hilt" positions (normal resting spots)
    int32_t vader_dir = hour_angle + TRIG_MAX_ANGLE / 2;
    int16_t vader_hilt_x = s_center.x + (sin_lookup(vader_dir) * s_char_offset) / TRIG_MAX_RATIO;
    int16_t vader_hilt_y = s_center.y - (cos_lookup(vader_dir) * s_char_offset) / TRIG_MAX_RATIO;

    int32_t luke_dir = min_angle + TRIG_MAX_ANGLE / 2;
    int16_t luke_hilt_x = s_center.x + (sin_lookup(luke_dir) * s_char_offset) / TRIG_MAX_RATIO;
    int16_t luke_hilt_y = s_center.y - (cos_lookup(luke_dir) * s_char_offset) / TRIG_MAX_RATIO;

    int16_t vader_x, vader_y, luke_x, luke_y;

    if (s_anim_state != ANIM_IDLE) {
        // Compute "duel stance" positions: side-by-side perpendicular to clash line
        int32_t behind = s_clash_angle + TRIG_MAX_ANGLE / 2;
        int32_t perp = s_clash_angle + TRIG_MAX_ANGLE / 4;
        int perp_spread = 22;
        int back_dist = 20;

        int16_t vader_duel_x = s_center.x + (sin_lookup(behind) * back_dist) / TRIG_MAX_RATIO
                                           + (sin_lookup(perp) * perp_spread) / TRIG_MAX_RATIO;
        int16_t vader_duel_y = s_center.y - (cos_lookup(behind) * back_dist) / TRIG_MAX_RATIO
                                           - (cos_lookup(perp) * perp_spread) / TRIG_MAX_RATIO;
        int16_t luke_duel_x = s_center.x + (sin_lookup(behind) * back_dist) / TRIG_MAX_RATIO
                                          - (sin_lookup(perp) * perp_spread) / TRIG_MAX_RATIO;
        int16_t luke_duel_y = s_center.y - (cos_lookup(behind) * back_dist) / TRIG_MAX_RATIO
                                          + (cos_lookup(perp) * perp_spread) / TRIG_MAX_RATIO;

        // Blend factor: 0 = hilt position, ANIM_MAX = duel position
        int32_t blend = 0;
        if (s_anim_state == ANIM_SWING) {
            // Ease into duel stance as sabers swing toward clash
            int32_t t = (s_anim_frame * ANIM_MAX) / SWING_FRAMES;
            blend = ease_in(t);
        } else if (s_anim_state == ANIM_CLASH) {
            blend = ANIM_MAX; // fully in duel stance
        } else if (s_anim_state == ANIM_SETTLE) {
            // Ease back to hilt positions
            int32_t t = (s_anim_frame * ANIM_MAX) / SETTLE_FRAMES;
            blend = ANIM_MAX - ease_out(t);
        }

        vader_x = vader_hilt_x + (int16_t)(((int32_t)(vader_duel_x - vader_hilt_x) * blend) / ANIM_MAX);
        vader_y = vader_hilt_y + (int16_t)(((int32_t)(vader_duel_y - vader_hilt_y) * blend) / ANIM_MAX);
        luke_x = luke_hilt_x + (int16_t)(((int32_t)(luke_duel_x - luke_hilt_x) * blend) / ANIM_MAX);
        luke_y = luke_hilt_y + (int16_t)(((int32_t)(luke_duel_y - luke_hilt_y) * blend) / ANIM_MAX);
    } else {
        vader_x = vader_hilt_x;
        vader_y = vader_hilt_y;
        luke_x = luke_hilt_x;
        luke_y = luke_hilt_y;
    }

    // 5. Draw character silhouettes BEHIND sabers
    // Add pixel shake during clash for impact feel
    if (s_anim_state == ANIM_CLASH) {
        int shake = 2 * (CLASH_FRAMES - s_anim_frame) / CLASH_FRAMES + 1;
        vader_x += random_in_range(-shake, shake);
        vader_y += random_in_range(-shake, shake);
        luke_x += random_in_range(-shake, shake);
        luke_y += random_in_range(-shake, shake);
    }
    draw_vader(ctx, vader_x, vader_y);

    // 6. Draw saber glows
    draw_saber_glow(ctx, hour_angle, s_hour_blade_len, COLOR_SABER_RED_GLOW);
    draw_saber_glow(ctx, min_angle, s_min_blade_len, COLOR_SABER_GREEN_GLOW);

    // 7. Draw lightsaber blades
    draw_saber_blade(ctx, s_hour_blade_path, hour_angle, COLOR_SABER_RED);
    draw_saber_blade(ctx, s_min_blade_path, min_angle, COLOR_SABER_GREEN);

    // 8. Draw lightsaber hilts
    draw_saber_hilt(ctx, s_hour_hilt_path, hour_angle);
    draw_saber_hilt(ctx, s_min_hilt_path, min_angle);

    // 9. Center clash dot (the duel point)
    graphics_context_set_fill_color(ctx, COLOR_CENTER_DOT);
    graphics_fill_circle(ctx, s_center, 3);
    graphics_context_set_fill_color(ctx, COLOR_SABER_CORE);
    graphics_fill_circle(ctx, s_center, 1);

    // 9b. Draw Luke ON TOP of everything so he's not hidden
    draw_luke(ctx, luke_x, luke_y);

    // 10. Clash effects: electric arcs + sparks + flash
    if (s_anim_state == ANIM_CLASH) {
        draw_electric_arcs(ctx);
        // Bright white flash at center during first few clash frames
        if (s_anim_frame < 5) {
            graphics_context_set_fill_color(ctx, GColorWhite);
            graphics_fill_circle(ctx, s_center, 8 - s_anim_frame);
        }
    }
    if (s_sparks_active) {
        draw_sparks(ctx);
    }

    // 11. Battery
    draw_battery(ctx, bounds);
}

// ============================================================================
// TIME HANDLING
// ============================================================================

static void update_time(void) {
    time_t temp = time(NULL);
    struct tm *tick_time = localtime(&temp);
    if (!tick_time) return;

    strftime(s_time_buf, sizeof(s_time_buf),
             clock_is_24h_style() ? "%H:%M" : "%I:%M", tick_time);
    text_layer_set_text(s_time_layer, s_time_buf);

    strftime(s_date_buf, sizeof(s_date_buf), "%a, %b %d", tick_time);
    text_layer_set_text(s_date_layer, s_date_buf);
}

// Forward declaration
static void anim_timer_callback(void *data);

static void anim_timer_callback(void *data) {
    s_anim_frame++;

    switch (s_anim_state) {
        case ANIM_SWING: {
            if (s_anim_frame > SWING_FRAMES) {
                s_anim_state = ANIM_CLASH;
                s_anim_frame = 0;
                init_sparks();
                play_clash_sound();
                break;
            }
            int32_t t = (s_anim_frame * ANIM_MAX) / SWING_FRAMES;
            int32_t progress = ease_in(t);
            s_cur_hour_angle = interp_angle(s_old_hour_angle, s_clash_angle, progress);
            s_cur_min_angle  = interp_angle(s_old_min_angle,  s_clash_angle, progress);
            break;
        }
        case ANIM_CLASH: {
            if (s_anim_frame > CLASH_FRAMES) {
                s_anim_state = ANIM_SETTLE;
                s_anim_frame = 0;
                break;
            }
            // Damped oscillation + random jitter for violent clash feel
            int32_t decay = REBOUND_AMPLITUDE * (CLASH_FRAMES - s_anim_frame) / CLASH_FRAMES;
            int32_t osc_phase = (s_anim_frame * TRIG_MAX_ANGLE / REBOUND_DECAY);
            int32_t osc = (sin_lookup(osc_phase) * decay) / TRIG_MAX_RATIO;
            // Add random angular jitter that decays over time
            int32_t jitter_range = (TRIG_MAX_ANGLE / 25) * (CLASH_FRAMES - s_anim_frame) / CLASH_FRAMES;
            int32_t jitter = random_in_range((int)(-jitter_range), (int)(jitter_range));
            s_cur_hour_angle = norm_angle(s_clash_angle + osc + jitter);
            s_cur_min_angle  = norm_angle(s_clash_angle - osc - jitter);
            update_sparks();
            break;
        }
        case ANIM_SETTLE: {
            if (s_anim_frame > SETTLE_FRAMES) {
                s_anim_state = ANIM_IDLE;
                s_anim_timer = NULL;
                s_sparks_active = false;
                layer_mark_dirty(s_canvas_layer);
                return; // stop timer
            }
            int32_t t = (s_anim_frame * ANIM_MAX) / SETTLE_FRAMES;
            int32_t progress = ease_out(t);
            s_cur_hour_angle = interp_angle(s_clash_angle, s_new_hour_angle, progress);
            s_cur_min_angle  = interp_angle(s_clash_angle, s_new_min_angle,  progress);
            if (s_sparks_active) update_sparks();
            break;
        }
        default:
            s_anim_timer = NULL;
            return;
    }

    layer_mark_dirty(s_canvas_layer);
    s_anim_timer = app_timer_register(ANIM_INTERVAL_MS, anim_timer_callback, NULL);
}

static void start_duel_animation(struct tm *t) {
    // Cancel any running animation
    if (s_anim_timer) {
        app_timer_cancel(s_anim_timer);
        s_anim_timer = NULL;
    }

    // Old angles: previous minute's positions
    int prev_min = (t->tm_min + 59) % 60;
    int prev_hour = t->tm_hour;
    if (t->tm_min == 0) prev_hour = (prev_hour + 23) % 24;
    s_old_hour_angle = ((prev_hour % 12) * TRIG_MAX_ANGLE / 12) +
                       (prev_min * TRIG_MAX_ANGLE / 12 / 60);
    s_old_min_angle  = (prev_min * TRIG_MAX_ANGLE / 60);

    // New angles: current minute's positions
    s_new_hour_angle = ((t->tm_hour % 12) * TRIG_MAX_ANGLE / 12) +
                       (t->tm_min * TRIG_MAX_ANGLE / 12 / 60);
    s_new_min_angle  = (t->tm_min * TRIG_MAX_ANGLE / 60);

    // Clash at midpoint
    s_clash_angle = compute_clash_angle(s_new_hour_angle, s_new_min_angle);

    // Start from old positions
    s_cur_hour_angle = s_old_hour_angle;
    s_cur_min_angle  = s_old_min_angle;
    s_anim_state = ANIM_SWING;
    s_anim_frame = 0;
    s_sparks_active = false;

    s_anim_timer = app_timer_register(ANIM_INTERVAL_MS, anim_timer_callback, NULL);
}

static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
    bool should_animate =
        settings.AnimateEvery == ANIMATE_MINUTE ||
        (settings.AnimateEvery == ANIMATE_HOUR && tick_time->tm_min == 0);

    if (should_animate) {
        start_duel_animation(tick_time);
    } else {
        // No animation — just redraw at the new time.
        if (s_canvas_layer) layer_mark_dirty(s_canvas_layer);
    }

    // Regenerate starfield every hour
    if (tick_time->tm_min == 0) {
        init_stars(s_center.x * 2, s_center.y * 2);
    }

    update_time();
}

// ============================================================================
// APP MESSAGE / CLAY SETTINGS INBOX
// ============================================================================

static void inbox_received_callback(DictionaryIterator *iterator, void *context) {
    bool changed = false;

    Tuple *animate_t = dict_find(iterator, MESSAGE_KEY_AnimateEvery);
    if (animate_t) {
        // Clay sends select values as cstrings.
        const char *v = animate_t->value->cstring;
        AnimateMode m = settings.AnimateEvery;
        if (v) {
            if (strcmp(v, "minute") == 0)      m = ANIMATE_MINUTE;
            else if (strcmp(v, "hour") == 0)   m = ANIMATE_HOUR;
            else if (strcmp(v, "none") == 0)   m = ANIMATE_NEVER;
        }
        if (m != settings.AnimateEvery) {
            settings.AnimateEvery = m;
            changed = true;
        }
    }

    Tuple *sounds_t = dict_find(iterator, MESSAGE_KEY_PlaySounds);
    if (sounds_t) {
        bool v = sounds_t->value->int32 == 1;
        if (v != settings.PlaySounds) {
            settings.PlaySounds = v;
            changed = true;
        }
    }

    Tuple *volume_t = dict_find(iterator, MESSAGE_KEY_Volume);
    if (volume_t) {
        // Clay sends select values as cstrings.
        const char *v = volume_t->value->cstring;
        if (v) {
            int parsed = atoi(v);
            if (parsed < 0) parsed = 0;
            if (parsed > 100) parsed = 100;
            if ((uint8_t)parsed != settings.Volume) {
                settings.Volume = (uint8_t)parsed;
                changed = true;
            }
        }
    }

    if (changed) {
        prv_save_settings();
    }
}

// ============================================================================
// BATTERY
// ============================================================================

static void battery_callback(BatteryChargeState state) {
    s_battery_level = state.charge_percent;
    if (s_canvas_layer) {
        layer_mark_dirty(s_canvas_layer);
    }
}

// ============================================================================
// WINDOW HANDLERS
// ============================================================================

static void main_window_load(Window *window) {
    Layer *window_layer = window_get_root_layer(window);
    GRect bounds = layer_get_bounds(window_layer);

    s_center = GPoint(bounds.size.w / 2, bounds.size.h / 2);

    // Platform-specific scaling.
    // Defaults (HOUR_BLADE_LEN etc.) target emery (200x228).
    if (bounds.size.w >= 260) {
        // gabbro (260x260): scale up 120%
        s_cs = 125; // characters 25% bigger
        s_char_offset = CHAR_OFFSET * 5 / 4;
        s_marker_radius = MARKER_RADIUS * 6 / 5;
        s_hour_blade_len = HOUR_BLADE_LEN * 6 / 5;  // 60
        s_min_blade_len = MINUTE_BLADE_LEN * 6 / 5;  // 84
        for (int i = 0; i < 4; i++) {
            s_hour_blade_pts[i].x = s_hour_blade_pts[i].x * 6 / 5;
            s_hour_blade_pts[i].y = s_hour_blade_pts[i].y * 6 / 5;
            s_min_blade_pts[i].x = s_min_blade_pts[i].x * 6 / 5;
            s_min_blade_pts[i].y = s_min_blade_pts[i].y * 6 / 5;
            s_hour_hilt_pts[i].x = s_hour_hilt_pts[i].x * 6 / 5;
            s_hour_hilt_pts[i].y = s_hour_hilt_pts[i].y * 6 / 5;
            s_min_hilt_pts[i].x = s_min_hilt_pts[i].x * 6 / 5;
            s_min_hilt_pts[i].y = s_min_hilt_pts[i].y * 6 / 5;
        }
    } else if (bounds.size.w < 180) {
        // flint and other 144x168 displays: scale down to ~70%.
        s_cs = 70;
        s_char_offset = CHAR_OFFSET * 7 / 10;          // 24
        s_marker_radius = MARKER_RADIUS * 7 / 10;      // 62
        s_hour_blade_len = HOUR_BLADE_LEN * 7 / 10;    // 35
        s_min_blade_len = MINUTE_BLADE_LEN * 7 / 10;   // 49
        for (int i = 0; i < 4; i++) {
            s_hour_blade_pts[i].x = s_hour_blade_pts[i].x * 7 / 10;
            s_hour_blade_pts[i].y = s_hour_blade_pts[i].y * 7 / 10;
            s_min_blade_pts[i].x = s_min_blade_pts[i].x * 7 / 10;
            s_min_blade_pts[i].y = s_min_blade_pts[i].y * 7 / 10;
            s_hour_hilt_pts[i].x = s_hour_hilt_pts[i].x * 7 / 10;
            s_hour_hilt_pts[i].y = s_hour_hilt_pts[i].y * 7 / 10;
            s_min_hilt_pts[i].x = s_min_hilt_pts[i].x * 7 / 10;
            s_min_hilt_pts[i].y = s_min_hilt_pts[i].y * 7 / 10;
        }
    }

    // Initialize stars
    init_stars(bounds.size.w, bounds.size.h);

    // Create GPath objects
    s_hour_blade_path = gpath_create(&s_hour_blade_info);
    s_min_blade_path = gpath_create(&s_min_blade_info);
    s_hour_hilt_path = gpath_create(&s_hour_hilt_info);
    s_min_hilt_path = gpath_create(&s_min_hilt_info);

    // Canvas layer (full screen)
    s_canvas_layer = layer_create(bounds);
    layer_set_update_proc(s_canvas_layer, canvas_update_proc);
    layer_add_child(window_layer, s_canvas_layer);

    // Digital time at top (Star Wars yellow)
    s_time_layer = text_layer_create(GRect(0, 2, bounds.size.w, 30));
    text_layer_set_background_color(s_time_layer, GColorClear);
    text_layer_set_text_color(s_time_layer, COLOR_TIME_TEXT);
    text_layer_set_font(s_time_layer, fonts_get_system_font(FONT_KEY_LECO_26_BOLD_NUMBERS_AM_PM));
    text_layer_set_text_alignment(s_time_layer, GTextAlignmentCenter);
    layer_add_child(window_layer, text_layer_get_layer(s_time_layer));

    // Date at bottom
    s_date_layer = text_layer_create(GRect(0, bounds.size.h - 25, bounds.size.w, 22));
    text_layer_set_background_color(s_date_layer, GColorClear);
    text_layer_set_text_color(s_date_layer, COLOR_DATE_TEXT);
    text_layer_set_font(s_date_layer, fonts_get_system_font(FONT_KEY_GOTHIC_18));
    text_layer_set_text_alignment(s_date_layer, GTextAlignmentCenter);
    layer_add_child(window_layer, text_layer_get_layer(s_date_layer));

    // Initial update
    update_time();
}

static void main_window_unload(Window *window) {
    if (s_anim_timer) { app_timer_cancel(s_anim_timer); s_anim_timer = NULL; }
    s_anim_state = ANIM_IDLE;

    if (s_hour_blade_path) { gpath_destroy(s_hour_blade_path); s_hour_blade_path = NULL; }
    if (s_min_blade_path)  { gpath_destroy(s_min_blade_path);  s_min_blade_path = NULL; }
    if (s_hour_hilt_path)  { gpath_destroy(s_hour_hilt_path);  s_hour_hilt_path = NULL; }
    if (s_min_hilt_path)   { gpath_destroy(s_min_hilt_path);   s_min_hilt_path = NULL; }

    if (s_canvas_layer) { layer_destroy(s_canvas_layer); s_canvas_layer = NULL; }
    if (s_time_layer)   { text_layer_destroy(s_time_layer); s_time_layer = NULL; }
    if (s_date_layer)   { text_layer_destroy(s_date_layer); s_date_layer = NULL; }
}

// ============================================================================
// APPLICATION LIFECYCLE
// ============================================================================

static void init(void) {
    srand(time(NULL));

    prv_load_settings();

    s_main_window = window_create();
    window_set_background_color(s_main_window, COLOR_BG);
    window_set_window_handlers(s_main_window, (WindowHandlers) {
        .load = main_window_load,
        .unload = main_window_unload
    });
    window_stack_push(s_main_window, true);

    tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
    battery_state_service_subscribe(battery_callback);
    s_battery_level = battery_state_service_peek().charge_percent;

    app_message_register_inbox_received(inbox_received_callback);
    app_message_open(256, 256);
}

static void deinit(void) {
    if (s_anim_timer) { app_timer_cancel(s_anim_timer); s_anim_timer = NULL; }
    tick_timer_service_unsubscribe();
    battery_state_service_unsubscribe();
#if defined(PBL_SPEAKER)
    clash_cleanup();
    speaker_stop();
#endif
    if (s_main_window) {
        window_destroy(s_main_window);
        s_main_window = NULL;
    }
}

int main(void) {
    init();
    app_event_loop();
    deinit();
    return 0;
}
