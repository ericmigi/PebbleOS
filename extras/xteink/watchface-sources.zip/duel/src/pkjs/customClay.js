module.exports = function(minified) {
  var clayConfig = this;

  // Platforms with built-in speaker hardware. Add to this list as new
  // speaker-equipped Pebble platforms appear.
  var SPEAKER_PLATFORMS = ['emery', 'flint'];

  var info = clayConfig.meta && clayConfig.meta.activeWatchInfo;
  var platform = info && info.platform;
  var hasSpeaker = platform && SPEAKER_PLATFORMS.indexOf(platform) >= 0;

  clayConfig.on(clayConfig.EVENTS.AFTER_BUILD, function() {
    if (hasSpeaker) return;
    var sounds = clayConfig.getItemByMessageKey('PlaySounds');
    var volume = clayConfig.getItemByMessageKey('Volume');
    if (sounds) sounds.disable();
    if (volume) volume.disable();
  });
};
