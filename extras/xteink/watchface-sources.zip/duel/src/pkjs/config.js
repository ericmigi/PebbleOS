module.exports = [
  {
    "type": "heading",
    "defaultValue": "Lightsaber Duel"
  },
  {
    "type": "text",
    "defaultValue": "Customize when the duel animation plays and whether to play clash sounds."
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Animation"
      },
      {
        "type": "select",
        "messageKey": "AnimateEvery",
        "label": "Show animation",
        "defaultValue": "minute",
        "options": [
          { "label": "Every minute", "value": "minute" },
          { "label": "Every hour",   "value": "hour" },
          { "label": "Never",         "value": "none" }
        ]
      },
      {
        "type": "toggle",
        "messageKey": "PlaySounds",
        "label": "Play sounds during animations",
        "defaultValue": true
      },
      {
        "type": "select",
        "messageKey": "Volume",
        "label": "Volume",
        "defaultValue": "75",
        "options": [
          { "label": "25%",  "value": "25" },
          { "label": "50%",  "value": "50" },
          { "label": "75%",  "value": "75" },
          { "label": "100%", "value": "100" }
        ]
      }
    ]
  },
  {
    "type": "submit",
    "defaultValue": "Save Settings"
  }
];
