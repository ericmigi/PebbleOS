var Clay = require('@rebble/clay');
var clayConfig = require('./config');
var customClay = require('./customClay');
var clay = new Clay(clayConfig, customClay);
