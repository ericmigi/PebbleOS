#ifndef STEPS_H
#define STEPS_H

#include <pebble.h>
#include "config.h"
#include "utils.h"

#define ORIG_STEP_ICON_SIZE 25
#if defined(PBL_PLATFORM_EMERY)
  #define STEP_ICON_SIZE 44
#else
  #define STEP_ICON_SIZE 32
#endif

extern GDrawCommandImage *s_step_icon;
extern char s_step_buffer[20];
extern int step_count;

/*
 * Function Declarations
 */
void draw_steps_info(InfoLayer* info_layer);
void update_step_count();
void load_step_icon();

#endif // STEPS_H