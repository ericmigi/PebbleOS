#include <pebble.h>
#include "config.h"
#include "custom_url.h"

int s_color_theme = 0; // 0 = dark, 1 = light, 2 = auto day/night, 3 = auto quiet time
int s_step_goal = 10000;
int s_temperature_unit = 0;  // 0 = celsius, 1 = fahrenheit
int s_is_day = 1; // 1 = day, 0 = night
int s_enable_animations = 0; // 1 = enabled, 0 = disabled
int s_disconnect_position = 0; // 0 = disabled, 1-4 = UL/UR/LL/LR
int s_enable_weather_forecast = 1; // 1 = enabled, 0 = disabled (default enabled)
int s_weather_forecast_duration = 0; // 0 = 5s, 1 = 10s, 2 = forever, 3 = 15s, 4 = 30s
int s_weather_forecast_flick_mode = 2; // 0 = disabled, 1 = single flick, 2 = double flick
int s_enable_mesh = 1; // 1 = enabled, 0 = disabled
char s_date_format[16] = " %a %d"; // strftime format string for date display
int s_light_show_background = 1; // 1 = show gray box in light theme, 0 = hide
int s_dark_show_border = 1; // 1 = show border in dark theme, 0 = hide
int s_vibrate_on_disconnect = 0; // 0 = disabled, 1 = vibrate on connect/disconnect
int s_light_bg_color = BG_COLOR_WHITE; // Background color for light theme (BgColor enum)
int s_dark_bg_color = BG_COLOR_BLACK; // Background color for dark theme (BgColor enum)

InfoLayer s_info_layers[NUM_INFO_LAYERS];
InfoType s_layer_assignments[NUM_INFO_LAYERS] = {
  INFO_TYPE_WEATHER,      // LAYER_UPPER_LEFT
  INFO_TYPE_TEMPERATURE,  // LAYER_UPPER_RIGHT  
  INFO_TYPE_STEPS,        // LAYER_LOWER_LEFT
  INFO_TYPE_BATTERY       // LAYER_LOWER_RIGHT
};


// Persistent storage functions
void save_theme_to_storage() {
  persist_write_int(PERSIST_KEY_COLOR_THEME, s_color_theme);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved theme to storage: %d", s_color_theme);
}

void load_theme_from_storage() {
  if (persist_exists(PERSIST_KEY_COLOR_THEME)) {
    s_color_theme = persist_read_int(PERSIST_KEY_COLOR_THEME);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded theme from storage: %d", s_color_theme);
  } else {
    // Default to light theme if no preference exists
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No theme preference found, using default light theme");
  }
}

bool is_dark_theme(){
  if(s_color_theme == 0) {
    return true;
  }
  else if(s_color_theme == 2) {
    return s_is_day == 0;
  }
  else if(s_color_theme == 3) {
    return quiet_time_is_active();
  }

  return false;
}

bool is_light_theme(){
  return !is_dark_theme();
}


static int get_active_bg_color() {
  return is_light_theme() ? s_light_bg_color : s_dark_bg_color;
}

// Function to get colors based on theme
GColor get_background_color() {
  int color = get_active_bg_color();
#if defined(PBL_COLOR)
  switch (color) {
    case BG_COLOR_WHITE:  return GColorWhite;
    case BG_COLOR_BLACK:  return GColorBlack;
    case BG_COLOR_RED:    return GColorRed;
    case BG_COLOR_GREEN:  return GColorGreen;
    case BG_COLOR_BLUE:   return GColorBlue;
    case BG_COLOR_YELLOW: return GColorYellow;
    case BG_COLOR_GRAY:   return GColorLightGray;
    // Enum colors without an SDK constant would go through GColorFromHEX here.
    default: return is_light_theme() ? GColorWhite : GColorBlack;
  }
#else
  // On black-and-white displays only pure black and white can be a window
  // background color. Gray is rendered as a dithered fill in draw_frame
  // (see is_bw_gray_background), on top of the theme's base color.
  if (color == BG_COLOR_BLACK) {
    return GColorBlack;
  }
  if (color == BG_COLOR_WHITE) {
    return GColorWhite;
  }
  return is_light_theme() ? GColorWhite : GColorBlack;
#endif
}

bool is_bw_gray_background() {
#if defined(PBL_COLOR)
  return false;
#else
  return get_active_bg_color() == BG_COLOR_GRAY;
#endif
}

GColor get_text_color() {
  return is_light_theme() ? GColorBlack : GColorWhite;
}

void save_step_goal_to_storage() {
  persist_write_int(PERSIST_KEY_STEP_GOAL, s_step_goal);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved step goal to storage: %d", s_step_goal);
}

void load_step_goal_from_storage() {
  if (persist_exists(PERSIST_KEY_STEP_GOAL)) {
    s_step_goal = persist_read_int(PERSIST_KEY_STEP_GOAL);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded step goal from storage: %d", s_step_goal);
  } else {
    // Default to 10000 if no preference exists
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No step goal preference found, using default 10000");
  }
}

void save_temperature_unit_to_storage() {
  persist_write_int(PERSIST_KEY_TEMPERATURE_UNIT, s_temperature_unit);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved temperature unit to storage: %d", s_temperature_unit);
}

void load_temperature_unit_from_storage() {
  if (persist_exists(PERSIST_KEY_TEMPERATURE_UNIT)) {
    s_temperature_unit = persist_read_int(PERSIST_KEY_TEMPERATURE_UNIT);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded temperature unit from storage: %d", s_temperature_unit);
  } else {
    // Default to celsius if no preference exists
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No temperature unit preference found, using default celsius");
  }
}

void save_enable_animations_to_storage() {
  persist_write_int(PERSIST_KEY_ENABLE_ANIMATIONS, s_enable_animations);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved enable animations to storage: %d", s_enable_animations);
}

void load_enable_animations_from_storage() {
  if (persist_exists(PERSIST_KEY_ENABLE_ANIMATIONS)) {
    s_enable_animations = persist_read_int(PERSIST_KEY_ENABLE_ANIMATIONS);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded enable animations from storage: %d", s_enable_animations);
  } else {
    // Default to enabled if no preference exists
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No enable animations preference found, using default enabled");
  }
}

void save_layout_to_storage() {
  persist_write_int(PERSIST_KEY_LAYOUT_UPPER_LEFT, s_layer_assignments[LAYER_UPPER_LEFT]);
  persist_write_int(PERSIST_KEY_LAYOUT_UPPER_RIGHT, s_layer_assignments[LAYER_UPPER_RIGHT]);
  persist_write_int(PERSIST_KEY_LAYOUT_LOWER_LEFT, s_layer_assignments[LAYER_LOWER_LEFT]);
  persist_write_int(PERSIST_KEY_LAYOUT_LOWER_RIGHT, s_layer_assignments[LAYER_LOWER_RIGHT]);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved layout to storage");
}

void load_layout_from_storage() {
  if (persist_exists(PERSIST_KEY_LAYOUT_UPPER_LEFT)) {
    s_layer_assignments[LAYER_UPPER_LEFT] = persist_read_int(PERSIST_KEY_LAYOUT_UPPER_LEFT);
    s_layer_assignments[LAYER_UPPER_RIGHT] = persist_read_int(PERSIST_KEY_LAYOUT_UPPER_RIGHT);
    s_layer_assignments[LAYER_LOWER_LEFT] = persist_read_int(PERSIST_KEY_LAYOUT_LOWER_LEFT);
    s_layer_assignments[LAYER_LOWER_RIGHT] = persist_read_int(PERSIST_KEY_LAYOUT_LOWER_RIGHT);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded layout from storage");
  }
}

void save_disconnect_position_to_storage() {
  persist_write_int(PERSIST_KEY_DISCONNECT_POSITION, s_disconnect_position);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved disconnect position to storage: %d", s_disconnect_position);
}

void load_disconnect_position_from_storage() {
  if (persist_exists(PERSIST_KEY_DISCONNECT_POSITION)) {
    s_disconnect_position = persist_read_int(PERSIST_KEY_DISCONNECT_POSITION);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded disconnect position from storage: %d", s_disconnect_position);
  } else {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No disconnect position preference found, using default disabled");
  }
}


void save_weather_forecast_duration_to_storage() {
  persist_write_int(PERSIST_KEY_WEATHER_FORECAST_DURATION, s_weather_forecast_duration);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved weather forecast duration to storage: %d", s_weather_forecast_duration);
}

void load_weather_forecast_duration_from_storage() {
  if (persist_exists(PERSIST_KEY_WEATHER_FORECAST_DURATION)) {
    s_weather_forecast_duration = persist_read_int(PERSIST_KEY_WEATHER_FORECAST_DURATION);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded weather forecast duration from storage: %d", s_weather_forecast_duration);
  } else {
    s_weather_forecast_duration = 0; // Default to 5s
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No weather forecast duration preference found, using default 5s");
  }
}

void save_weather_forecast_flick_mode_to_storage() {
  persist_write_int(PERSIST_KEY_WEATHER_FORECAST_FLICK_MODE, s_weather_forecast_flick_mode);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved weather forecast flick mode to storage: %d", s_weather_forecast_flick_mode);
}

void load_weather_forecast_flick_mode_from_storage() {
  if (persist_exists(PERSIST_KEY_WEATHER_FORECAST_FLICK_MODE)) {
    s_weather_forecast_flick_mode = persist_read_int(PERSIST_KEY_WEATHER_FORECAST_FLICK_MODE);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded weather forecast flick mode from storage: %d", s_weather_forecast_flick_mode);
  } else {
    s_weather_forecast_flick_mode = 2; // Default to double flick
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No weather forecast flick mode preference found, using default double flick");
  }
}

void save_enable_mesh_to_storage() {
  persist_write_int(PERSIST_KEY_ENABLE_MESH, s_enable_mesh);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved enable mesh to storage: %d", s_enable_mesh);
}

void load_enable_mesh_from_storage() {
  if (persist_exists(PERSIST_KEY_ENABLE_MESH)) {
    s_enable_mesh = persist_read_int(PERSIST_KEY_ENABLE_MESH);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded enable mesh from storage: %d", s_enable_mesh);
  } else {
    s_enable_mesh = 1; // Default to enabled
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No enable mesh preference found, using default enabled");
  }
}

void save_date_format_to_storage() {
  persist_write_string(PERSIST_KEY_DATE_FORMAT, s_date_format);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved date format to storage: %s", s_date_format);
}

void load_date_format_from_storage() {
  if (persist_exists(PERSIST_KEY_DATE_FORMAT)) {
    persist_read_string(PERSIST_KEY_DATE_FORMAT, s_date_format, sizeof(s_date_format));
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded date format from storage: %s", s_date_format);
  } else {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No date format preference found, using default");
  }
}

void save_light_show_background_to_storage() {
  persist_write_int(PERSIST_KEY_LIGHT_SHOW_BACKGROUND, s_light_show_background);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved light show background to storage: %d", s_light_show_background);
}

void load_light_show_background_from_storage() {
  if (persist_exists(PERSIST_KEY_LIGHT_SHOW_BACKGROUND)) {
    s_light_show_background = persist_read_int(PERSIST_KEY_LIGHT_SHOW_BACKGROUND);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded light show background from storage: %d", s_light_show_background);
  } else {
    s_light_show_background = 1; // Default to enabled
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No light show background preference found, using default enabled");
  }
}

void save_dark_show_border_to_storage() {
  persist_write_int(PERSIST_KEY_DARK_SHOW_BORDER, s_dark_show_border);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved dark show border to storage: %d", s_dark_show_border);
}

void load_dark_show_border_from_storage() {
  if (persist_exists(PERSIST_KEY_DARK_SHOW_BORDER)) {
    s_dark_show_border = persist_read_int(PERSIST_KEY_DARK_SHOW_BORDER);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded dark show border from storage: %d", s_dark_show_border);
  } else {
    s_dark_show_border = 1; // Default to enabled
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No dark show border preference found, using default enabled");
  }
}

void save_bg_colors_to_storage() {
  persist_write_int(PERSIST_KEY_LIGHT_BG_COLOR, s_light_bg_color);
  persist_write_int(PERSIST_KEY_DARK_BG_COLOR, s_dark_bg_color);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved background colors to storage: %d / %d", s_light_bg_color, s_dark_bg_color);
}

void load_bg_colors_from_storage() {
  if (persist_exists(PERSIST_KEY_LIGHT_BG_COLOR)) {
    s_light_bg_color = persist_read_int(PERSIST_KEY_LIGHT_BG_COLOR);
  }
  if (persist_exists(PERSIST_KEY_DARK_BG_COLOR)) {
    s_dark_bg_color = persist_read_int(PERSIST_KEY_DARK_BG_COLOR);
  }
  if (s_light_bg_color < BG_COLOR_WHITE || s_light_bg_color > BG_COLOR_GRAY) {
    s_light_bg_color = BG_COLOR_WHITE;
  }
  if (s_dark_bg_color < BG_COLOR_WHITE || s_dark_bg_color > BG_COLOR_GRAY) {
    s_dark_bg_color = BG_COLOR_BLACK;
  }
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded background colors from storage: %d / %d", s_light_bg_color, s_dark_bg_color);
}

void save_vibrate_on_disconnect_to_storage() {
  persist_write_int(PERSIST_KEY_VIBRATE_ON_DISCONNECT, s_vibrate_on_disconnect);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved vibrate on disconnect to storage: %d", s_vibrate_on_disconnect);
}

void load_vibrate_on_disconnect_from_storage() {
  if (persist_exists(PERSIST_KEY_VIBRATE_ON_DISCONNECT)) {
    s_vibrate_on_disconnect = persist_read_int(PERSIST_KEY_VIBRATE_ON_DISCONNECT);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded vibrate on disconnect from storage: %d", s_vibrate_on_disconnect);
  } else {
    s_vibrate_on_disconnect = 0; // Default to disabled
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No vibrate on disconnect preference found, using default disabled");
  }
}

time_t s_custom_data_last_received = 0;

void save_custom_lines_to_storage() {
  persist_write_string(PERSIST_KEY_CUSTOM_LINE_1, s_custom_line1);
  persist_write_string(PERSIST_KEY_CUSTOM_LINE_2, s_custom_line2);
  persist_write_int(PERSIST_KEY_CUSTOM_DATA_TIMESTAMP, (int)s_custom_data_last_received);
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Saved custom lines to storage: %s | %s", s_custom_line1, s_custom_line2);
}

void load_custom_lines_from_storage() {
  if (persist_exists(PERSIST_KEY_CUSTOM_LINE_1)) {
    persist_read_string(PERSIST_KEY_CUSTOM_LINE_1, s_custom_line1, sizeof(s_custom_line1));
    persist_read_string(PERSIST_KEY_CUSTOM_LINE_2, s_custom_line2, sizeof(s_custom_line2));
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Loaded custom lines from storage: %s | %s", s_custom_line1, s_custom_line2);
  } else {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "No custom lines found in storage, using defaults");
  }
  if (persist_exists(PERSIST_KEY_CUSTOM_DATA_TIMESTAMP)) {
    s_custom_data_last_received = (time_t)persist_read_int(PERSIST_KEY_CUSTOM_DATA_TIMESTAMP);
  }
}
