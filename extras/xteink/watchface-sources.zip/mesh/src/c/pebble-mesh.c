#include <pebble.h>
#include "config.h"
#include "utils.h"
#include "weather.h"
#include "steps.h"
#include "battery.h"
#include "calendar.h"
#include "disconnect.h"
#include "heart_rate.h"
#include "weather_forecast.h"
#include "custom_url.h"



// A pointer to the main window and layers
static Window *s_main_window;
static Layer *s_time_layer;
static Layer *s_date_layer;
static Layer *s_frame_layer;
static Layer *s_animation_layer;

// Pointer for the animation AppTimer
#define GRID_SIZE 8
#define CROSS_SIZE 0

#define ANIMATION_FRAMES 5 // number of screen refreshes for the time type-in
#define ANIMATION_RATE_MS 100 // interval between type-in refreshes
#define ANIMATION_FIRST_DELAY_MS 300 // beat before type-in starts, so the time is briefly visible

#define BORDER_THICKNESS 3

// Double-flick detection for weather detail screen
#define DOUBLE_FLICK_WINDOW_MS 1500

// How old phone-fetched data (weather, custom URL) may get before a window
// re-appearance triggers a new request. Matches the phone's own 30-minute
// refresh interval. Without this check, every return from a notification or
// app re-requested everything (GPS fix + HTTP + Bluetooth), which drains
// both batteries for users who get frequent notifications.
#define DATA_MAX_AGE_SECONDS (30 * 60)

static uint32_t s_last_tap_time = 0;

// Animation
static AppTimer *s_animation_timer = NULL;
static int s_animation_refreshes_left = 0; // ANIMATION_FRAMES down to 0
static bool s_last_was_dark = false;

// Cached rendering of the frame layer (background, border, mesh). The frame
// only changes with theme/config, but its update proc runs on every render
// pass (every minute plus every animation frame), so drawing the mesh
// dot-by-dot each time wastes battery. Instead the frame is drawn once,
// captured from the framebuffer into this bitmap, and blitted afterwards.
// If the allocation fails (low heap) it stays NULL and the frame is simply
// drawn directly every pass, as before.
static GBitmap *s_frame_cache = NULL;
static bool s_frame_cache_valid = false;
static int s_last_connected = -1; // -1 = unknown (init), 0 = disconnected, 1 = connected
static bool s_is_vibrating = false;

// Buffer to hold the time string (e.g., "12:34" or "23:59")
static char s_time_buffer[9];
static char s_date_buffer[20];

// Forward declarations
static void update_time();
static void battery_handler(BatteryChargeState state);
static void tick_handler(struct tm *tick_time, TimeUnits units_changed);
static void animation_timer_callback(void *data);
static void try_start_animation_timer();
static void try_stop_animation_timer();
static void draw_frame(Layer *layer, GContext *ctx);
static void invalidate_frame_cache();
static void draw_animation(Layer *layer, GContext *ctx);
static void draw_time(Layer *layer, GContext *ctx);
static void draw_date(Layer *layer, GContext *ctx);
static void inbox_received_callback(DictionaryIterator *iterator, void *context);
static void delayed_weather_request(void *data);
static void delayed_custom_url_request(void *data);
static void init_info_layers(GRect bounds);
static void update_all_info_layers();
static void draw_info_for_type(InfoType info_type, InfoLayer* info_layer);
static void clear_info_layer(InfoLayer* info_layer);
static void bluetooth_connection_handler(bool connected);
static void tap_handler(AccelAxisType axis, int32_t direction);


// Function to update all colors based on current theme
static void update_colors() {
  // The display now reflects this theme. Tracking it here (rather than at each
  // call site) keeps tick_handler from detecting a "change" that this pass has
  // already applied and repeating the whole thing a minute later.
  s_last_was_dark = is_dark_theme();

  window_set_background_color(s_main_window, get_background_color());
  // window_set_background_color() is a no-op in the firmware when the color is
  // unchanged (white is the window default), so force a full repaint explicitly
  layer_mark_dirty(window_get_root_layer(s_main_window));

  layer_mark_dirty(s_time_layer);
  layer_mark_dirty(s_date_layer);

  // Recreate PDC icons for new theme
  load_weather_icon();
  load_step_icon();
  load_calendar_icon();
  load_battery_icon();
  load_disconnect_icon();
  load_heart_icon();

  // Update all info layers to refresh the display
  update_all_info_layers();

  // Force redraw
  invalidate_frame_cache();
  layer_mark_dirty(s_animation_layer);
}

// --- Weather Functions ---
static void inbox_received_callback(DictionaryIterator *iterator, void *context) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Message received");

  bool weather_data_updated = false;
  // A single message can carry several settings that each require rebuilding
  // the info layers. Rebuilding tears down and recreates every quadrant, so
  // collect the need in this flag and rebuild once at the end instead.
  bool info_layers_need_update = false;

  // Read temperature unit first to know what symbol to use
  Tuple *temp_unit_tuple = dict_find(iterator, MESSAGE_KEY_TEMPERATURE_UNIT);
  if (temp_unit_tuple) {
    int new_unit = (int)temp_unit_tuple->value->int32;
    if (new_unit != s_temperature_unit) {
      s_temperature_unit = new_unit;
      save_temperature_unit_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Temperature unit changed to: %d", s_temperature_unit);
      weather_data_updated = true;
    }
  }

  // Read temperature
  Tuple *temperature_tuple = dict_find(iterator, MESSAGE_KEY_WEATHER_TEMPERATURE);
  if (temperature_tuple) {
    const char* unit_symbol = s_temperature_unit == 1 ? "°F" : "°C";
    snprintf(s_temperature_buffer, sizeof(s_temperature_buffer), "%s%s", temperature_tuple->value->cstring, unit_symbol);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Temperature: %s", s_temperature_buffer);
    // Live weather from the phone - remember when, so window re-appearances
    // don't re-request data that is still fresh
    s_weather_last_received = time(NULL);
    weather_data_updated = true;
  }

  // Read location
  Tuple *location_tuple = dict_find(iterator, MESSAGE_KEY_WEATHER_LOCATION);
  if (location_tuple) {
    snprintf(s_location_buffer, sizeof(s_location_buffer), "%s", location_tuple->value->cstring);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Location: %s", s_location_buffer);
    weather_data_updated = true;
  }

  // Read weather condition and update icon
  Tuple *condition_tuple = dict_find(iterator, MESSAGE_KEY_WEATHER_CONDITION);
  if (condition_tuple) {
    s_current_weather_code = (int)condition_tuple->value->int32;
    // Recreate weather icon with new weather code
    load_weather_icon();
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Weather condition: %d", s_current_weather_code);
    weather_data_updated = true;
  }

  // Read is_day. It arrives with every weather push (every 30 minutes), so
  // only react when the value actually flipped - a full update_colors() pass
  // reloads all icons, drops the frame cache and rebuilds every quadrant.
  Tuple *is_day_tuple = dict_find(iterator, MESSAGE_KEY_WEATHER_IS_DAY);
  if (is_day_tuple) {
    int new_is_day = (int)is_day_tuple->value->int32;
    if (new_is_day != s_is_day) {
      s_is_day = new_is_day;
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Is day changed to: %d", s_is_day);
      weather_data_updated = true; // persist the new value
      if (s_color_theme == 2) {
        // Dynamic day/night theme follows is_day - switch the whole theme
        update_colors();
      } else {
        // Only the day/night variant of the weather icon depends on is_day
        load_weather_icon();
      }
    }
  }

  // Read color theme
  Tuple *theme_tuple = dict_find(iterator, MESSAGE_KEY_COLOR_THEME);
  if (theme_tuple) {
    int new_theme = (int)theme_tuple->value->int32;
    if (new_theme != s_color_theme) {
      s_color_theme = new_theme;
      save_theme_to_storage(); // Save the new theme preference
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Color theme changed to: %d", s_color_theme);
      update_colors();
    }
  }

  // Read step goal
  Tuple *step_goal_tuple = dict_find(iterator, MESSAGE_KEY_STEP_GOAL);
  if (step_goal_tuple) {
    int new_step_goal = (int)step_goal_tuple->value->int32;
    if (new_step_goal > 0 && new_step_goal != s_step_goal) {
      s_step_goal = new_step_goal;
      save_step_goal_to_storage(); // Save the new step goal preference
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Step goal changed to: %d", s_step_goal);
      // Redraw steps info layer to update the progress bar
      info_layers_need_update = true;
    }
  }

  // Save weather data to persistent storage if any was updated
  if (weather_data_updated) {
    save_weather_to_storage();
    // Redraw all info layers to show updated weather data
    info_layers_need_update = true;
  }

  // Read forecast data (now, +1d, +2d)
  Tuple *fc_temp1 = dict_find(iterator, MESSAGE_KEY_FORECAST_TEMP_1);
  Tuple *fc_temp2 = dict_find(iterator, MESSAGE_KEY_FORECAST_TEMP_2);
  Tuple *fc_temp3 = dict_find(iterator, MESSAGE_KEY_FORECAST_TEMP_3);
  Tuple *fc_cond1 = dict_find(iterator, MESSAGE_KEY_FORECAST_CONDITION_1);
  Tuple *fc_cond2 = dict_find(iterator, MESSAGE_KEY_FORECAST_CONDITION_2);
  Tuple *fc_cond3 = dict_find(iterator, MESSAGE_KEY_FORECAST_CONDITION_3);
  if (fc_temp1) s_forecast[0].temperature = (int)fc_temp1->value->int32;
  if (fc_temp2) s_forecast[1].temperature = (int)fc_temp2->value->int32;
  if (fc_temp3) s_forecast[2].temperature = (int)fc_temp3->value->int32;
  if (fc_cond1) s_forecast[0].condition_code = (int)fc_cond1->value->int32;
  if (fc_cond2) s_forecast[1].condition_code = (int)fc_cond2->value->int32;
  if (fc_cond3) s_forecast[2].condition_code = (int)fc_cond3->value->int32;
  if (fc_temp1 || fc_cond1) {
    weather_forecast_update_icons();
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Forecast updated: %d/%d %d/%d %d/%d",
            s_forecast[0].temperature, s_forecast[0].condition_code,
            s_forecast[1].temperature, s_forecast[1].condition_code,
            s_forecast[2].temperature, s_forecast[2].condition_code);
  }

  // Read hourly forecast data for bottom bar graph
  Tuple *hourly_temps_tuple = dict_find(iterator, MESSAGE_KEY_HOURLY_TEMPS);
  if (hourly_temps_tuple) {
    weather_forecast_parse_hourly_temps(hourly_temps_tuple->value->cstring);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Hourly temps received: %s", hourly_temps_tuple->value->cstring);
  }
  Tuple *hourly_precip_tuple = dict_find(iterator, MESSAGE_KEY_HOURLY_PRECIP);
  if (hourly_precip_tuple) {
    weather_forecast_parse_hourly_precip(hourly_precip_tuple->value->cstring);
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Hourly precip received: %s", hourly_precip_tuple->value->cstring);
  }

  // Read enable animations
  Tuple *enable_animations_tuple = dict_find(iterator, MESSAGE_KEY_ENABLE_ANIMATIONS);
  if (enable_animations_tuple) {
    int new_enable_animations = (int)enable_animations_tuple->value->int32;
    if (new_enable_animations != s_enable_animations) {
      s_enable_animations = new_enable_animations;
      save_enable_animations_to_storage();
      try_start_animation_timer();
    }
  }

  // Read weather detail duration
  Tuple *forecast_duration_tuple = dict_find(iterator, MESSAGE_KEY_WEATHER_FORECAST_DURATION);
  if (forecast_duration_tuple) {
    int new_duration = (int)forecast_duration_tuple->value->int32;
    if (new_duration != s_weather_forecast_duration) {
      s_weather_forecast_duration = new_duration;
      save_weather_forecast_duration_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Weather forecast duration changed to: %d", s_weather_forecast_duration);
    }
  }

  // Read weather detail flick mode
  Tuple *flick_mode_tuple = dict_find(iterator, MESSAGE_KEY_WEATHER_FORECAST_FLICK_MODE);
  if (flick_mode_tuple) {
    int new_flick_mode = (int)flick_mode_tuple->value->int32;
    if (new_flick_mode != s_weather_forecast_flick_mode) {
      s_weather_forecast_flick_mode = new_flick_mode;
      save_weather_forecast_flick_mode_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Weather forecast flick mode changed to: %d", s_weather_forecast_flick_mode);
    }
  }

  // Read date format
  Tuple *date_format_tuple = dict_find(iterator, MESSAGE_KEY_DATE_FORMAT);
  if (date_format_tuple) {
    const char *new_fmt = date_format_tuple->value->cstring;
    if (strcmp(new_fmt, s_date_format) != 0) {
      snprintf(s_date_format, sizeof(s_date_format), "%s", new_fmt);
      save_date_format_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Date format changed to: %s", s_date_format);
      update_time();
    }
  }

  // Read enable mesh
  Tuple *enable_mesh_tuple = dict_find(iterator, MESSAGE_KEY_ENABLE_MESH);
  if (enable_mesh_tuple) {
    int new_enable_mesh = (int)enable_mesh_tuple->value->int32;
    if (new_enable_mesh != s_enable_mesh) {
      s_enable_mesh = new_enable_mesh;
      save_enable_mesh_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Enable mesh changed to: %d", s_enable_mesh);
      invalidate_frame_cache();
    }
  }

  // Read light theme show background
  Tuple *light_bg_tuple = dict_find(iterator, MESSAGE_KEY_LIGHT_SHOW_BACKGROUND);
  if (light_bg_tuple) {
    int new_val = (int)light_bg_tuple->value->int32;
    if (new_val != s_light_show_background) {
      s_light_show_background = new_val;
      save_light_show_background_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Light show background changed to: %d", s_light_show_background);
      invalidate_frame_cache();
    }
  }

  // Read dark theme show border
  Tuple *dark_border_tuple = dict_find(iterator, MESSAGE_KEY_DARK_SHOW_BORDER);
  if (dark_border_tuple) {
    int new_val = (int)dark_border_tuple->value->int32;
    if (new_val != s_dark_show_border) {
      s_dark_show_border = new_val;
      save_dark_show_border_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Dark show border changed to: %d", s_dark_show_border);
      invalidate_frame_cache();
    }
  }

  // Read vibrate on disconnect
  Tuple *vibrate_tuple = dict_find(iterator, MESSAGE_KEY_VIBRATE_ON_DISCONNECT);
  if (vibrate_tuple) {
    int new_val = (int)vibrate_tuple->value->int32;
    if (new_val != s_vibrate_on_disconnect) {
      s_vibrate_on_disconnect = new_val;
      save_vibrate_on_disconnect_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Vibrate on disconnect changed to: %d", s_vibrate_on_disconnect);
    }
  }

  // Read background colors for light and dark theme
  Tuple *light_bg_color_tuple = dict_find(iterator, MESSAGE_KEY_LIGHT_BG_COLOR_ENUM);
  Tuple *dark_bg_color_tuple = dict_find(iterator, MESSAGE_KEY_DARK_BG_COLOR_ENUM);
  bool bg_colors_changed = false;
  if (light_bg_color_tuple && (int)light_bg_color_tuple->value->int32 != s_light_bg_color) {
    s_light_bg_color = (int)light_bg_color_tuple->value->int32;
    bg_colors_changed = true;
  }
  if (dark_bg_color_tuple && (int)dark_bg_color_tuple->value->int32 != s_dark_bg_color) {
    s_dark_bg_color = (int)dark_bg_color_tuple->value->int32;
    bg_colors_changed = true;
  }
  if (bg_colors_changed) {
    save_bg_colors_to_storage();
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Background colors changed to: %d / %d", s_light_bg_color, s_dark_bg_color);
    update_colors();
  }

  // Read custom data lines (extracted on the phone from the user-configured URL)
  Tuple *custom_line1_tuple = dict_find(iterator, MESSAGE_KEY_CUSTOM_LINE_1);
  Tuple *custom_line2_tuple = dict_find(iterator, MESSAGE_KEY_CUSTOM_LINE_2);
  if (custom_line1_tuple || custom_line2_tuple) {
    if (custom_line1_tuple) {
      snprintf(s_custom_line1, sizeof(s_custom_line1), "%s", custom_line1_tuple->value->cstring);
    }
    if (custom_line2_tuple) {
      snprintf(s_custom_line2, sizeof(s_custom_line2), "%s", custom_line2_tuple->value->cstring);
    }
    s_custom_data_stale = false;
    s_custom_data_last_received = time(NULL);
    save_custom_lines_to_storage();
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Custom lines updated: %s | %s", s_custom_line1, s_custom_line2);
    info_layers_need_update = true;
  }

  // Custom URL error (e.g. non-HTTPS URL) - keep last good value but mark it stale
  Tuple *custom_data_error_tuple = dict_find(iterator, MESSAGE_KEY_CUSTOM_DATA_ERROR);
  if (custom_data_error_tuple) {
    s_custom_data_stale = true;
    APP_LOG(APP_LOG_LEVEL_WARNING, "Custom data error received, marking data as stale");
    info_layers_need_update = true;
  }

  // Read disconnect position
  Tuple *disconnect_pos_tuple = dict_find(iterator, MESSAGE_KEY_DISCONNECT_POSITION);
  if (disconnect_pos_tuple) {
    int new_disconnect_position = (int)disconnect_pos_tuple->value->int32;
    if (new_disconnect_position != s_disconnect_position) {
      s_disconnect_position = new_disconnect_position;
      save_disconnect_position_to_storage();
      APP_LOG(APP_LOG_LEVEL_DEBUG, "Disconnect position changed to: %d", s_disconnect_position);
      info_layers_need_update = true;
    }
  }

  // Read layout assignments
  Tuple *layout_ul = dict_find(iterator, MESSAGE_KEY_LAYOUT_UPPER_LEFT);
  Tuple *layout_ur = dict_find(iterator, MESSAGE_KEY_LAYOUT_UPPER_RIGHT);
  Tuple *layout_ll = dict_find(iterator, MESSAGE_KEY_LAYOUT_LOWER_LEFT);
  Tuple *layout_lr = dict_find(iterator, MESSAGE_KEY_LAYOUT_LOWER_RIGHT);
  if (layout_ul || layout_ur || layout_ll || layout_lr) {
    if (layout_ul) s_layer_assignments[LAYER_UPPER_LEFT] = (InfoType)layout_ul->value->int32;
    if (layout_ur) s_layer_assignments[LAYER_UPPER_RIGHT] = (InfoType)layout_ur->value->int32;
    if (layout_ll) s_layer_assignments[LAYER_LOWER_LEFT] = (InfoType)layout_ll->value->int32;
    if (layout_lr) s_layer_assignments[LAYER_LOWER_RIGHT] = (InfoType)layout_lr->value->int32;
    save_layout_to_storage();
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Layout updated: %d %d %d %d",
            s_layer_assignments[0], s_layer_assignments[1],
            s_layer_assignments[2], s_layer_assignments[3]);
    info_layers_need_update = true;
  }

  // Rebuild the info layers once for everything above. update_colors() (theme,
  // day/night, background color changes) already rebuilds them itself.
  if (info_layers_need_update) {
    update_all_info_layers();
  }
}

// --- Update Time Function ---

// Repaint only the quadrants whose content update_time() rewrites (steps,
// heart rate, calendar day). Their text layers point at static buffers, so
// rewriting the buffer alone doesn't schedule a redraw - and dirtying the
// full-screen frame layer instead forces a whole-display refresh every
// minute, which wastes battery.
static void mark_time_dependent_info_layers_dirty() {
  for (int i = 0; i < NUM_INFO_LAYERS; i++) {
    InfoType type = s_layer_assignments[i];
    if (s_info_layers[i].layer &&
        (type == INFO_TYPE_STEPS || type == INFO_TYPE_HEART_RATE || type == INFO_TYPE_CALENDAR)) {
      layer_mark_dirty(s_info_layers[i].layer);
    }
  }
}

static void update_time() {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Update time");
  time_t temp = time(NULL);
  struct tm *tick_time = localtime(&temp);

  // Use strftime to get the time in the user's 12h or 24h format
  if (clock_is_24h_style()) {
    strftime(s_time_buffer, sizeof(s_time_buffer), "%H:%M", tick_time);
  } else {
    strftime(s_time_buffer, sizeof(s_time_buffer), "%I:%M", tick_time);
  }

  layer_mark_dirty(s_time_layer);

  if (strftime(s_date_buffer, sizeof(s_date_buffer), s_date_format, tick_time) == 0) {
    // Directly show the text of the date format -- e.g. its just a text
    snprintf(s_date_buffer, sizeof(s_date_buffer), "%s", s_date_format);
  }
  layer_mark_dirty(s_date_layer);

  update_step_count();
  update_heart_rate();
  update_day();
  mark_time_dependent_info_layers_dirty();
}

// --- Battery Handler ---
static void battery_handler(BatteryChargeState state) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Battery handler");
  battery_level = state.charge_percent;
  snprintf(s_battery_buffer, sizeof(s_battery_buffer), "%d%%", battery_level);
  
  // Update info layers to reflect new battery level
  update_all_info_layers();
}

/**
 * @brief Stops the animation timer and resets the refresh counter.
 */
static void try_stop_animation_timer() {
  if (s_animation_timer) {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Stop animation timer");
    app_timer_cancel(s_animation_timer);
    s_animation_timer = NULL;
  }

  s_animation_refreshes_left = 0;
}

/**
 * @brief Starts the animation timer if it's not already running.
 */
static void try_start_animation_timer() {
  if (s_animation_timer) {
    return; // already running
  }

  if (s_enable_animations == 0) {
    // Animations disabled - show the time in full, no type-in
    s_animation_refreshes_left = 0;
    layer_mark_dirty(s_time_layer);
    return;
  }

  APP_LOG(APP_LOG_LEVEL_DEBUG, "Start animation timer");
  s_animation_refreshes_left = ANIMATION_FRAMES;
  s_animation_timer = app_timer_register(ANIMATION_FIRST_DELAY_MS, animation_timer_callback, NULL);
}

/**
 * @brief AppTimer callback that triggers one type-in refresh and reschedules itself.
 */
static void animation_timer_callback(void *data) {
  s_animation_timer = NULL;
  s_animation_refreshes_left -= 1;

  APP_LOG(APP_LOG_LEVEL_DEBUG, "Animation refreshes left: %d", s_animation_refreshes_left);

  // Only the time changes during the animation - the date and lines
  // are already fully drawn, so don't waste redraws on them
  layer_mark_dirty(s_time_layer);

  // Reschedule the timer for the next refresh, creating a short type-in
  if (s_animation_refreshes_left > 0) {
    s_animation_timer = app_timer_register(ANIMATION_RATE_MS, animation_timer_callback, NULL);
  }
}


/**
 * @brief Marks the cached frame bitmap stale so the next render pass redraws
 * the frame from scratch (and re-captures it). Call whenever anything the
 * frame depends on changes: theme, background color, mesh/border/box config.
 */
static void invalidate_frame_cache() {
  s_frame_cache_valid = false;
  if (s_frame_layer) {
    layer_mark_dirty(s_frame_layer);
  }
}

/**
 * @brief Copies the just-rendered frame from the framebuffer into
 * s_frame_cache so later passes can blit it instead of redrawing.
 * Safe to call only from draw_frame, right after drawing, while the frame
 * layer is the only thing rendered so far (it is the bottom layer).
 */
static void frame_cache_store(GContext *ctx) {
  GBitmap *fb = graphics_capture_frame_buffer(ctx);
  if (!fb) {
    return;
  }

  GRect fb_bounds = gbitmap_get_bounds(fb);
  if (!s_frame_cache) {
    s_frame_cache = gbitmap_create_blank(fb_bounds.size, gbitmap_get_format(fb));
  }

  if (s_frame_cache) {
    uint8_t *src = gbitmap_get_data(fb);
    uint8_t *dst = gbitmap_get_data(s_frame_cache);
    uint16_t src_stride = gbitmap_get_bytes_per_row(fb);
    uint16_t dst_stride = gbitmap_get_bytes_per_row(s_frame_cache);
    uint16_t copy_bytes = src_stride < dst_stride ? src_stride : dst_stride;
    for (int y = 0; y < fb_bounds.size.h; y++) {
      memcpy(dst + y * dst_stride, src + y * src_stride, copy_bytes);
    }
    s_frame_cache_valid = true;
  } else {
    APP_LOG(APP_LOG_LEVEL_WARNING, "Frame cache alloc failed, drawing frame directly");
  }

  graphics_release_frame_buffer(ctx, fb);
}

// --- Frame Layer Drawing Update Procedure (Modified for Line Fly-In) ---
static void draw_frame(Layer *layer, GContext *ctx) {
  GRect bounds = layer_get_bounds(layer);

  // Fast path: blit the cached frame instead of redrawing it
  if (s_frame_cache_valid && s_frame_cache) {
    graphics_context_set_compositing_mode(ctx, GCompOpAssign);
    graphics_draw_bitmap_in_rect(ctx, s_frame_cache, bounds);
    return;
  }

  GColor frame_color = get_text_color(); // Use theme-appropriate color

  // Paint the background ourselves instead of relying on the window
  // background color: when the firmware hands the screen back to the
  // watchface (system overlays, settings, quiet time toggle) it may redraw
  // only the dirty layers over a black framebuffer, see #27
  graphics_context_set_fill_color(ctx, get_background_color());
  graphics_fill_rect(ctx, bounds, 0, GCornerNone);

  // On black-and-white displays a gray background is not possible as window
  // background color, so draw it as a dithered 50% gray fill instead
  if (is_bw_gray_background()) {
    graphics_context_set_fill_color(ctx, GColorLightGray);
    graphics_fill_rect(ctx, bounds, 0, GCornerNone);
  }

  // In case we have dark theme, we draw a border frame
  if(BORDER_THICKNESS > 0 && is_dark_theme() && s_dark_show_border) {
    graphics_context_set_stroke_color(ctx, frame_color);
    graphics_context_set_stroke_width(ctx, BORDER_THICKNESS);
    graphics_draw_rect(ctx, GRect(1, 1, bounds.size.w - 2, bounds.size.h - 2));
  }

  // In case we have light theme, we draw a gray rectangle in the middle
  if(is_light_theme() && s_light_show_background) {
    graphics_context_set_fill_color(ctx, GColorLightGray);
    
    // We draw the rectange exactly from the upper to the lower animated line in  the same length
    const int max_line_length = bounds.size.w * 0.8;
    const int line_x_start_full = (bounds.size.w - max_line_length) / 2;
    const int time_y = bounds.size.h / 2;
#if defined(PBL_PLATFORM_EMERY)
    const int line_y_upper = time_y - 41;
    const int line_y_lower = time_y + 41;
#else
    const int line_y_upper = time_y - 30;
    const int line_y_lower = time_y + 30;
#endif

    graphics_fill_rect(ctx, GRect(line_x_start_full, line_y_upper + 4, max_line_length, line_y_lower - line_y_upper - 7), 0, GCornerNone);
  }

  // Dots (mesh pattern)
  if (s_enable_mesh) {
    graphics_context_set_stroke_color(ctx, frame_color);
    graphics_context_set_stroke_width(ctx, 1);
    for (int y = 0; y < bounds.size.h; y += GRID_SIZE) {
      for (int x = 0; x < bounds.size.w; x += GRID_SIZE) {
        // 1. Draw the horizontal part of the cross
        // Starts at x - CROSS_SIZE and ends at x + CROSS_SIZE, centered on y
        graphics_draw_line(
            ctx,
            GPoint(x - CROSS_SIZE, y),
            GPoint(x + CROSS_SIZE, y));

        // 2. Draw the vertical part of the cross
        // Starts at y - CROSS_SIZE and ends at y + CROSS_SIZE, centered on x
        graphics_draw_line(
            ctx,
            GPoint(x, y - CROSS_SIZE),
            GPoint(x, y + CROSS_SIZE));
      }
    }
  }

  // The frame layer is the bottom layer, so the framebuffer now holds
  // exactly the frame content - snapshot it for the fast path
  frame_cache_store(ctx);
}

static void draw_animation(Layer *layer, GContext *ctx) {
  GRect bounds = layer_get_bounds(layer);
  GColor color = get_text_color();

  const int max_line_length = bounds.size.w * 0.8;
  const int line_x_start_full = (bounds.size.w - max_line_length) / 2;
  const int line_x_end_full = line_x_start_full + max_line_length;
  const int time_y = bounds.size.h / 2;
#if defined(PBL_PLATFORM_EMERY)
  const int line_y_upper = time_y - 41;
  const int line_y_lower = time_y + 41;
#else
  const int line_y_upper = time_y - 30;
    const int line_y_lower = time_y + 30;
#endif

  // The lines are static - only the time is animated
  graphics_context_set_stroke_color(ctx, color);
  graphics_context_set_stroke_width(ctx, BORDER_THICKNESS);

  graphics_draw_line(ctx,
      GPoint(line_x_start_full, line_y_upper),
      GPoint(line_x_end_full, line_y_upper));
  graphics_draw_line(ctx,
      GPoint(line_x_start_full, line_y_lower),
      GPoint(line_x_end_full, line_y_lower));
}


// --- Draw Time with Outline ---
static void draw_time(Layer *layer, GContext *ctx) {
  GRect bounds = layer_get_bounds(layer);
#if defined(PBL_PLATFORM_EMERY)
  // LECO 60 exists only on newer PebbleOS firmware. Older firmware returns
  // the tiny fallback font for unknown keys, so detect that and use
  // Roboto 49 instead.
  static GFont s_emery_time_font = NULL;
  if (s_emery_time_font == NULL) {
    GFont leco_60 = fonts_get_system_font(FONT_KEY_LECO_60_NUMBERS_AM_PM);
    if (leco_60 == fonts_get_system_font("RESOURCE_ID_NONEXISTENT_FONT")) {
      leco_60 = fonts_get_system_font(FONT_KEY_ROBOTO_BOLD_SUBSET_49);
    }
    s_emery_time_font = leco_60;
  }
  GFont font = s_emery_time_font;
#else
  GFont font = fonts_get_system_font(FONT_KEY_LECO_42_NUMBERS);
#endif
  
  // Calculate animation progress: 0.0 = nothing typed, 1.0 = fully typed
  float animation_factor = 1.0f - ((float)s_animation_refreshes_left / ANIMATION_FRAMES);

  // Typewriter effect: the time is the only animated element
  char display_buffer[9];
  int time_len = strlen(s_time_buffer);
  int chars_to_show = (int)(time_len * animation_factor + 0.5f);
  if (chars_to_show > time_len) chars_to_show = time_len;

  strncpy(display_buffer, s_time_buffer, chars_to_show);
  display_buffer[chars_to_show] = '\0';
  
  // In light mode (and on a dithered gray background) draw an outline
  // around the text for readability
  if (is_light_theme() || is_bw_gray_background()) {
    GColor text_color = get_text_color();
    GColor outline_color = gcolor_equal(text_color, GColorBlack) ? GColorWhite : GColorBlack;

    // Draw outline by drawing the text 4 times with 1-pixel offsets
    graphics_context_set_text_color(ctx, outline_color);

    // Left
    graphics_draw_text(ctx, display_buffer, font,
                      GRect(bounds.origin.x - 1, bounds.origin.y, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
    // Right
    graphics_draw_text(ctx, display_buffer, font,
                      GRect(bounds.origin.x + 1, bounds.origin.y, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
    // Up
    graphics_draw_text(ctx, display_buffer, font,
                      GRect(bounds.origin.x, bounds.origin.y - 1, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
    // Down
    graphics_draw_text(ctx, display_buffer, font,
                      GRect(bounds.origin.x, bounds.origin.y + 1, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);

    // Draw text in center
    graphics_context_set_text_color(ctx, text_color);
    graphics_draw_text(ctx, display_buffer, font,
                      bounds,
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
  } else {
    // Dark mode: just draw white text without outline
    graphics_context_set_text_color(ctx, GColorWhite);
    graphics_draw_text(ctx, display_buffer, font,
                      bounds,
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
  }
}

// --- Draw Date with Outline ---
static void draw_date(Layer *layer, GContext *ctx) {
  GRect bounds = layer_get_bounds(layer);
#if defined(PBL_PLATFORM_EMERY)
  GFont font = fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD);
#else
  GFont font = fonts_get_system_font(FONT_KEY_GOTHIC_18_BOLD);
#endif
  
  // In light mode (and on a dithered gray background) draw an outline
  // around the text for readability
  if (is_light_theme() || is_bw_gray_background()) {
    GColor text_color = get_text_color();
    GColor outline_color = gcolor_equal(text_color, GColorBlack) ? GColorWhite : GColorBlack;

    // Draw outline by drawing the text 4 times with 1-pixel offsets
    graphics_context_set_text_color(ctx, outline_color);

    // Left
    graphics_draw_text(ctx, s_date_buffer, font,
                      GRect(bounds.origin.x - 1, bounds.origin.y, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
    // Right
    graphics_draw_text(ctx, s_date_buffer, font,
                      GRect(bounds.origin.x + 1, bounds.origin.y, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
    // Up
    graphics_draw_text(ctx, s_date_buffer, font,
                      GRect(bounds.origin.x, bounds.origin.y - 1, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
    // Down
    graphics_draw_text(ctx, s_date_buffer, font,
                      GRect(bounds.origin.x, bounds.origin.y + 1, bounds.size.w, bounds.size.h),
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);

    // Draw text in center
    graphics_context_set_text_color(ctx, text_color);
    graphics_draw_text(ctx, s_date_buffer, font,
                      bounds,
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
  } else {
    // Dark mode: just draw white text without outline
    graphics_context_set_text_color(ctx, GColorWhite);
    graphics_draw_text(ctx, s_date_buffer, font,
                      bounds,
                      GTextOverflowModeWordWrap, GTextAlignmentCenter, NULL);
  }
}


// --- Tick Handler ---
static void tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  // Detect dynamic theme changes (e.g., quiet time toggling)
  if (is_dark_theme() != s_last_was_dark) {
    update_colors(); // updates s_last_was_dark itself
  }

  // The type-in animation only plays on window appear (see
  // main_window_appear) - replaying it every minute costs 5 extra display
  // refreshes and timer wakeups per minute, which adds up on battery.
  update_time();
}


// Its simply a box with a border width 3 in the text color
static void draw_colored_box_info(InfoLayer* info_layer) {
  Layer* layer = info_layer->layer;
  // Create a filled rectangle layer
  info_layer->bitmap_layer_1 = bitmap_layer_create(GRect(1, 1, info_layer->bounds.size.w-2, info_layer->bounds.size.h-2));
  bitmap_layer_set_background_color(info_layer->bitmap_layer_1, get_text_color());
  // Add to the info layer
  layer_add_child(layer, bitmap_layer_get_layer(info_layer->bitmap_layer_1));
}

// Generic function to draw info based on type
static void draw_info_for_type(InfoType info_type, InfoLayer* info_layer) {
  switch (info_type) {
    case INFO_TYPE_WEATHER:
      draw_weather_info(info_layer);
      break;
    case INFO_TYPE_TEMPERATURE:
      draw_temperature_info(info_layer);
      break;
    case INFO_TYPE_STEPS:
      draw_steps_info(info_layer);
      break;
    case INFO_TYPE_BATTERY:
      draw_battery_info(info_layer);
      break;
    case INFO_TYPE_CALENDAR:
      draw_calendar_info(info_layer);
      break;
    case INFO_TYPE_DISCONNECT:
      draw_disconnect_info(info_layer);
      break;
    case INFO_TYPE_HEART_RATE:
      draw_heart_rate_info(info_layer);
      break;
    case INFO_TYPE_CUSTOM_URL:
      draw_custom_url_info(info_layer);
      break;
    case INFO_TYPE_COLORED_BOX:
      draw_colored_box_info(info_layer);
      break;
    case INFO_TYPE_NONE:
      // Do nothing for empty layers
      break;
  }
}

// Clear all child layers from an info layer
static void clear_info_layer(InfoLayer* info_layer) {
  if (info_layer->text_layer1) {
    text_layer_destroy(info_layer->text_layer1);
    info_layer->text_layer1 = NULL;
  }
  if (info_layer->text_layer2) {
    text_layer_destroy(info_layer->text_layer2);
    info_layer->text_layer2 = NULL;
  }
  if (info_layer->bitmap_layer_1) {
    bitmap_layer_destroy(info_layer->bitmap_layer_1);
    info_layer->bitmap_layer_1 = NULL;
  }
  if (info_layer->bitmap_layer_2) {
    bitmap_layer_destroy(info_layer->bitmap_layer_2);
    info_layer->bitmap_layer_2 = NULL;
  }
  if (info_layer->bitmap_layer_3) {
    bitmap_layer_destroy(info_layer->bitmap_layer_3);
    info_layer->bitmap_layer_3 = NULL;
  }
  if (info_layer->custom_layer) {
    layer_destroy(info_layer->custom_layer);
    info_layer->custom_layer = NULL;
  }
}

static void vibrate_done_callback(void *data) {
  s_is_vibrating = false;
}

// Vibrate when connection state changes (3 pulses)
static void vibrate_connection_changed() {
  if (!s_vibrate_on_disconnect) {
    return;
  }

  APP_LOG(APP_LOG_LEVEL_DEBUG, "Vibrate on connection change");
  static const uint32_t segments[] = {100, 200, 100, 200, 100};
  VibePattern pattern = {
    .durations = segments,
    .num_segments = ARRAY_LENGTH(segments),
  };
  s_is_vibrating = true;
  vibes_enqueue_custom_pattern(pattern);
  // 100+200+100+200+100 = 700ms + buffer
  app_timer_register(900, vibrate_done_callback, NULL);
}

// Update all info layers according to current assignments
static void update_all_info_layers() {
  bool connected = connection_service_peek_pebble_app_connection();
  
  // Detect connection state change and vibrate
  if (s_last_connected != -1 && (int)connected != s_last_connected) {
    vibrate_connection_changed();
  }
  s_last_connected = (int)connected;

  for (int i = 0; i < NUM_INFO_LAYERS; i++) {
    // Clear existing content first
    clear_info_layer(&s_info_layers[i]);

    // Override with disconnect icon if disconnected and this is the configured position
    // s_disconnect_position: 1=UL, 2=UR, 3=LL, 4=LR (maps to i+1)
    if (!connected && s_disconnect_position > 0 && s_disconnect_position == i + 1) {
      draw_info_for_type(INFO_TYPE_DISCONNECT, &s_info_layers[i]);
    } else {
      draw_info_for_type(s_layer_assignments[i], &s_info_layers[i]);
    }
  }
}

// Bluetooth connection handler
static void bluetooth_connection_handler(bool connected) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Bluetooth connection: %s", connected ? "connected" : "disconnected");
  update_all_info_layers();
}

// Tap/flick handler - configurable: off, single flick, or double flick
static void tap_handler(AccelAxisType axis, int32_t direction) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Tap detected on axis %d", axis);

  // Ignore flicks caused by vibration motor
  if (s_is_vibrating) {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Ignoring tap during vibration");
    return;
  }

  // If flick mode is disabled, ignore flicks entirely
  if (s_weather_forecast_flick_mode == 0) {
    return;
  }

  // Single flick mode
  if (s_weather_forecast_flick_mode == 1) {
    weather_forecast_show();
    return;
  }

  // Double flick mode
  uint32_t now = 0;
  time_t t = time(NULL);
  uint16_t ms = time_ms(NULL, &ms);
  now = (uint32_t)t * 1000 + ms;

  if (s_last_tap_time > 0 && (now - s_last_tap_time) < DOUBLE_FLICK_WINDOW_MS) {
    // Double flick detected
    weather_forecast_show();
    s_last_tap_time = 0;
  } else {
    // First flick — record time
    s_last_tap_time = now;
  }
}

// Timer callback to request weather after UI is loaded
static void delayed_weather_request(void *data) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Requesting weather update (delayed)");
  request_weather_update();
}

// Retry counter for delayed_custom_url_request — file-level so main_window_appear can reset it.
static int s_custom_url_retries = 0;

#define CUSTOM_URL_MAX_RETRIES 8
#define CUSTOM_URL_RETRY_INTERVAL_MS 1500

// Timer callback to request custom URL data after UI is loaded.
// Retries several times if the outbox is still busy (e.g. weather request in flight).
// The outbox can only hold one unacknowledged outgoing message at a time, so this only
// fails transiently while another message (weather, config, ...) is still being delivered.
static void delayed_custom_url_request(void *data) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Requesting custom URL update (delayed, attempt %d)", s_custom_url_retries + 1);
  if (!request_custom_url_update()) {
    if (++s_custom_url_retries < CUSTOM_URL_MAX_RETRIES) {
      app_timer_register(CUSTOM_URL_RETRY_INTERVAL_MS, delayed_custom_url_request, NULL);
    } else {
      APP_LOG(APP_LOG_LEVEL_WARNING, "Custom URL request gave up after %d attempts", CUSTOM_URL_MAX_RETRIES);
      s_custom_data_stale = true;
      update_all_info_layers();
      s_custom_url_retries = 0;
    }
  } else {
    s_custom_url_retries = 0;
  }
}

// Initialize the 4 info layers with proper positioning
static void init_info_layers(GRect bounds) {

  int theme_offset = (is_dark_theme() && s_dark_show_border) ? 2 : 0;
  const int info_layer_width = bounds.size.w / 2 - BORDER_THICKNESS - 2 - theme_offset;
#if defined(PBL_PLATFORM_EMERY)
  const int info_layer_height = 60;
#else
  const int info_layer_height = 44;
#endif

#if defined(PBL_PLATFORM_EMERY)
  int margin_w = 2 + theme_offset;
#else
  int margin_w = 6 + theme_offset;
#endif
  const int margin_h = 4;

  // Upper left
  s_info_layers[LAYER_UPPER_LEFT].bounds = GRect(margin_w, margin_h, info_layer_width, info_layer_height);
  s_info_layers[LAYER_UPPER_LEFT].position = LAYER_UPPER_LEFT;
  s_info_layers[LAYER_UPPER_LEFT].layer = layer_create(s_info_layers[LAYER_UPPER_LEFT].bounds);
  s_info_layers[LAYER_UPPER_LEFT].text_layer1 = NULL;
  s_info_layers[LAYER_UPPER_LEFT].text_layer2 = NULL;
  s_info_layers[LAYER_UPPER_LEFT].bitmap_layer_1 = NULL;
  s_info_layers[LAYER_UPPER_LEFT].bitmap_layer_2 = NULL;
  s_info_layers[LAYER_UPPER_LEFT].bitmap_layer_3 = NULL;
  
  // Upper right 
  s_info_layers[LAYER_UPPER_RIGHT].bounds = GRect(bounds.size.w - info_layer_width - margin_w, margin_h, info_layer_width, info_layer_height);
  s_info_layers[LAYER_UPPER_RIGHT].position = LAYER_UPPER_RIGHT;
  s_info_layers[LAYER_UPPER_RIGHT].layer = layer_create(s_info_layers[LAYER_UPPER_RIGHT].bounds);
  s_info_layers[LAYER_UPPER_RIGHT].text_layer1 = NULL;
  s_info_layers[LAYER_UPPER_RIGHT].text_layer2 = NULL;
  s_info_layers[LAYER_UPPER_RIGHT].bitmap_layer_1 = NULL;
  s_info_layers[LAYER_UPPER_RIGHT].bitmap_layer_2 = NULL;
  s_info_layers[LAYER_UPPER_RIGHT].bitmap_layer_3 = NULL;
  
  // Lower left
  s_info_layers[LAYER_LOWER_LEFT].bounds = GRect(margin_w, bounds.size.h - info_layer_height - margin_h, info_layer_width, info_layer_height);
  s_info_layers[LAYER_LOWER_LEFT].position = LAYER_LOWER_LEFT;
  s_info_layers[LAYER_LOWER_LEFT].layer = layer_create(s_info_layers[LAYER_LOWER_LEFT].bounds);
  s_info_layers[LAYER_LOWER_LEFT].text_layer1 = NULL;
  s_info_layers[LAYER_LOWER_LEFT].text_layer2 = NULL;
  s_info_layers[LAYER_LOWER_LEFT].bitmap_layer_1 = NULL;
  s_info_layers[LAYER_LOWER_LEFT].bitmap_layer_2 = NULL;
  s_info_layers[LAYER_LOWER_LEFT].bitmap_layer_3 = NULL;
  
  // Lower right
  s_info_layers[LAYER_LOWER_RIGHT].bounds = GRect(bounds.size.w - info_layer_width - margin_w, bounds.size.h - info_layer_height - margin_h, info_layer_width, info_layer_height);
  s_info_layers[LAYER_LOWER_RIGHT].position = LAYER_LOWER_RIGHT;
  s_info_layers[LAYER_LOWER_RIGHT].layer = layer_create(s_info_layers[LAYER_LOWER_RIGHT].bounds);
  s_info_layers[LAYER_LOWER_RIGHT].text_layer1 = NULL;
  s_info_layers[LAYER_LOWER_RIGHT].text_layer2 = NULL;
  s_info_layers[LAYER_LOWER_RIGHT].bitmap_layer_1 = NULL;
  s_info_layers[LAYER_LOWER_RIGHT].bitmap_layer_2 = NULL;
  s_info_layers[LAYER_LOWER_RIGHT].bitmap_layer_3 = NULL;
}


// Returns true if data received at `last_received` is old enough to
// re-request from the phone. 0 means "never received". A last_received in
// the future means the clock changed - treat as stale to recover.
static bool is_data_stale(time_t last_received) {
  time_t now = time(NULL);
  return last_received == 0 || last_received > now ||
         (now - last_received) >= DATA_MAX_AGE_SECONDS;
}

// Returns true if any quadrant shows custom URL data. The phone ignores
// custom URL requests anyway when no slot is configured, so the watch can
// save the Bluetooth message (and its retry cycle) entirely.
static bool is_custom_url_slot_configured() {
  for (int i = 0; i < NUM_INFO_LAYERS; i++) {
    if (s_layer_assignments[i] == INFO_TYPE_CUSTOM_URL) {
      return true;
    }
  }
  return false;
}

// --- Window Load/Unload Handlers ---
static void main_window_appear(Window *window) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Window appear");

  // Repaint background/frame and update UI immediately
  layer_mark_dirty(window_get_root_layer(window));
  layer_mark_dirty(s_frame_layer);
  try_start_animation_timer();
  battery_handler(battery_state_service_peek());
  update_time(); // Ensure time is displayed immediately

  // The window re-appears every time the firmware hands the screen back
  // (dismissed notification, closed app, ...). Only re-request data from the
  // phone when the persisted data is actually stale - the phone pushes fresh
  // data every 30 minutes on its own.
  if (is_data_stale(s_weather_last_received)) {
    // Request weather update after a short delay to prevent blocking UI
    app_timer_register(100, delayed_weather_request, NULL);
  } else {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Weather still fresh, skipping request");
  }

  if (is_custom_url_slot_configured() && is_data_stale(s_custom_data_last_received)) {
    // Request custom URL update separately, staggered well after the weather request so it
    // doesn't immediately collide with it for the single-slot outbox (which only holds one
    // unacknowledged outgoing message at a time). Reset stale state and retry counter so a
    // fresh window appearance never inherits red text from a previous retry cycle.
    s_custom_data_stale = false;
    s_custom_url_retries = 0;
    app_timer_register(1500, delayed_custom_url_request, NULL);
  } else {
    APP_LOG(APP_LOG_LEVEL_DEBUG, "Custom data still fresh, skipping request");
  }
}

static void main_window_load(Window *window) {
  APP_LOG(APP_LOG_LEVEL_DEBUG, "Window load");

  Layer *window_layer = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(window_layer);

  // Create frame layer
  s_frame_layer = layer_create(bounds);
  layer_set_update_proc(s_frame_layer, draw_frame);
  layer_add_child(window_layer, s_frame_layer);

  // Create animation layer
  s_animation_layer = layer_create(bounds);
  layer_set_update_proc(s_animation_layer, draw_animation);
  layer_add_child(window_layer, s_animation_layer);

   // Create Time Layer
#if defined(PBL_PLATFORM_EMERY)
   const int time_y_pos = bounds.size.h / 2 - 20 - 28;
#else
   const int time_y_pos = bounds.size.h / 2 - 20 - 14;
#endif
   // Tight band around the time glyphs (instead of the whole window
   // height) so animation refreshes repaint less area - better for battery
   // on the always-on display. Anchored at the time position and ending
   // just above the date layer.
#if defined(PBL_PLATFORM_EMERY)
   const int time_band_height = 72;
#else
   const int time_band_height = 48;
#endif
   s_time_layer = layer_create(
       GRect(0, time_y_pos, bounds.size.w, time_band_height));
   layer_set_update_proc(s_time_layer, draw_time);
   layer_add_child(window_layer, s_time_layer);

  // Create the Date Layer (Center below time)
#if defined(PBL_PLATFORM_EMERY)
  s_date_layer = layer_create(
      GRect(0, time_y_pos + 56, bounds.size.w, 28));
#else
  s_date_layer = layer_create(
      GRect(0, time_y_pos + 38, bounds.size.w, 24));
#endif
  layer_set_update_proc(s_date_layer, draw_date);
  layer_add_child(window_layer, s_date_layer);

  // Initialize the 4 info layers
  init_info_layers(bounds);
  
  // Add the info layers to the window
  for (int i = 0; i < NUM_INFO_LAYERS; i++) {
    layer_add_child(window_layer, s_info_layers[i].layer);
  }

  // Initialize weather forecast bar (on top of info layers)
  weather_forecast_init(window_layer, bounds);

  // Initialize PDC icons for use in info drawing functions
  load_weather_icon();
  load_step_icon();
  load_battery_icon();
  load_calendar_icon();
  load_disconnect_icon();
  load_heart_icon();
  update_day();

  // Initialize the display with current layer assignments
  update_all_info_layers();

  // Make sure the initial time is displayed
  update_time();
}

static void main_window_unload(Window *window) {
  // Destroy the main layers
  layer_destroy(s_time_layer);
  layer_destroy(s_date_layer);
  layer_destroy(s_frame_layer);
  s_frame_layer = NULL;
  layer_destroy(s_animation_layer);

  if (s_frame_cache) {
    gbitmap_destroy(s_frame_cache);
    s_frame_cache = NULL;
    s_frame_cache_valid = false;
  }

  // Destroy weather forecast layer
  weather_forecast_deinit();

  // Destroy info layers (this will also destroy all their children via clear_info_layer)
  for (int i = 0; i < NUM_INFO_LAYERS; i++) {
    if (s_info_layers[i].layer) {
      clear_info_layer(&s_info_layers[i]);
      layer_destroy(s_info_layers[i].layer);
    }
  }

  // Destroy bitmaps
  if (s_step_icon) {
    gdraw_command_image_destroy(s_step_icon);
  }
  if (s_weather_icon) {
    gdraw_command_image_destroy(s_weather_icon);
  }
  if (s_battery_icon) {
    gdraw_command_image_destroy(s_battery_icon);
  }
  if (s_calendar_icon) {
    gdraw_command_image_destroy(s_calendar_icon);
  }
  if (s_disconnect_icon) {
    gdraw_command_image_destroy(s_disconnect_icon);
  }
  if (s_heart_icon) {
    gdraw_command_image_destroy(s_heart_icon);
  }
}

// --- Initialization and Deinitialization ---

static void init() {
  srand(time(NULL));

  // Load saved theme preference before creating UI
  load_theme_from_storage();
  
  // Load saved step goal preference
  load_step_goal_from_storage();
  
  // Load saved temperature unit preference
  load_temperature_unit_from_storage();

  // Load animation
  load_enable_animations_from_storage();
  
  // Load saved weather data from storage
  load_weather_from_storage();

  // Load saved layout assignments
  load_layout_from_storage();

  // Load saved disconnect position
  load_disconnect_position_from_storage();

  // Load saved weather detail preferences
  load_weather_forecast_flick_mode_from_storage();
  load_weather_forecast_duration_from_storage();

  // Load saved mesh preference
  load_enable_mesh_from_storage();

  // Load saved date format preference
  load_date_format_from_storage();
  load_light_show_background_from_storage();
  load_dark_show_border_from_storage();
  load_vibrate_on_disconnect_from_storage();
  load_bg_colors_from_storage();
  load_custom_lines_from_storage();

  s_last_was_dark = is_dark_theme();

  s_main_window = window_create();
  window_set_background_color(s_main_window, get_background_color());

  window_set_window_handlers(s_main_window, (WindowHandlers){
                                                .load = main_window_load,
                                                .unload = main_window_unload,
                                                .appear = main_window_appear});

  // Initialize App Message
  app_message_register_inbox_received(inbox_received_callback);
  app_message_open(768, 128); // Buffer size for weather + forecast + layout + config data

  // Subscribe to MINUTE_UNIT (for time update/minute-start trigger) and SECOND_UNIT (for stop trigger)
  tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);

  // Subscribe to battery state updates
  battery_state_service_subscribe(battery_handler);

  // Subscribe to Bluetooth connection updates
  connection_service_subscribe((ConnectionHandlers) {
    .pebble_app_connection_handler = bluetooth_connection_handler
  });

  // Subscribe to tap/flick events for weather forecast bar
  accel_tap_service_subscribe(tap_handler);

  window_stack_push(s_main_window, true);

  APP_LOG(APP_LOG_LEVEL_DEBUG, "Finished init");
}

static void deinit() {
  try_stop_animation_timer();
  window_destroy(s_main_window);
  tick_timer_service_unsubscribe();
  battery_state_service_unsubscribe();
  connection_service_unsubscribe();
  accel_tap_service_unsubscribe();
}

// --- Main Program Loop ---

int main(void)
{
  init();
  app_event_loop();
  deinit();
}