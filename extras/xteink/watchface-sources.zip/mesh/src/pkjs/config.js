module.exports = [
  {
    "type": "heading",
    "defaultValue": "Pebble Mesh"
  },
  {
    "type": "text",
    "defaultValue": "<span>David Peer, 2026 | <a href='https://www.paypal.com/donate/?hosted_button_id=Y4PDJU84LC3N2'>Buy me a coffee</a> &#9749; </span>"
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "General"
      },
      {
        "type": "select",
        "messageKey": "COLOR_THEME",
        "label": "Color Theme",
        "defaultValue": "dark",
        "options": [
          {
            "label": "Dark",
            "value": "dark"
          },
          {
            "label": "Light",
            "value": "light"
          },
          {
            "label": "Dynamic (Sunrise/Sunset)",
            "value": "dynamic"
          },
          {
            "label": "Dynamic (Quiet)",
            "value": "quiet"
          },
        ]
      },
      {
        "type": "toggle",
        "messageKey": "ENABLE_ANIMATIONS",
        "label": "Enable Animations",
        "defaultValue": true
      },
      {
        "type": "toggle",
        "messageKey": "VIBRATE_ON_DISCONNECT",
        "label": "Vibrate on Connect/Disconnect",
        "description": "Vibrate 3 times when the watch connects or disconnects from the phone.",
        "defaultValue": false
      },
      {
        "type": "toggle",
        "messageKey": "ENABLE_MESH",
        "label": "Enable Mesh",
        "description": "Wait... you're disabling the mesh on a watchface called Mesh? Bold move. Improves readability, destroys identity.",
        "defaultValue": true
      },
      {
        "type": "input",
        "messageKey": "DATE_FORMAT",
        "label": "Date Format or Static Text",
        "defaultValue": " %a %d",
        "description": "Default: ' %a %d'. Patterns: %a = day name, %b = month name, %d = day, %m = month number. Examples: ' %d %b' = 12 Apr, ' %d/%m' = 12/04, ' %m/%d' = 04/12",
        "attributes": {
          "placeholder": " %a %d"
        }
      },
      {
        "type": "heading",
        "defaultValue": "Light Theme",
        "size": 4
      },
      {
        "type": "toggle",
        "messageKey": "LIGHT_SHOW_BACKGROUND",
        "label": "Show Background Box",
        "defaultValue": true
      },
      {
        "type": "select",
        "messageKey": "LIGHT_BG_COLOR_ENUM",
        "label": "Background Color",
        "defaultValue": "white",
        "capabilities": ["COLOR"],
        "options": [
          { "label": "White", "value": "white" },
          { "label": "Black", "value": "black" },
          { "label": "Red", "value": "red" },
          { "label": "Green", "value": "green" },
          { "label": "Blue", "value": "blue" },
          { "label": "Yellow", "value": "yellow" },
          { "label": "Gray", "value": "gray" }
        ]
      },
      {
        "type": "select",
        "messageKey": "LIGHT_BG_COLOR_ENUM",
        "label": "Background Color",
        "defaultValue": "white",
        "capabilities": ["BW"],
        "options": [
          { "label": "White", "value": "white" },
          { "label": "Black", "value": "black" },
          { "label": "Gray", "value": "gray" }
        ]
      },
      {
        "type": "heading",
        "defaultValue": "Dark Theme",
        "size": 4
      },
      {
        "type": "toggle",
        "messageKey": "DARK_SHOW_BORDER",
        "label": "Show Border",
        "defaultValue": true
      },
      {
        "type": "select",
        "messageKey": "DARK_BG_COLOR_ENUM",
        "label": "Background Color",
        "defaultValue": "black",
        "capabilities": ["COLOR"],
        "options": [
          { "label": "White", "value": "white" },
          { "label": "Black", "value": "black" },
          { "label": "Red", "value": "red" },
          { "label": "Green", "value": "green" },
          { "label": "Blue", "value": "blue" },
          { "label": "Yellow", "value": "yellow" },
          { "label": "Gray", "value": "gray" }
        ]
      },
      {
        "type": "select",
        "messageKey": "DARK_BG_COLOR_ENUM",
        "label": "Background Color",
        "defaultValue": "black",
        "capabilities": ["BW"],
        "options": [
          { "label": "White", "value": "white" },
          { "label": "Black", "value": "black" },
          { "label": "Gray", "value": "gray" }
        ]
      }
    ]
  },
    {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Layout"
      },
      {
        "type": "select",
        "messageKey": "LAYOUT_UPPER_LEFT",
        "label": "Upper Left",
        "defaultValue": "0",
        "options": [
          { "label": "Weather Icon", "value": "0" },
          { "label": "Temperature", "value": "1" },
          { "label": "Steps", "value": "2" },
          { "label": "Heart Rate", "value": "8" },
          { "label": "Battery", "value": "3" },
          { "label": "Calendar", "value": "6" },
          { "label": "Custom Data", "value": "9" },
          { "label": "None", "value": "5" }
        ]
      },
      {
        "type": "select",
        "messageKey": "LAYOUT_UPPER_RIGHT",
        "label": "Upper Right",
        "defaultValue": "1",
        "options": [
          { "label": "Weather Icon", "value": "0" },
          { "label": "Temperature", "value": "1" },
          { "label": "Steps", "value": "2" },
          { "label": "Heart Rate", "value": "8" },
          { "label": "Battery", "value": "3" },
          { "label": "Calendar", "value": "6" },
          { "label": "Custom Data", "value": "9" },
          { "label": "None", "value": "5" }
        ]
      },
      {
        "type": "select",
        "messageKey": "LAYOUT_LOWER_LEFT",
        "label": "Lower Left",
        "defaultValue": "2",
        "options": [
          { "label": "Weather Icon", "value": "0" },
          { "label": "Temperature", "value": "1" },
          { "label": "Steps", "value": "2" },
          { "label": "Heart Rate", "value": "8" },
          { "label": "Battery", "value": "3" },
          { "label": "Calendar", "value": "6" },
          { "label": "Custom Data", "value": "9" },
          { "label": "None", "value": "5" }
        ]
      },
      {
        "type": "select",
        "messageKey": "LAYOUT_LOWER_RIGHT",
        "label": "Lower Right",
        "defaultValue": "3",
        "options": [
          { "label": "Weather Icon", "value": "0" },
          { "label": "Temperature", "value": "1" },
          { "label": "Steps", "value": "2" },
          { "label": "Heart Rate", "value": "8" },
          { "label": "Battery", "value": "3" },
          { "label": "Calendar", "value": "6" },
          { "label": "Custom Data", "value": "9" },
          { "label": "None", "value": "5" }
        ]
      },
      {
        "type": "select",
        "messageKey": "DISCONNECT_POSITION",
        "label": "Disconnect Icon",
        "defaultValue": "0",
        "description": "Show disconnect icon when the watch loses connection.",
        "options": [
          { "label": "Disabled", "value": "0" },
          { "label": "Upper Left", "value": "1" },
          { "label": "Upper Right", "value": "2" },
          { "label": "Lower Left", "value": "3" },
          { "label": "Lower Right", "value": "4" }
        ]
      }
    ]
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Health"
      },
      {
        "type": "input",
        "messageKey": "STEP_GOAL",
        "label": "Daily Step Goal",
        "defaultValue": "10000",
        "description": "Set your daily step goal (100-100000)",
        "attributes": {
          "type": "number",
          "min": 100,
          "max": 100000,
          "placeholder": "10000"
        }
      }
    ]
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Weather"
      },
      {
        "type": "input",
        "messageKey": "WEATHER_LOCATION_CONFIG",
        "label": "Location",
        "defaultValue": "",
        "description": "Enter your city name (e.g., Vienna, New York, Tokyo) or leave empty to use GPS location automatically. Weather data is fetched from Open-Meteo API.",
        "attributes": {
          "placeholder": "e.g., Vienna (or leave empty for GPS)"
        }
      },
      {
        "type": "radiogroup",
        "messageKey": "TEMPERATURE_UNIT",
        "label": "Temperature Unit",
        "defaultValue": "celsius",
        "options": [
          {
            "label": "Celsius",
            "value": "celsius"
          },
          {
            "label": "Fahrenheit",
            "value": "fahrenheit"
          }
        ]
      },
      {
        "type": "select",
        "messageKey": "WEATHER_FORECAST_FLICK_MODE",
        "label": "Forecast Trigger",
        "description": "How to open the weather forecast.",
        "defaultValue": "2",
        "options": [
          { "label": "Disabled", "value": "0" },
          { "label": "Single Flick", "value": "1" },
          { "label": "Double Flick", "value": "2" }
        ]
      },
      {
        "type": "select",
        "messageKey": "WEATHER_FORECAST_DURATION",
        "label": "Forecast Duration",
        "description": "How long to show the weather forecast.",
        "defaultValue": "0",
        "options": [
          { "label": "5 seconds", "value": "0" },
          { "label": "10 seconds", "value": "1" },
          { "label": "15 seconds", "value": "3" },
          { "label": "30 seconds", "value": "4" },
          { "label": "Until dismissed", "value": "2" }
        ]
      }
    ]
  },
  {
    "type": "section",
    "items": [
      {
        "type": "heading",
        "defaultValue": "Custom Data"
      },
      {
        "type": "input",
        "messageKey": "CUSTOM_URL",
        "label": "Custom Data URL",
        "defaultValue": "",
        "description": "Fetch data from a URL and show it accordingly to regex1 and regex2. Refreshed every 30 min.",
        "attributes": {
          "placeholder": "https://example.com/data"
        }
      },
      {
        "type": "input",
        "messageKey": "CUSTOM_REGEX_1",
        "label": "Line 1 regex",
        "defaultValue": "([^\|]*)",
        "description": "Regex for the first line.",
        "attributes": {
          "placeholder": "temp\":([\\d]+)"
        }
      },
      {
        "type": "input",
        "messageKey": "CUSTOM_REGEX_2",
        "label": "Line 2 regex",
        "defaultValue": "\|([^\|]*)",
        "description": "Regex for the second line (smaller font).",
        "attributes": {
          "placeholder": "city\":([\\w ]+)"
        }
      }
    ]
  },
  {
    "type": "submit",
    "defaultValue": "Save Settings"
  },
];