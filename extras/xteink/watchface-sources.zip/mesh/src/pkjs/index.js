var Clay = require('pebble-clay');
var clayConfig = require('./config');
var clay = new Clay(clayConfig, null, { autoHandleEvents: false });

// Default configuration
var config = {
  location: '', // Empty = use GPS, otherwise use static location
  colorTheme: 'dark',  // Default to dark theme (dark/light/dynamic)
  stepGoal: 10000, // Default step goal
  temperatureUnit: 'celsius', // Default temperature unit (celsius/fahrenheit)
  enableAnimations: false, // Default to animations enabled
  layoutUpperLeft: 0,   // INFO_TYPE_WEATHER
  layoutUpperRight: 1,  // INFO_TYPE_TEMPERATURE
  layoutLowerLeft: 2,   // INFO_TYPE_STEPS
  layoutLowerRight: 3,  // INFO_TYPE_BATTERY
  disconnectPosition: 0, // 0 = disabled, 1-4 = UL/UR/LL/LR
  forecastDuration: 0, // 0=5s, 1=10s, 2=forever
  forecastFlickMode: 2, // 0=disabled, 1=single flick, 2=double flick
  enableMesh: true, // Show mesh dot pattern
  dateFormat: ' %a %d', // strftime format pattern for date display
  lightShowBackground: true, // Show gray box in light theme
  darkShowBorder: true, // Show border in dark theme
  vibrateOnDisconnect: false, // Vibrate on connect/disconnect
  lightBgColor: 'white', // Background color for light theme (named enum color)
  darkBgColor: 'black', // Background color for dark theme (named enum color)
  customUrl: '', // URL to fetch custom data from
  customRegexLine1: '', // regex to extract the big line; empty = whole page is line 1
  customRegexLine2: '' // regex to extract the small line; empty = no second line
};

// Background colors are a fixed enum of named colors; the watch receives the
// index. Must match the BgColor enum in src/c/config.h.
var BG_COLOR_ENUM = {
  white: 0,
  black: 1,
  red: 2,
  green: 3,
  blue: 4,
  yellow: 5,
  gray: 6
};

// Values saved by older versions (free-form hex ints) fail this check and
// fall back to the defaults.
function isValidBgColor(name) {
  return BG_COLOR_ENUM[name] !== undefined;
}

// Load saved configuration
if (localStorage.getItem('WEATHER_LOCATION_CONFIG')) {
  config.location = localStorage.getItem('WEATHER_LOCATION_CONFIG');
}
if (localStorage.getItem('COLOR_THEME')) {
  config.colorTheme = localStorage.getItem('COLOR_THEME');
}
if (localStorage.getItem('STEP_GOAL')) {
  config.stepGoal = parseInt(localStorage.getItem('STEP_GOAL'));
}
if (localStorage.getItem('TEMPERATURE_UNIT')) {
  config.temperatureUnit = localStorage.getItem('TEMPERATURE_UNIT');
}
if (localStorage.getItem('ENABLE_ANIMATIONS')) {
  config.enableAnimations = (localStorage.getItem('ENABLE_ANIMATIONS') === 'true');
}
if (localStorage.getItem('LAYOUT_UPPER_LEFT') !== null) {
  config.layoutUpperLeft = parseInt(localStorage.getItem('LAYOUT_UPPER_LEFT'));
}
if (localStorage.getItem('LAYOUT_UPPER_RIGHT') !== null) {
  config.layoutUpperRight = parseInt(localStorage.getItem('LAYOUT_UPPER_RIGHT'));
}
if (localStorage.getItem('LAYOUT_LOWER_LEFT') !== null) {
  config.layoutLowerLeft = parseInt(localStorage.getItem('LAYOUT_LOWER_LEFT'));
}
if (localStorage.getItem('LAYOUT_LOWER_RIGHT') !== null) {
  config.layoutLowerRight = parseInt(localStorage.getItem('LAYOUT_LOWER_RIGHT'));
}
if (localStorage.getItem('DISCONNECT_POSITION') !== null) {
  config.disconnectPosition = parseInt(localStorage.getItem('DISCONNECT_POSITION'));
}
if (localStorage.getItem('WEATHER_FORECAST_DURATION') !== null) {
  config.forecastDuration = parseInt(localStorage.getItem('WEATHER_FORECAST_DURATION'));
}
if (localStorage.getItem('WEATHER_FORECAST_FLICK_MODE') !== null) {
  config.forecastFlickMode = parseInt(localStorage.getItem('WEATHER_FORECAST_FLICK_MODE'));
}
if (localStorage.getItem('ENABLE_MESH') !== null) {
  config.enableMesh = (localStorage.getItem('ENABLE_MESH') === 'true');
}
if (localStorage.getItem('DATE_FORMAT') !== null) {
  config.dateFormat = localStorage.getItem('DATE_FORMAT');
}
if (localStorage.getItem('LIGHT_SHOW_BACKGROUND') !== null) {
  config.lightShowBackground = (localStorage.getItem('LIGHT_SHOW_BACKGROUND') === 'true');
}
if (localStorage.getItem('DARK_SHOW_BORDER') !== null) {
  config.darkShowBorder = (localStorage.getItem('DARK_SHOW_BORDER') === 'true');
}
if (localStorage.getItem('VIBRATE_ON_DISCONNECT') !== null) {
  config.vibrateOnDisconnect = (localStorage.getItem('VIBRATE_ON_DISCONNECT') === 'true');
}
if (isValidBgColor(localStorage.getItem('LIGHT_BG_COLOR_ENUM'))) {
  config.lightBgColor = localStorage.getItem('LIGHT_BG_COLOR_ENUM');
}
if (isValidBgColor(localStorage.getItem('DARK_BG_COLOR_ENUM'))) {
  config.darkBgColor = localStorage.getItem('DARK_BG_COLOR_ENUM');
}
if (localStorage.getItem('CUSTOM_URL') !== null) {
  config.customUrl = localStorage.getItem('CUSTOM_URL');
}
if (localStorage.getItem('CUSTOM_REGEX_1') !== null) {
  config.customRegexLine1 = localStorage.getItem('CUSTOM_REGEX_1');
}
if (localStorage.getItem('CUSTOM_REGEX_2') !== null) {
  config.customRegexLine2 = localStorage.getItem('CUSTOM_REGEX_2');
}

// Variables to store weather data
var weatherData = {
  temperature: '--',
  location: 'Loading...',
  condition: -1,  // Weather code for condition
  is_day: true,   // Default to true (day)
  hourlyTemps: '',   // Comma-separated 12h hourly temperatures
  hourlyPrecip: '',  // Comma-separated 12h hourly precipitation probabilities
  forecast: [
    { temp: 0, condition: -1 },  // now
    { temp: 0, condition: -1 },  // +1d (tomorrow)
    { temp: 0, condition: -1 }   // +2d (day after)
  ]
};

// Function to get coordinates for a city name
function getCoordinatesForCityAndFetchWeather(cityName) {
  console.log('Getting coordinates for: ' + cityName);
  
  var url = 'https://geocoding-api.open-meteo.com/v1/search?name=' + 
            encodeURIComponent(cityName) + '&count=1&language=en&format=json';
  
  console.log('Geocoding URL: ' + url);
  
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        try {
          var response = JSON.parse(xhr.responseText);
          console.log('Geocoding response: ' + xhr.responseText);
          
          if (response.results && response.results.length > 0) {
            var result = response.results[0];
            var latitude = result.latitude;
            var longitude = result.longitude;
            var locationName = result.name || cityName;
            
            console.log('Found coordinates: ' + latitude + ',' + longitude + ' for ' + locationName);
            weatherData.location = locationName;
            
            // Now get weather data for these coordinates
            getWeatherData(latitude, longitude);
          } else {
            console.log('No results found for city: ' + cityName);
            weatherData.location = config.location + ' Not Found';
            weatherData.temperature = 'N/A';
            weatherData.condition = -1;
          }
        } catch (e) {
          console.log('Geocoding JSON parse error: ' + e.message);
          weatherData.location = 'Parse Error';
          weatherData.temperature = 'N/A';
          weatherData.condition = -1;
        }
      } else {
        console.log('Geocoding request failed with status: ' + xhr.status);
        weatherData.location = 'Geocode Error';
        weatherData.temperature = 'N/A';
        weatherData.condition = -1;
      }
    }
  };
  
  xhr.open('GET', url, true);
  xhr.timeout = 10000;
  xhr.ontimeout = function() {
    console.log('Geocoding request timed out');
    weatherData.location = 'Timeout';
    weatherData.temperature = 'N/A';
    weatherData.condition = -1;
  };
  xhr.onerror = function() {
    console.log('Geocoding request network error');
    weatherData.location = 'Net Error';
    weatherData.temperature = 'N/A';
    weatherData.condition = -1;
  };
  xhr.send();
}

function isCustomDataNeeded() {
  return [config.layoutUpperLeft, config.layoutUpperRight, config.layoutLowerLeft, config.layoutLowerRight]
    .some(function(v) { return v === 9; });
}

// Main function to fetch weather for configured location
function fetchWeatherForLocation() {
  console.log('Fetching weather for configured location: ' + config.location);

  // If location is empty or not set, use GPS
  if (!config.location || config.location.trim() === '') {
    console.log('No static location configured, using GPS');
    getLocationAndFetchWeather();
  } else {
    console.log('Using static location: ' + config.location);
    getCoordinatesForCityAndFetchWeather(config.location);
  }
}

// Function to get current GPS location and fetch weather
function getLocationAndFetchWeather() {
  console.log('Getting GPS location...');
  
  navigator.geolocation.getCurrentPosition(
    function(pos) {
      var latitude = pos.coords.latitude;
      var longitude = pos.coords.longitude;
      console.log('GPS coordinates: ' + latitude + ',' + longitude);
      // Get city name from reverse geocoding and then get weather
      getReverseGeocodingAndFetchWeather(latitude, longitude);
    },
    function(err) {
      console.log('GPS location error: ' + err.message);
      weatherData.location = 'GPS Error';
      weatherData.temperature = 'N/A';
      weatherData.condition = -1;
    },
    {
      timeout: 15000,
      maximumAge: 60000
    }
  );
}

// Function to get city name from coordinates and fetch weather
function getReverseGeocodingAndFetchWeather(latitude, longitude) {
  console.log('Getting city name for coordinates: ' + latitude + ',' + longitude);
  
  // Use OpenStreetMap Nominatim for reverse geocoding
  var url = 'https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=' + latitude + '&longitude=' + longitude;

  console.log('Reverse geocoding URL: ' + url);
  
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        try {
          var response = JSON.parse(xhr.responseText);
          console.log('Reverse geocoding response: ' + xhr.responseText);
          
          if (response) {
            // Try to get city, town, village, or locality
            var locationName = response.city || 
                             response.locality || 
                             response.countryName ||
                             'GPS Loc';
            weatherData.location = locationName;
            console.log('Found location name: ' + weatherData.location);
          } else {
            console.log('No location name found, using GPS coordinates');
            weatherData.location = 'GPS Loc';
          }
        } catch (e) {
          console.log('Reverse geocoding JSON parse error: ' + e.message);
          weatherData.location = 'GPS Loc';
        }
        
        // Now get weather data for these coordinates
        getWeatherData(latitude, longitude);
      } else {
        console.log('Reverse geocoding request failed with status: ' + xhr.status);
        weatherData.location = 'GPS Loc';
        // Still get weather data even if reverse geocoding failed
        getWeatherData(latitude, longitude);
      }
    }
  };
  
  xhr.open('GET', url, true);
  xhr.timeout = 10000;
  xhr.ontimeout = function() {
    console.log('Reverse geocoding request timed out');
    weatherData.location = 'GPS Loc';
    // Still get weather data even if reverse geocoding timed out
    getWeatherData(latitude, longitude);
  };
  xhr.onerror = function() {
    console.log('Reverse geocoding request network error');
    weatherData.location = 'GPS Loc';
    // Still get weather data even if reverse geocoding failed
    getWeatherData(latitude, longitude);
  };
  xhr.send();
}

// Function to get weather data from Open-Meteo API
function getWeatherData(latitude, longitude) {
  // Request sunrise and sunset for today, along with current weather and hourly forecast
  var now = new Date();
  var yyyy = now.getUTCFullYear();
  var mm = String(now.getUTCMonth() + 1).padStart(2, '0');
  var dd = String(now.getUTCDate()).padStart(2, '0');
  var today = yyyy + '-' + mm + '-' + dd;
  // Get day after tomorrow for daily forecast (now, +1d, +2d)
  var dayAfterTomorrow = new Date(now);
  dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);
  var yyyy2 = dayAfterTomorrow.getUTCFullYear();
  var mm2 = String(dayAfterTomorrow.getUTCMonth() + 1).padStart(2, '0');
  var dd2 = String(dayAfterTomorrow.getUTCDate()).padStart(2, '0');
  var endDate = yyyy2 + '-' + mm2 + '-' + dd2;
  var url = 'https://api.open-meteo.com/v1/forecast?latitude=' +
            latitude + '&longitude=' + longitude +
            '&current_weather=true&temperature_unit=' + config.temperatureUnit + '&windspeed_unit=kmh' +
            '&hourly=temperature_2m,weather_code,precipitation_probability' +
            '&daily=sunrise,sunset,weather_code,temperature_2m_max&timezone=auto&start_date=' + today + '&end_date=' + endDate;

  console.log('Fetching weather from: ' + url);

  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
      console.log('Weather request completed with status: ' + xhr.status);
      if (xhr.status === 200) {
        try {
          var response = JSON.parse(xhr.responseText);
          console.log('Weather response: ' + xhr.responseText);

          if (response.current_weather && response.current_weather.temperature !== undefined) {
            var temp = Math.round(response.current_weather.temperature);
            weatherData.temperature = temp.toString();
            weatherData.condition = response.current_weather.weathercode || 0;

            // Default to is_day from API if available, else calculate
            var isDay = true; // Default to true
            // Fallback: calculate from sunrise/sunset
            try {
              var sunrise = null, sunset = null;
              if (response.daily && response.daily.sunrise && response.daily.sunset) {
                sunrise = new Date(response.daily.sunrise[0]);
                sunset = new Date(response.daily.sunset[0]);
                var nowLocal = new Date();
                isDay = (nowLocal >= sunrise && nowLocal < sunset);
              }
            } catch (e) {
              isDay = true; // Fallback to true if error
              console.log('Error calculating is_day: ' + e.message);
            }
            
            weatherData.is_day = isDay;

            // Extract forecast: now (current), tomorrow (daily), day after (daily)
            try {
              if (response.hourly && response.hourly.time && response.hourly.temperature_2m && response.hourly.weather_code) {
                var nowLocal = new Date();

                // Slot 0: Current weather (now)
                weatherData.forecast[0].temp = Math.round(response.current_weather.temperature);
                weatherData.forecast[0].condition = response.current_weather.weathercode || 0;

                // Slots 1 & 2: Tomorrow and day after from daily forecast
                if (response.daily && response.daily.weather_code && response.daily.temperature_2m_max) {
                  // daily arrays: index 0 = today, 1 = tomorrow, 2 = day after
                  for (var di = 1; di <= 2; di++) {
                    if (di < response.daily.weather_code.length) {
                      weatherData.forecast[di].temp = Math.round(response.daily.temperature_2m_max[di]);
                      weatherData.forecast[di].condition = response.daily.weather_code[di];
                    }
                  }
                }

                console.log('Forecast: now=' + weatherData.forecast[0].temp + '/' + weatherData.forecast[0].condition +
                            ' +1d=' + weatherData.forecast[1].temp + '/' + weatherData.forecast[1].condition +
                            ' +2d=' + weatherData.forecast[2].temp + '/' + weatherData.forecast[2].condition);

                // Extract 24 hours of today's data for the bottom bar graph (hours 0-23)
                var hourlyTemps = [];
                var hourlyPrecip = [];
                // Today's midnight
                var todayMidnight = new Date(nowLocal.getFullYear(), nowLocal.getMonth(), nowLocal.getDate(), 0, 0, 0);
                for (var h = 0; h < 24; h++) {
                  var hTarget = new Date(todayMidnight.getTime() + h * 3600 * 1000);
                  var hBestIdx = 0;
                  var hBestDiff = Infinity;
                  for (var hi2 = 0; hi2 < response.hourly.time.length; hi2++) {
                    var ht = new Date(response.hourly.time[hi2]);
                    var hd = Math.abs(ht.getTime() - hTarget.getTime());
                    if (hd < hBestDiff) {
                      hBestDiff = hd;
                      hBestIdx = hi2;
                    }
                  }
                  hourlyTemps.push(Math.round(response.hourly.temperature_2m[hBestIdx]));
                  var precip = (response.hourly.precipitation_probability && response.hourly.precipitation_probability[hBestIdx]) || 0;
                  hourlyPrecip.push(Math.round(precip));
                }
                weatherData.hourlyTemps = hourlyTemps.join(',');
                weatherData.hourlyPrecip = hourlyPrecip.join(',');
                console.log('Hourly temps: ' + weatherData.hourlyTemps);
                console.log('Hourly precip: ' + weatherData.hourlyPrecip);
              }
            } catch (fe) {
              console.log('Forecast parse error: ' + fe.message);
            }

            console.log('Temperature: ' + weatherData.temperature + ', Weather code: ' + weatherData.condition + ', is_day: ' + isDay);
            sendDataToPebble();
          } else {
            console.log('Invalid weather response format - no current_weather');
            weatherData.temperature = 'N/A';
            weatherData.condition = -1;
            weatherData.is_day = true;
          }
        } catch (e) {
          console.log('Weather JSON parse error: ' + e.message);
          weatherData.temperature = 'Error';
          weatherData.condition = -1;
          weatherData.is_day = true;
        }
      } else {
        console.log('Weather request failed with status: ' + xhr.status + ', response: ' + xhr.responseText);
        weatherData.temperature = 'Error';
        weatherData.condition = -1;
        weatherData.is_day = true;
      }
    }
  };

  xhr.open('GET', url, true);
  xhr.timeout = 15000;
  xhr.ontimeout = function() {
    console.log('Weather request timed out');
    weatherData.temperature = 'Timeout';
    weatherData.condition = -1;
    weatherData.is_day = true;
  };
  xhr.onerror = function() {
    console.log('Weather request network error');
    weatherData.temperature = 'Net Error';
    weatherData.condition = -1;
    weatherData.is_day = true;
  };
  xhr.send();
}


// Fetch the user-configured URL, extract the two lines with the user's
// regexes and send them to the watch.
function extractLine(text, pattern) {
  var m = (text || '').match(pattern);
  if (!m) {
    return null;
  }
  // Prefer the first capture group, fall back to the whole match
  var value = (m.length > 1 && m[1] !== undefined) ? m[1] : m[0];
  return value.trim().substring(0, 32);
}

function fetchCustomUrl() {
  if (!config.customUrl || config.customUrl.trim() === '') {
    console.log('No custom URL configured, skipping fetch');
    return;
  }

  var url = config.customUrl.trim();

  if (!/^(https?|ftp):\/\//i.test(url)) {
    console.log('Custom URL must be a valid URL, skipping: ' + url);
    enqueueMessage('custom_data', { 'CUSTOM_DATA_ERROR': 1 });
    return;
  }

  console.log('Fetching custom URL: ' + url);

  var re1 = null;
  var re2 = null;
  try {
    if (config.customRegexLine1) re1 = new RegExp(config.customRegexLine1);
    if (config.customRegexLine2) re2 = new RegExp(config.customRegexLine2);
  } catch (err) {
    console.log('Invalid custom regex, skipping fetch: ' + err.message);
    enqueueMessage('custom_data', { 'CUSTOM_DATA_ERROR': 1 });
    return;
  }

  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        var text = (xhr.responseText || '').trim();
        var line1 = re1 ? extractLine(text, re1) : text.substring(0, 32);
        var line2 = re2 ? extractLine(text, re2) : '';
        // Only send a line 2 if a line 1 exists, so the watch never shows
        // an orphaned second line or wipes a working single-line value.
        if (line1 === null || line1 === '') {
          console.log('Line 1 is empty, keeping last known value');
          return;
        }
        if (line2 === null) line2 = '';
        console.log('Custom lines: [' + line1 + '] | [' + line2 + ']');
        enqueueMessage('custom_data', { 'CUSTOM_LINE_1': line1, 'CUSTOM_LINE_2': line2 });
      } else {
        // Transient failure - keep showing the last known-good value on the watch
        // instead of overwriting it (same approach as weather).
        console.log('Custom URL request failed with status: ' + xhr.status + ', keeping last known value');
      }
    }
  };

  xhr.open('GET', url, true);
  xhr.timeout = 10000;
  xhr.ontimeout = function() {
    console.log('Custom URL request timed out, keeping last known value');
  };
  xhr.onerror = function() {
    console.log('Custom URL request network error, keeping last known value');
  };
  xhr.send();
}


function colorThemeStrToInt(themeStr) {
  if (themeStr === 'light') {
    return 1;
  } else if (themeStr === 'dynamic') {
    return 2;
  } else if (themeStr === 'quiet') {
    return 3;
  } else {
    return 0; // Default to dark
  }
}


// Message queue - Pebble can only handle one AppMessage in-flight at a time
var messageQueue = [];
var isSending = false;

function sendNextInQueue() {
  if (messageQueue.length === 0) {
    isSending = false;
    return;
  }

  isSending = true;
  var entry = messageQueue.shift();
  console.log('Sending message: ' + entry.label);

  Pebble.sendAppMessage(entry.message,
    function() {
      console.log('Sent successfully: ' + entry.label);
      sendNextInQueue();
    },
    function(e) {
      console.log('Failed to send ' + entry.label + ': ' + JSON.stringify(e));
      // Retry once after a short delay
      if (!entry.retried) {
        entry.retried = true;
        messageQueue.unshift(entry);
        setTimeout(sendNextInQueue, 200);
      } else {
        console.log('Giving up on: ' + entry.label);
        sendNextInQueue();
      }
    }
  );
}

function enqueueMessage(label, message) {
  messageQueue.push({ label: label, message: message, retried: false });
  if (!isSending) {
    sendNextInQueue();
  }
}

// Function to send data to Pebble in smaller chunks
function sendDataToPebble() {
  console.log('Queueing data for pebble.');

  // Message 1: Config settings (all small integers)
  enqueueMessage('config', {
    'COLOR_THEME': colorThemeStrToInt(config.colorTheme),
    'STEP_GOAL': config.stepGoal,
    'TEMPERATURE_UNIT': config.temperatureUnit === 'fahrenheit' ? 1 : 0,
    'ENABLE_ANIMATIONS': config.enableAnimations ? 1 : 0,
    'ENABLE_MESH': config.enableMesh ? 1 : 0,
    'LAYOUT_UPPER_LEFT': config.layoutUpperLeft,
    'LAYOUT_UPPER_RIGHT': config.layoutUpperRight,
    'LAYOUT_LOWER_LEFT': config.layoutLowerLeft,
    'LAYOUT_LOWER_RIGHT': config.layoutLowerRight,
    'DISCONNECT_POSITION': config.disconnectPosition,
    'WEATHER_FORECAST_DURATION': config.forecastDuration,
    'WEATHER_FORECAST_FLICK_MODE': config.forecastFlickMode,
    'DATE_FORMAT': config.dateFormat,
    'LIGHT_SHOW_BACKGROUND': config.lightShowBackground ? 1 : 0,
    'DARK_SHOW_BORDER': config.darkShowBorder ? 1 : 0,
    'VIBRATE_ON_DISCONNECT': config.vibrateOnDisconnect ? 1 : 0,
    'LIGHT_BG_COLOR_ENUM': BG_COLOR_ENUM[config.lightBgColor],
    'DARK_BG_COLOR_ENUM': BG_COLOR_ENUM[config.darkBgColor]
  });

  // Message 2: Weather data + forecast
  // Skip when we only have placeholder data (e.g. right after app start), so a
  // pending push never overwrites the live weather already on the watch.
  if (weatherData.location !== 'Loading...') {
    enqueueMessage('weather', {
      'WEATHER_TEMPERATURE': weatherData.temperature,
      'WEATHER_LOCATION': weatherData.location,
      'WEATHER_CONDITION': weatherData.condition,
      'WEATHER_IS_DAY': weatherData.is_day ? 1 : 0,
      'FORECAST_TEMP_1': weatherData.forecast[0].temp,
      'FORECAST_TEMP_2': weatherData.forecast[1].temp,
      'FORECAST_TEMP_3': weatherData.forecast[2].temp,
      'FORECAST_CONDITION_1': weatherData.forecast[0].condition,
      'FORECAST_CONDITION_2': weatherData.forecast[1].condition,
      'FORECAST_CONDITION_3': weatherData.forecast[2].condition
    });
    enqueueMessage('hourly', {
      'HOURLY_TEMPS': weatherData.hourlyTemps,
      'HOURLY_PRECIP': weatherData.hourlyPrecip
    });
  }
}

// Event listeners from app
Pebble.addEventListener('appmessage', function(e) {
  console.log('AppMessage received: ' + JSON.stringify(e.payload));
  
  // Check if it's a weather update request
  if (e.payload.WEATHER_REQUEST) {
    console.log('Weather update requested from watch');
    fetchWeatherForLocation();
  }

  // Check if it's a custom URL update request
  if (e.payload.CUSTOM_URL_REQUEST) {
    if (isCustomDataNeeded()) {
      console.log('Custom URL update requested from watch');
      fetchCustomUrl();
    } else {
      console.log('Custom URL update requested but no custom data slot configured, skipping');
    }
  }
  
  // Check if it's a location configuration update
  if (e.payload.WEATHER_LOCATION_CONFIG) {
    config.location = e.payload.WEATHER_LOCATION_CONFIG;
    console.log('Location configuration updated to: ' + config.location);
    fetchWeatherForLocation();
  }
});


Pebble.addEventListener('webviewclosed', function(e) {
  if (e && !e.response) {
    return;
  }
  
  // Get the keys and values from Clay
  // Get the keys and values from each config item
  var dict = clay.getSettings(e.response, false);
  console.log('Configuration received: ' + JSON.stringify(dict));
  var layoutChanged = false;

  // Update all config values first before any sendDataToPebble() calls,
  // since AppMessage can only handle one in-flight message at a time.
  if (dict.DISCONNECT_POSITION) {
    config.disconnectPosition = parseInt(dict.DISCONNECT_POSITION.value);
    localStorage.setItem('DISCONNECT_POSITION', config.disconnectPosition);
    console.log('Disconnect position saved to: ' + config.disconnectPosition);
  }

  if (dict.WEATHER_LOCATION_CONFIG !== undefined) {
    config.location = dict.WEATHER_LOCATION_CONFIG.value || ''; // Empty string for GPS
    localStorage.setItem('WEATHER_LOCATION_CONFIG', config.location);
    console.log('Location saved to: "' + config.location + '" (empty = GPS)');
    fetchWeatherForLocation();
  }
  
  if (dict.COLOR_THEME) {
    config.colorTheme = dict.COLOR_THEME.value;
    localStorage.setItem('COLOR_THEME', config.colorTheme);
    console.log('Color theme saved to: ' + config.colorTheme);
    layoutChanged = true;
  }
  
  if (dict.STEP_GOAL) {
    config.stepGoal = parseInt(dict.STEP_GOAL.value);
    localStorage.setItem('STEP_GOAL', config.stepGoal);
    console.log('Step goal saved to: ' + config.stepGoal);
    layoutChanged = true;
  }
  
  if (dict.TEMPERATURE_UNIT) {
    config.temperatureUnit = dict.TEMPERATURE_UNIT.value;
    localStorage.setItem('TEMPERATURE_UNIT', config.temperatureUnit);
    console.log('Temperature unit saved to: ' + config.temperatureUnit);
    fetchWeatherForLocation(); // Fetch weather again with new unit
  }

  if (dict.ENABLE_ANIMATIONS) {
    config.enableAnimations = dict.ENABLE_ANIMATIONS.value;
    localStorage.setItem('ENABLE_ANIMATIONS', config.enableAnimations);
    console.log('Enable animations saved to: ' + config.enableAnimations);
    layoutChanged = true;
  }

  if (dict.ENABLE_MESH) {
    config.enableMesh = dict.ENABLE_MESH.value;
    localStorage.setItem('ENABLE_MESH', config.enableMesh);
    console.log('Enable mesh saved to: ' + config.enableMesh);
    layoutChanged = true;
  }

  if (dict.LIGHT_SHOW_BACKGROUND) {
    config.lightShowBackground = dict.LIGHT_SHOW_BACKGROUND.value;
    localStorage.setItem('LIGHT_SHOW_BACKGROUND', config.lightShowBackground);
    console.log('Light show background saved to: ' + config.lightShowBackground);
    layoutChanged = true;
  }

  if (dict.DARK_SHOW_BORDER) {
    config.darkShowBorder = dict.DARK_SHOW_BORDER.value;
    localStorage.setItem('DARK_SHOW_BORDER', config.darkShowBorder);
    console.log('Dark show border saved to: ' + config.darkShowBorder);
    layoutChanged = true;
  }

  if (dict.LIGHT_BG_COLOR_ENUM !== undefined && isValidBgColor(dict.LIGHT_BG_COLOR_ENUM.value)) {
    config.lightBgColor = dict.LIGHT_BG_COLOR_ENUM.value;
    localStorage.setItem('LIGHT_BG_COLOR_ENUM', config.lightBgColor);
    console.log('Light background color saved to: ' + config.lightBgColor);
    layoutChanged = true;
  }

  if (dict.DARK_BG_COLOR_ENUM !== undefined && isValidBgColor(dict.DARK_BG_COLOR_ENUM.value)) {
    config.darkBgColor = dict.DARK_BG_COLOR_ENUM.value;
    localStorage.setItem('DARK_BG_COLOR_ENUM', config.darkBgColor);
    console.log('Dark background color saved to: ' + config.darkBgColor);
    layoutChanged = true;
  }

  if (dict.VIBRATE_ON_DISCONNECT !== undefined) {
    config.vibrateOnDisconnect = dict.VIBRATE_ON_DISCONNECT.value;
    localStorage.setItem('VIBRATE_ON_DISCONNECT', config.vibrateOnDisconnect);
    console.log('Vibrate on disconnect saved to: ' + config.vibrateOnDisconnect);
    layoutChanged = true;
  }

  var customUrlChanged = false;
  if (dict.CUSTOM_URL !== undefined) {
    config.customUrl = dict.CUSTOM_URL.value || '';
    localStorage.setItem('CUSTOM_URL', config.customUrl);
    console.log('Custom URL saved to: ' + config.customUrl);
    customUrlChanged = true;
  }
  if (dict.CUSTOM_REGEX_1 !== undefined) {
    config.customRegexLine1 = dict.CUSTOM_REGEX_1.value || '';
    localStorage.setItem('CUSTOM_REGEX_1', config.customRegexLine1);
    console.log('Custom line 1 regex saved to: ' + config.customRegexLine1);
    customUrlChanged = true;
  }
  if (dict.CUSTOM_REGEX_2 !== undefined) {
    config.customRegexLine2 = dict.CUSTOM_REGEX_2.value || '';
    localStorage.setItem('CUSTOM_REGEX_2', config.customRegexLine2);
    console.log('Custom line 2 regex saved to: ' + config.customRegexLine2);
    customUrlChanged = true;
  }
  if (customUrlChanged && isCustomDataNeeded()) {
    fetchCustomUrl();
  }

  if (dict.DATE_FORMAT !== undefined) {
    config.dateFormat = dict.DATE_FORMAT.value || ' %a %d';
    localStorage.setItem('DATE_FORMAT', config.dateFormat);
    console.log('Date format saved to: ' + config.dateFormat);
    layoutChanged = true;
  }

  if (dict.WEATHER_FORECAST_DURATION) {
    config.forecastDuration = parseInt(dict.WEATHER_FORECAST_DURATION.value);
    localStorage.setItem('WEATHER_FORECAST_DURATION', config.forecastDuration);
    console.log('Forecast duration saved to: ' + config.forecastDuration);
    layoutChanged = true;
  }

  if (dict.WEATHER_FORECAST_FLICK_MODE) {
    config.forecastFlickMode = parseInt(dict.WEATHER_FORECAST_FLICK_MODE.value);
    localStorage.setItem('WEATHER_FORECAST_FLICK_MODE', config.forecastFlickMode);
    console.log('Forecast flick mode saved to: ' + config.forecastFlickMode);
    layoutChanged = true;
  }

  if (dict.LAYOUT_UPPER_LEFT) {
    config.layoutUpperLeft = parseInt(dict.LAYOUT_UPPER_LEFT.value);
    localStorage.setItem('LAYOUT_UPPER_LEFT', config.layoutUpperLeft);
    layoutChanged = true;
  }
  if (dict.LAYOUT_UPPER_RIGHT) {
    config.layoutUpperRight = parseInt(dict.LAYOUT_UPPER_RIGHT.value);
    localStorage.setItem('LAYOUT_UPPER_RIGHT', config.layoutUpperRight);
    layoutChanged = true;
  }
  if (dict.LAYOUT_LOWER_LEFT) {
    config.layoutLowerLeft = parseInt(dict.LAYOUT_LOWER_LEFT.value);
    localStorage.setItem('LAYOUT_LOWER_LEFT', config.layoutLowerLeft);
    layoutChanged = true;
  }
  if (dict.LAYOUT_LOWER_RIGHT) {
    config.layoutLowerRight = parseInt(dict.LAYOUT_LOWER_RIGHT.value);
    localStorage.setItem('LAYOUT_LOWER_RIGHT', config.layoutLowerRight);
    layoutChanged = true;
  }
  if (layoutChanged) {
    console.log('Layout saved: ' + config.layoutUpperLeft + ',' + config.layoutUpperRight + ',' + config.layoutLowerLeft + ',' + config.layoutLowerRight);
    sendDataToPebble();
  }

});

// Update weather/custom data every 30 minutes
setInterval(function() {
  console.log('Periodic update (30min timer)');
  fetchWeatherForLocation();
  if (isCustomDataNeeded()) fetchCustomUrl();
}, 30 * 60 * 1000);


// Handle Pebble ready event
Pebble.addEventListener('ready', function() {
  console.log('PebbleKit JS ready!');
  // Push layout/config to watch immediately so panels are correct before data arrives
  sendDataToPebble();
});


// Handle configuration page request
Pebble.addEventListener('showConfiguration', function() {
  console.log('Showing configuration page');
  Pebble.openURL(clay.generateUrl());
});
