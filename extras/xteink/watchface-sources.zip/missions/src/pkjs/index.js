// PebbleKit JS — Space Mission Watchface
// Stations: wheretheiss.at (ISS NORAD 25544), N2YO (CSS NORAD 48274)
// Missions: Launch Library 2 — cached in localStorage for 1 hour

var CACHE_KEY = 'spc_v8'; // bumped: 14-char mission names
var STATION_CACHE_KEY = 'spc_stations_v1';
var CACHE_TTL = 3600000; // 1 hour in ms
var N2YO_KEY_STORAGE = 'n2yo_key';
var SETTINGS_STORAGE = 'spc_settings_v1';

// Display filters — all on by default. Persisted in localStorage and mirrored
// to the watch (which also persists them itself).
var DEFAULT_SETTINGS = {
    show_iss: 1, show_css: 1, show_roadster: 1, show_missions: 1,
    show_us: 1, show_cn: 1, show_eu: 1, show_ru: 1
};

function getSettings() {
    try {
        var raw = localStorage.getItem(SETTINGS_STORAGE);
        if (!raw) return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
        var s = JSON.parse(raw);
        var out = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
        for (var k in DEFAULT_SETTINGS) {
            if (s[k] !== undefined) out[k] = s[k] ? 1 : 0;
        }
        return out;
    } catch(e) { return JSON.parse(JSON.stringify(DEFAULT_SETTINGS)); }
}

function saveSettings(s) {
    try { localStorage.setItem(SETTINGS_STORAGE, JSON.stringify(s)); }
    catch(e) { console.log('Settings save error: ' + e); }
}

// Add the display-filter keys to an outgoing message.
function addSettingsMsg(msg) {
    var s = getSettings();
    msg['SHOW_ISS']      = s.show_iss;
    msg['SHOW_CSS']      = s.show_css;
    msg['SHOW_ROADSTER'] = s.show_roadster;
    msg['SHOW_MISSIONS'] = s.show_missions;
    msg['SHOW_US']       = s.show_us;
    msg['SHOW_CN']       = s.show_cn;
    msg['SHOW_EU']       = s.show_eu;
    msg['SHOW_RU']       = s.show_ru;
}

// Push just the settings to the watch (used right after the config closes,
// so changes apply immediately without waiting on a network fetch).
function sendSettings() {
    var msg = {};
    addSettingsMsg(msg);
    Pebble.sendAppMessage(msg,
        function() { console.log('Settings sent OK'); },
        function() { console.log('Failed to send settings'); }
    );
}

var s_userLat = 0;
var s_userLon = 0;
var s_pendingRequests = 0;
var s_issResult = null;
var s_cssResult = null;
var s_missionsResult = null;

function getN2YOKey() {
    try {
        var key = localStorage.getItem(N2YO_KEY_STORAGE);
        return key || '';
    } catch(e) { return ''; }
}

// ---- XHR helper ----

var xhrRequest = function(url, type, callback) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function() { callback(this.responseText); };
    xhr.onerror = function() {
        console.log('XHR error: ' + url);
        callback(null);
    };
    xhr.open(type, url);
    xhr.send();
};

// ---- Station cache (localStorage) ----

function saveStationCache(issLon, cssLon) {
    try {
        localStorage.setItem(STATION_CACHE_KEY, JSON.stringify({
            ts: Date.now(),
            iss_lon: issLon,
            css_lon: cssLon
        }));
    } catch(e) { console.log('Station cache save error: ' + e); }
}

function loadStationCache() {
    try {
        var raw = localStorage.getItem(STATION_CACHE_KEY);
        if (!raw) return null;
        var c = JSON.parse(raw);
        if ((Date.now() - c.ts) < CACHE_TTL) return c;
        return null;
    } catch(e) { return null; }
}

// ---- Mission cache (localStorage) ----

function loadMissionCache() {
    try {
        var raw = localStorage.getItem(CACHE_KEY);
        if (!raw) return null;
        return JSON.parse(raw);
    } catch(e) { return null; }
}

function saveMissionCache(missions) {
    try {
        localStorage.setItem(CACHE_KEY, JSON.stringify({
            ts: Date.now(),
            missions: missions
        }));
    } catch(e) {
        console.log('Cache save error: ' + e);
    }
}

function isMissionCacheValid() {
    var c = loadMissionCache();
    return c !== null &&
           (Date.now() - c.ts) < CACHE_TTL &&
           c.missions && c.missions.length > 0;  // don't serve empty cache
}

// ---- Data mapping ----

function agencyToCountry(abbrev) {
    if (!abbrev) return 0;
    var a = abbrev.toUpperCase();
    if (a === 'CNSA') return 1;
    if (a === 'ESA' || a === 'CNES' || a === 'DLR' || a === 'ASI') return 2;
    if (a === 'ROSCOSMOS' || a === 'RSC ENERGIA' || a === 'RKA' || a === 'ROSKOSMOS') return 3;
    return 0;
}

// Returns orbit code:
// 0=ORBIT_EARTH, 1=ORBIT_MOON, 2=TRANSIT_TO_MOON, 3=TRANSIT_TO_EARTH, 4=ORBIT_DOCKED
function isLunarMission(destination, orbitName) {
    var d = (destination || '').toLowerCase();
    var o = (orbitName || '').toLowerCase();
    return d.indexOf('lunar') >= 0 || d.indexOf('moon') >= 0 ||
           o.indexOf('lunar') >= 0;
}

// Returns orbit code:
// 0=ORBIT_EARTH, 1=ORBIT_MOON, 2=TRANSIT_TO_MOON, 3=TRANSIT_TO_EARTH, 4=ORBIT_DOCKED
function destinationToOrbit(destination, orbitName, launchDateStr) {
    var d = (destination || '').toLowerCase();
    // Docked to CSS/Tiangong (check before generic "space station")
    if (d.indexOf('tiangong') >= 0 || d.indexOf('chinese space station') >= 0) {
        return 6;  // ORBIT_DOCKED_CSS
    }
    // Docked to ISS
    if (d === 'iss' ||
        d.indexOf('international space station') >= 0 ||
        d.indexOf('space station') >= 0) {
        return 4;  // ORBIT_DOCKED
    }
    // Moon or lunar missions
    if (isLunarMission(destination, orbitName)) {
        if (launchDateStr) {
            var daysSinceLaunch = (Date.now() - new Date(launchDateStr).getTime()) / 86400000;
            if (daysSinceLaunch < 4) return 2;
        }
        return 1;
    }
    // Heliocentric / deep space
    if (d.indexOf('heliocentric') >= 0 || d.indexOf('deep space') >= 0 ||
        d.indexOf('solar orbit') >= 0) {
        return 5;
    }
    return 0;
}

// Returns the longitude of the station a docked spacecraft is attached to
function dockedStationLon(destination, issLon, cssLon) {
    if (!destination) return issLon;
    var d = destination.toLowerCase();
    if (d.indexOf('tiangong') >= 0 || d.indexOf('chinese space station') >= 0) return cssLon;
    return issLon;
}

// ---- Send to watch ----

// Build the mission portion of a message (country, orbit, name for each slot)
function buildMissionMsg(msg, missions, issLon, cssLon) {
    for (var i = 0; i < Math.min(missions.length, 10); i++) {
        var m = missions[i];
        msg['MISSION_' + i + '_COUNTRY'] = m.country;
        msg['MISSION_' + i + '_ORBIT']   = m.orbit;
        msg['MISSION_' + i + '_NAME']    = m.name || '';
        if (m.orbit === 4) {
            msg['MISSION_' + i + '_LON'] = dockedStationLon(m.destination, issLon, cssLon);
        }
    }
}

// Send cached missions immediately so the watch isn't blank while stations load
function sendCachedMissionsEarly() {
    var missions = s_missionsResult;
    var sc = loadStationCache();
    var issLon = sc ? sc.iss_lon : 0;
    var cssLon = sc ? sc.css_lon : 0;
    var msg = { 'USER_LON': Math.round(s_userLon) };
    if (sc) {
        msg['ISS_LON'] = issLon;
        msg['CSS_LON'] = cssLon;
        console.log('Station cache hit: ISS=' + issLon + ' CSS=' + cssLon);
    }
    buildMissionMsg(msg, missions, issLon, cssLon);
    addSettingsMsg(msg);
    console.log('Sending cached missions early (' + missions.length + ')');
    Pebble.sendAppMessage(msg,
        function() { console.log('Early missions sent OK'); },
        function() { console.log('Failed to send early missions'); }
    );
}

function sendDataWhenReady() {
    if (s_pendingRequests > 0) return;
    if (!s_issResult || !s_cssResult || !s_missionsResult) return;

    var msg = {
        'USER_LON':    Math.round(s_userLon),
        'ISS_VISIBLE': s_issResult.visible,
        'ISS_LON':     s_issResult.lon,
        'CSS_VISIBLE': s_cssResult.visible,
        'CSS_LON':     s_cssResult.lon
    };
    buildMissionMsg(msg, s_missionsResult, s_issResult.lon, s_cssResult.lon);
    addSettingsMsg(msg);

    saveStationCache(s_issResult.lon, s_cssResult.lon);

    console.log('Sending: ISS=' + s_issResult.visible + '@' + s_issResult.lon +
                ' CSS=' + s_cssResult.visible + '@' + s_cssResult.lon +
                ' missions=' + s_missionsResult.length);

    Pebble.sendAppMessage(
        msg,
        function() { console.log('Data sent OK'); },
        function() { console.log('Failed to send data'); }
    );
}

// ---- Fetch: stations (always fresh) ----

// Returns true if a satellite at (satLat, satLon) degrees and altKm altitude
// is geometrically above the horizon as seen from (userLat, userLon).
// Uses great-circle angular separation vs. the Earth-limb angle for that altitude.
function isAboveHorizon(userLat, userLon, satLat, satLon, altKm) {
    var R = 6371;
    // Satellite is above horizon when great-circle angle < arccos(R / (R+h)),
    // equivalent to cos(angle) > R / (R+h).
    var maxCos = R / (R + altKm);
    var lat1 = userLat * Math.PI / 180;
    var lat2 = satLat  * Math.PI / 180;
    var dLon  = (satLon - userLon) * Math.PI / 180;
    var cosAngle = Math.sin(lat1) * Math.sin(lat2) +
                   Math.cos(lat1) * Math.cos(lat2) * Math.cos(dLon);
    return cosAngle > maxCos;
}

function fetchStation(noradId, callback) {
    var url = 'https://api.wheretheiss.at/v1/satellites/' + noradId;
    xhrRequest(url, 'GET', function(responseText) {
        if (responseText) {
            try {
                var j = JSON.parse(responseText);
                var lon = parseFloat(j.longitude);
                var lat = parseFloat(j.latitude);
                var alt = parseFloat(j.altitude);
                if (isNaN(lon) || isNaN(lat)) {
                    console.log('Station ' + noradId + ': position missing in response');
                    callback({ visible: 0, lon: 0 });
                    return;
                }
                if (isNaN(alt)) alt = 408; // typical ISS altitude fallback
                var visible = isAboveHorizon(s_userLat, s_userLon, lat, lon, alt) ? 1 : 0;
                console.log('Station ' + noradId + ': lat=' + lat.toFixed(1) +
                            ' lon=' + Math.round(lon) + ' alt=' + Math.round(alt) +
                            ' visible=' + visible);
                callback({ visible: visible, lon: Math.round(lon) });
                return;
            } catch(e) {
                console.log('Station parse error (' + noradId + '): ' + e);
            }
        }
        console.log('Station ' + noradId + ': no response');
        callback({ visible: 0, lon: 0 });
    });
}

function fetchISS() {
    s_pendingRequests++;
    fetchStation(25544, function(result) {
        s_pendingRequests--;
        s_issResult = result;
        sendDataWhenReady();
    });
}

function fetchCSS() {
    var key = getN2YOKey();
    if (!key) {
        s_cssResult = { visible: 0, lon: 0 };
        sendDataWhenReady();
        return;
    }
    s_pendingRequests++;
    var url = 'https://api.n2yo.com/rest/v1/satellite/positions/48274/' +
              s_userLat + '/' + s_userLon + '/0/1/&apiKey=' + key;
    xhrRequest(url, 'GET', function(responseText) {
        s_pendingRequests--;
        if (responseText) {
            try {
                var j = JSON.parse(responseText);
                var pos = j.positions && j.positions[0];
                if (pos) {
                    var lon = parseFloat(pos.satlongitude);
                    if (!isNaN(lon)) {
                        var visible = (pos.elevation > 0) ? 1 : 0;
                        s_cssResult = { visible: visible, lon: Math.round(lon) };
                        console.log('CSS: lat=' + (pos.satlatitude || '?') +
                                    ' lon=' + Math.round(lon) + ' elev=' + pos.elevation.toFixed(1) +
                                    ' visible=' + visible);
                        sendDataWhenReady();
                        return;
                    }
                }
                console.log('CSS: unexpected N2YO response');
            } catch(e) {
                console.log('CSS parse error: ' + e);
            }
        } else {
            console.log('CSS: N2YO request failed');
        }
        s_cssResult = { visible: 0, lon: 0 };
        sendDataWhenReady();
    });
}

// ---- Fetch: missions (cached 1 hour via LL2) ----

function fetchMissions() {
    // Serve from cache if still valid — send immediately, don't wait for stations
    if (isMissionCacheValid()) {
        var c = loadMissionCache();
        s_missionsResult = c.missions;
        console.log('Missions from cache (' + s_missionsResult.length + ')');
        sendCachedMissionsEarly();
        // sendDataWhenReady() will fire again once ISS/CSS fetches complete
        return;
    }

    s_pendingRequests++;
    var url = 'https://ll.thespacedevs.com/2.3.0/spacecraft_flights/' +
              '?limit=20&ordering=-mission_end&format=json';
    xhrRequest(url, 'GET', function(responseText) {
        s_pendingRequests--;
        if (responseText) {
            try {
                var json = JSON.parse(responseText);
                var results = json.results || [];
                var inSpaceResults = results.filter(function(f) { return f.spacecraft && f.spacecraft.in_space; });
                console.log('LL2: ' + results.length + ' total, ' + inSpaceResults.length + ' in_space=true');
                var missions = [];

                for (var i = 0; i < results.length && missions.length < 10; i++) {
                    var flight = results[i];

                    // Only include spacecraft currently in space
                    if (!flight.spacecraft || !flight.spacecraft.in_space) continue;

                    var agency = null;
                    // 1. spacecraft_config.agency
                    if (!agency && flight.spacecraft && flight.spacecraft.spacecraft_config &&
                        flight.spacecraft.spacecraft_config.agency) {
                        agency = flight.spacecraft.spacecraft_config.agency.abbrev;
                    }
                    // 2. launch.launch_service_provider
                    if (!agency && flight.launch && flight.launch.launch_service_provider) {
                        agency = flight.launch.launch_service_provider.abbrev;
                    }
                    // 3. mission.agencies[0]
                    if (!agency && flight.mission && flight.mission.agencies &&
                        flight.mission.agencies.length > 0) {
                        agency = flight.mission.agencies[0].abbrev;
                    }
                    // 4. crew fallback
                    if (!agency && flight.crew && flight.crew.length > 0 &&
                        flight.crew[0].astronaut && flight.crew[0].astronaut.agency) {
                        agency = flight.crew[0].astronaut.agency.abbrev;
                    }

                    var destination = flight.destination || '';
                    var orbitName   = (flight.mission && flight.mission.orbit) ? flight.mission.orbit.name : '';
                    var launchDate  = flight.launch ? flight.launch.net : null;
                    var orbit       = destinationToOrbit(destination, orbitName, launchDate);
                    var country     = agencyToCountry(agency);

                    var name = '';
                    if (flight.spacecraft && flight.spacecraft.spacecraft_config &&
                        flight.spacecraft.spacecraft_config.name) {
                        name = flight.spacecraft.spacecraft_config.name.substring(0, 14).toUpperCase();
                    }

                    console.log('Mission: "' + name + '" dest="' + destination +
                                '" orbitName="' + orbitName + '" orbit=' + orbit);
                    missions.push({ country: country, orbit: orbit, name: name, destination: destination });
                }

                s_missionsResult = missions;
                saveMissionCache(missions);
            } catch(e) {
                console.log('LL2 parse error: ' + e);
                s_missionsResult = [];
            }
        } else {
            s_missionsResult = [];
        }
        sendDataWhenReady();
    });
}

// ---- Entry points ----

function fetchAllData() {
    s_issResult = null;
    s_cssResult = null;
    s_missionsResult = null;
    fetchISS();
    fetchCSS();
    fetchMissions();
}

function getLocationAndFetch() {
    navigator.geolocation.getCurrentPosition(
        function(pos) {
            s_userLat = pos.coords.latitude;
            s_userLon = pos.coords.longitude;
            console.log('Location: ' + s_userLat.toFixed(4) + ',' + s_userLon.toFixed(4));
            fetchAllData();
        },
        function(err) {
            console.log('Geolocation error: ' + err.message);
            fetchAllData();
        },
        { timeout: 15000, maximumAge: 300000 }
    );
}

Pebble.addEventListener('ready', function() {
    console.log('Space Mission Watchface JS ready');
    getLocationAndFetch();
});

Pebble.addEventListener('appmessage', function(e) {
    if (e.payload['REQUEST_UPDATE']) {
        console.log('Watch requested update');
        getLocationAndFetch();
    }
});

Pebble.addEventListener('showConfiguration', function() {
    var currentKey = getN2YOKey();
    var s = getSettings();
    function chk(v) { return v ? ' checked' : ''; }
    var html = '<!DOCTYPE html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">' +
        '<style>body{font-family:sans-serif;background:#1a1a2e;color:#eee;padding:20px;margin:0}' +
        'h2{color:#e94560;margin-top:0}h3{color:#e94560;font-size:15px;margin:20px 0 8px}' +
        'label{display:block;margin-bottom:6px;font-size:14px}' +
        'input[type=text]{width:100%;box-sizing:border-box;padding:10px;background:#16213e;color:#eee;' +
        'border:1px solid #e94560;border-radius:4px;font-size:14px;margin-bottom:16px}' +
        '.row{display:flex;align-items:center;padding:8px 0;font-size:15px}' +
        '.row input{width:20px;height:20px;margin-right:12px}' +
        'button{width:100%;padding:12px;background:#e94560;color:#fff;border:none;' +
        'border-radius:4px;font-size:16px;cursor:pointer;margin-top:20px}' +
        'p{font-size:12px;color:#aaa;margin-top:12px}' +
        'hr{border:none;border-top:1px solid #333;margin:20px 0}</style></head>' +
        '<body><h2>Space Mission Settings</h2>' +
        '<h3>Show on watchface</h3>' +
        '<label class="row"><input type="checkbox" id="show_iss"'      + chk(s.show_iss)      + '>ISS</label>' +
        '<label class="row"><input type="checkbox" id="show_css"'      + chk(s.show_css)      + '>Tiangong (CSS)</label>' +
        '<label class="row"><input type="checkbox" id="show_roadster"' + chk(s.show_roadster) + '>Tesla Roadster</label>' +
        '<label class="row"><input type="checkbox" id="show_missions"' + chk(s.show_missions) + '>Live missions</label>' +
        '<h3>Mission agencies</h3>' +
        '<label class="row"><input type="checkbox" id="show_us"' + chk(s.show_us) + '>USA</label>' +
        '<label class="row"><input type="checkbox" id="show_cn"' + chk(s.show_cn) + '>China</label>' +
        '<label class="row"><input type="checkbox" id="show_eu"' + chk(s.show_eu) + '>Europe</label>' +
        '<label class="row"><input type="checkbox" id="show_ru"' + chk(s.show_ru) + '>Russia</label>' +
        '<p>Agency filters apply to live missions only.</p>' +
        '<hr>' +
        '<label for="key">N2YO API Key (for CSS real-time position)</label>' +
        '<input type="text" id="key" placeholder="Your personal key" value="' + currentKey + '">' +
        '<p>Get a free key at <strong>n2yo.com</strong>.</p>' +
        '<button onclick="save()">Save</button>' +
        '<script>function cb(id){return document.getElementById(id).checked?1:0;}' +
        'function save(){var k=document.getElementById("key").value.trim();' +
        'var cfg={n2yo_key:k.length>0?k:"",' +
        'show_iss:cb("show_iss"),show_css:cb("show_css"),show_roadster:cb("show_roadster"),' +
        'show_missions:cb("show_missions"),show_us:cb("show_us"),show_cn:cb("show_cn"),' +
        'show_eu:cb("show_eu"),show_ru:cb("show_ru")};' +
        'location.href="pebblejs://close#"+encodeURIComponent(JSON.stringify(cfg));' +
        '}<\/script></body></html>';
    Pebble.openURL('data:text/html,' + encodeURIComponent(html));
});

Pebble.addEventListener('webviewclosed', function(e) {
    if (!e || !e.response || e.response === 'CANCELLED') return;
    try {
        var config = JSON.parse(decodeURIComponent(e.response));
        if (config.n2yo_key !== undefined) {
            if (config.n2yo_key.length > 0) {
                localStorage.setItem(N2YO_KEY_STORAGE, config.n2yo_key);
                console.log('N2YO key saved');
            } else {
                localStorage.removeItem(N2YO_KEY_STORAGE);
                console.log('N2YO key cleared');
            }
        }

        // Persist display filters and push them to the watch right away
        var s = getSettings();
        var keys = ['show_iss','show_css','show_roadster','show_missions',
                    'show_us','show_cn','show_eu','show_ru'];
        for (var i = 0; i < keys.length; i++) {
            if (config[keys[i]] !== undefined) s[keys[i]] = config[keys[i]] ? 1 : 0;
        }
        saveSettings(s);
        sendSettings();

        getLocationAndFetch();
    } catch(e2) {
        console.log('Config parse error: ' + e2);
    }
});
