# Rebuild a Pro watchface

Build or extract the combined Xteink SDK using the [branch README](https://github.com/ericmigi/PebbleOS/blob/codex/xteink-combined/README.md). Install the SDK Python dependencies, Node.js/npm, the SDK webpack dependencies, CMake, Ninja, ARM GCC and the Espressif Xtensa toolchain. Set PEBBLE_PYTHON to the SDK Python executable and PEBBLE_NODE_MODULES to the installed Pebble SDK's node_modules directory if they are outside the SDK tree.

Run `bash rebuild.sh arcminute-xteinkx4pro /path/to/sdk-core/pebble build/arcminute`. Each face directory contains its Pro manifest, app source and resources. For all faces, run `for manifest in */package.json; do face=${manifest%/package.json}; bash rebuild.sh "$face" /path/to/sdk-core/pebble "build/$face" || exit 1; done` starting from a clean extraction. WATCHFACES.csv attributes each source and identifies the tested PBW. The original projects retain their respective licenses.
