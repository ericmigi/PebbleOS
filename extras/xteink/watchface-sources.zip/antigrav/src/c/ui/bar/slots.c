#include <pebble.h>
#include "slots.h"
#include "battery_bar.h"
#include "phone_battery_bar.h"
#include "combo_slot.h"
#include "steps_bar.h"
#include "seconds_slot.h"
#include "seconds_bar.h"
#include "status_bar.h"
#include "empty_bar.h"
#include "../../settings.h"

void slots_init()
{
    int battery_mask = 0;
    int phone_battery_mask = 0;
    int combo_a_mask = 0;
    int combo_b_mask = 0;
    int combo_c_mask = 0;
    int icons_mask = 0;
    int steps_mask = 0;
    int seconds_mask = 0;
    int seconds_bar_mask = 0;
    int none_mask = 0;
    int bit = 0;
    SlotContent content = SLOT_CONTENT_NONE;
    for (int i = 0; i < 3; i++)
    {
        content = settings_get_slot_content(i);
        switch (i)
        {
        case 0:
            bit = 4;
            break;
        case 1:
            bit = 2;
            break;
        case 2:
            bit = 1;
            break;
        default:
        }

        switch (content)
        {
        case SLOT_CONTENT_ICONS:
            icons_mask += bit;
            break;
        case SLOT_CONTENT_BATTERY:
            battery_mask += bit;
            break;
        case SLOT_CONTENT_PHONE_BATTERY:
            phone_battery_mask += bit;
            break;
        case SLOT_CONTENT_COMBO_A:
            combo_a_mask += bit;
            break;
        case SLOT_CONTENT_COMBO_B:
            combo_b_mask += bit;
            break;
        case SLOT_CONTENT_COMBO_C:
            combo_c_mask += bit;
            break;
        case SLOT_CONTENT_STEPS:
            steps_mask += bit;
            break;
        case SLOT_CONTENT_SECONDS:
            seconds_mask += bit;
            break;
        case SLOT_CONTENT_SECONDS_BAR:
            seconds_bar_mask += bit;
            break;
        case SLOT_CONTENT_NONE:
            none_mask += bit;
            break;
        default:
        }
    }

    GRect slots_frame = GRect(SLOTS_X, SLOTS_Y, SLOTS_W, SLOTS_H);
    battery_bar_init(battery_mask, slots_frame);
    phone_battery_bar_init(phone_battery_mask, slots_frame);
    combo_slot_init(combo_a_mask, combo_b_mask, combo_c_mask, slots_frame);
    steps_bar_init(steps_mask, slots_frame);
    seconds_slot_init(seconds_mask, slots_frame);
    seconds_bar_init(seconds_bar_mask, slots_frame);
    status_bar_init(icons_mask, slots_frame);
    empty_bar_init(none_mask, slots_frame);
}

void slots_deinit()
{
    empty_bar_deinit();
    status_bar_deinit();
    seconds_bar_deinit();
    seconds_slot_deinit();
    steps_bar_deinit();
    combo_slot_deinit();
    phone_battery_bar_deinit();
    battery_bar_deinit();
}

static void slots_mask_change(SlotPlaceholder placeholder, char bits, bool include)
{
    switch (placeholder)
    {
    case SLOT_PLACEHOLDER_BATTERY:
        if (include)
        {
            battery_bar_mask_include(bits);
        }
        else
        {
            battery_bar_mask_exclude(bits);
        }
        break;
    case SLOT_PLACEHOLDER_PHONE_BATTERY:
        if (include)
        {
            phone_battery_bar_mask_include(bits);
        }
        else
        {
            phone_battery_bar_mask_exclude(bits);
        }
        break;
    case SLOT_PLACEHOLDER_STEPS:
        if (include)
        {
            steps_bar_mask_include(bits);
        }
        else
        {
            steps_bar_mask_exclude(bits);
        }
        break;
    case SLOT_PLACEHOLDER_COMBO_A:
        if (include)
        {
            combo_slot_mask_include(COMBO_BAR_A, bits);
        }
        else
        {
            combo_slot_mask_exclude(COMBO_BAR_A, bits);
        }
        break;
    case SLOT_PLACEHOLDER_COMBO_B:
        if (include)
        {
            combo_slot_mask_include(COMBO_BAR_B, bits);
        }
        else
        {
            combo_slot_mask_exclude(COMBO_BAR_B, bits);
        }
        break;
    case SLOT_PLACEHOLDER_COMBO_C:
        if (include)
        {
            combo_slot_mask_include(COMBO_BAR_C, bits);
        }
        else
        {
            combo_slot_mask_exclude(COMBO_BAR_C, bits);
        }
        break;
    default:
        break;
    }
}

void slots_mask_include(SlotPlaceholder placeholder, char bits)
{
    slots_mask_change(placeholder, bits, true);
}

void slots_mask_exclude(SlotPlaceholder placeholder, char bits)
{
    slots_mask_change(placeholder, bits, false);
}