/**
 * This file was generated with Enamel : http://gregoiresage.github.io/enamel
 */

#include <pebble.h>
#include <@rebble/linked-list/linked-list.h>
#include <pebble-events/pebble-events.h>
#include "enamel.h"

#ifndef ENAMEL_MAX_STRING_LENGTH
#define ENAMEL_MAX_STRING_LENGTH 100
#endif

#define ENAMEL_PKEY 3000000000
#define ENAMEL_DICT_PKEY (ENAMEL_PKEY+1)

typedef struct {
	EnamelSettingsReceivedHandler *handler;
	void *context;
} SettingsReceivedState;

static LinkedRoot *s_handler_list;

static EventHandle s_event_handle;

static DictionaryIterator s_dict;
static uint8_t* s_dict_buffer = NULL;
static uint32_t s_dict_size = 0;

static bool s_config_changed;

// -----------------------------------------------------
// Getter for 'background'
GColor enamel_get_background(){
	Tuple* tuple = dict_find(&s_dict, 3202544658);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0x000000);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'drawHourOutline'
bool enamel_get_drawHourOutline(){
	Tuple* tuple = dict_find(&s_dict, 228125679);
	return tuple ? tuple->value->int32 == 1 : false;
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'hourOutline'
GColor enamel_get_hourOutline(){
	Tuple* tuple = dict_find(&s_dict, 1479342317);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0xFFFFFF);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'hourFill'
GColor enamel_get_hourFill(){
	Tuple* tuple = dict_find(&s_dict, 3280383659);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0xFFFFFF);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'backgroundMinute'
GColor enamel_get_backgroundMinute(){
	Tuple* tuple = dict_find(&s_dict, 1028171876);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0x000000);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'drawMinuteOutline'
bool enamel_get_drawMinuteOutline(){
	Tuple* tuple = dict_find(&s_dict, 4072825378);
	return tuple ? tuple->value->int32 == 1 : false;
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'minuteOutline'
GColor enamel_get_minuteOutline(){
	Tuple* tuple = dict_find(&s_dict, 1426332628);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0x55AAFF);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'minuteFill'
GColor enamel_get_minuteFill(){
	Tuple* tuple = dict_find(&s_dict, 589198429);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0x55AAFF);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'line'
GColor enamel_get_line(){
	Tuple* tuple = dict_find(&s_dict, 2833137020);
	return tuple ? GColorFromHEX(tuple->value->int32) : GColorFromHEX(0xFFFFFF);
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'cutAmount'
int32_t enamel_get_cutAmount(){
	Tuple* tuple = dict_find(&s_dict, 1012542246);
		
	return tuple ? tuple->value->int32 : 0;
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'animation'
bool enamel_get_animation(){
	Tuple* tuple = dict_find(&s_dict, 2321542991);
	return tuple ? tuple->value->int32 == 1 : true;
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'bluetooth'
bool enamel_get_bluetooth(){
	Tuple* tuple = dict_find(&s_dict, 2309848766);
	return tuple ? tuple->value->int32 == 1 : true;
}
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'bluetoothVisual'
bool enamel_get_bluetoothVisual(){
	Tuple* tuple = dict_find(&s_dict, 2498678837);
	return tuple ? tuple->value->int32 == 1 : true;
}
// -----------------------------------------------------


static uint16_t prv_get_inbound_size() {
	return 1
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
		+ 7 + 4
;
}

static uint32_t prv_map_messagekey(const uint32_t key){
	if( key == MESSAGE_KEY_background) return 3202544658;
	if( key == MESSAGE_KEY_drawHourOutline) return 228125679;
	if( key == MESSAGE_KEY_hourOutline) return 1479342317;
	if( key == MESSAGE_KEY_hourFill) return 3280383659;
	if( key == MESSAGE_KEY_backgroundMinute) return 1028171876;
	if( key == MESSAGE_KEY_drawMinuteOutline) return 4072825378;
	if( key == MESSAGE_KEY_minuteOutline) return 1426332628;
	if( key == MESSAGE_KEY_minuteFill) return 589198429;
	if( key == MESSAGE_KEY_line) return 2833137020;
	if( key == MESSAGE_KEY_cutAmount) return 1012542246;
	if( key == MESSAGE_KEY_animation) return 2321542991;
	if( key == MESSAGE_KEY_bluetooth) return 2309848766;
	if( key == MESSAGE_KEY_bluetoothVisual) return 2498678837;
	return 0;
}

static void prv_key_update_cb(const uint32_t key, const Tuple *new_tuple, const Tuple *old_tuple, void *context){
}

static bool prv_each_settings_received(void *this, void *context) {
	SettingsReceivedState *state=(SettingsReceivedState *)this;
	state->handler(state->context);
	return true;
}


static bool prv_is_setting_message(const DictionaryIterator *iter){
	if( dict_find(iter, MESSAGE_KEY_background) ) return true;
	if( dict_find(iter, MESSAGE_KEY_drawHourOutline) ) return true;
	if( dict_find(iter, MESSAGE_KEY_hourOutline) ) return true;
	if( dict_find(iter, MESSAGE_KEY_hourFill) ) return true;
	if( dict_find(iter, MESSAGE_KEY_backgroundMinute) ) return true;
	if( dict_find(iter, MESSAGE_KEY_drawMinuteOutline) ) return true;
	if( dict_find(iter, MESSAGE_KEY_minuteOutline) ) return true;
	if( dict_find(iter, MESSAGE_KEY_minuteFill) ) return true;
	if( dict_find(iter, MESSAGE_KEY_line) ) return true;
	if( dict_find(iter, MESSAGE_KEY_cutAmount) ) return true;
	if( dict_find(iter, MESSAGE_KEY_animation) ) return true;
	if( dict_find(iter, MESSAGE_KEY_bluetooth) ) return true;
	if( dict_find(iter, MESSAGE_KEY_bluetoothVisual) ) return true;
	return false;	
}

static void prv_inbox_received_handle(DictionaryIterator *iter, void *context) {
	if( prv_is_setting_message(iter) ){
		if(s_dict_buffer){
			free(s_dict_buffer);
			s_dict_buffer = NULL;
		}
		s_dict_size = dict_size(iter);
		s_dict_buffer = malloc(s_dict_size);

		Tuple *tuple=dict_read_first(iter);
		while(tuple){
			tuple->key = prv_map_messagekey(tuple->key);
			tuple=dict_read_next(iter);
		}

		dict_write_begin(&s_dict, s_dict_buffer, s_dict_size);
		dict_write_end(&s_dict);
		dict_merge(&s_dict, &s_dict_size, iter, false, prv_key_update_cb, NULL);

		if(s_handler_list){
			linked_list_foreach(s_handler_list, prv_each_settings_received, NULL);
		}

		s_config_changed = true;
	}
}

static uint16_t prv_save_generic_data(uint32_t startkey, const void *data, uint16_t size){
	uint16_t offset = 0;
	uint16_t total_w_bytes = 0;
	uint16_t w_bytes = 0;
	while(offset < size){
		w_bytes = size - offset < PERSIST_DATA_MAX_LENGTH ? size - offset : PERSIST_DATA_MAX_LENGTH;
		w_bytes = persist_write_data(startkey + offset / PERSIST_DATA_MAX_LENGTH, data + offset, w_bytes);
		total_w_bytes += w_bytes;
		offset += PERSIST_DATA_MAX_LENGTH;
	}
	return total_w_bytes; 
}

static uint16_t prv_load_generic_data(uint32_t startkey, void *data, uint16_t size){
	uint16_t offset = 0;
	uint16_t total_r_bytes = 0;
	uint16_t expected_r_bytes = 0;
	uint16_t r_bytes = 0;
	while(offset < size){
		if(size - offset > PERSIST_DATA_MAX_LENGTH){
			expected_r_bytes = PERSIST_DATA_MAX_LENGTH;
		}
		else {
			expected_r_bytes = size - offset;
		}
		r_bytes = persist_read_data(startkey + offset / PERSIST_DATA_MAX_LENGTH, data + offset, expected_r_bytes);
		total_r_bytes += r_bytes;
		if(r_bytes != expected_r_bytes){
			break; 
		}
		offset += PERSIST_DATA_MAX_LENGTH;
	}
	return total_r_bytes;
}

void enamel_init(){
	if(persist_exists(ENAMEL_PKEY) && persist_exists(ENAMEL_DICT_PKEY)) 
	{
		s_dict_size = persist_read_int(ENAMEL_PKEY);
		s_dict_buffer = malloc(s_dict_size);
		prv_load_generic_data(ENAMEL_DICT_PKEY, s_dict_buffer, s_dict_size);
	}
	else {
		s_dict_size = 0;
		s_dict_buffer = NULL;
	}

	dict_read_begin_from_buffer(&s_dict, s_dict_buffer, s_dict_size);
	
	s_config_changed = false;
	s_event_handle = events_app_message_register_inbox_received(prv_inbox_received_handle, NULL);
	events_app_message_request_inbox_size(prv_get_inbound_size());
}

void enamel_deinit(){
	if(s_config_changed){
		persist_write_int(ENAMEL_PKEY, s_dict_size);
		prv_save_generic_data(ENAMEL_DICT_PKEY, s_dict_buffer, s_dict_size);
	}

	if(s_dict_buffer){
		free(s_dict_buffer);
		s_dict_buffer = NULL;
	}

	s_config_changed = false;
	events_app_message_unsubscribe(s_event_handle);
}

EventHandle enamel_settings_received_subscribe(EnamelSettingsReceivedHandler *handler, void *context) {
	if (!s_handler_list) {
		s_handler_list = linked_list_create_root();
	}

	SettingsReceivedState *this = malloc(sizeof(SettingsReceivedState));
	this->handler = handler;
	this->context = context;
	linked_list_append(s_handler_list, this);

	return this;
}

void enamel_settings_received_unsubscribe(EventHandle handle) {
	int16_t index = linked_list_find(s_handler_list, handle);
	if (index == -1) {
		return;
	}

	free(linked_list_get(s_handler_list, index));
	linked_list_remove(s_handler_list, index);
	if (linked_list_count(s_handler_list) == 0) {
		free(s_handler_list);
		s_handler_list = NULL;
	}
}