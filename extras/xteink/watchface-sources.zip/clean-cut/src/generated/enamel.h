/**
 * This file was generated with Enamel : http://gregoiresage.github.io/enamel
 */

#ifndef ENAMEL_H
#define ENAMEL_H

#include <pebble.h>

// -----------------------------------------------------
// Getter for 'background'
GColor enamel_get_background();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'drawHourOutline'
bool enamel_get_drawHourOutline();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'hourOutline'
GColor enamel_get_hourOutline();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'hourFill'
GColor enamel_get_hourFill();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'backgroundMinute'
GColor enamel_get_backgroundMinute();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'drawMinuteOutline'
bool enamel_get_drawMinuteOutline();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'minuteOutline'
GColor enamel_get_minuteOutline();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'minuteFill'
GColor enamel_get_minuteFill();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'line'
GColor enamel_get_line();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'cutAmount'
#define CUTAMOUNT_PRECISION 1
int32_t enamel_get_cutAmount();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'animation'
bool enamel_get_animation();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'bluetooth'
bool enamel_get_bluetooth();
// -----------------------------------------------------

// -----------------------------------------------------
// Getter for 'bluetoothVisual'
bool enamel_get_bluetoothVisual();
// -----------------------------------------------------

void enamel_init();

void enamel_deinit();

typedef void* EventHandle;
typedef void(EnamelSettingsReceivedHandler)(void* context);

EventHandle enamel_settings_received_subscribe(EnamelSettingsReceivedHandler *handler, void *context);
void enamel_settings_received_unsubscribe(EventHandle handle);

#endif