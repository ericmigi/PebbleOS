Pebble.addEventListener('ready',
    function (e) {
        //     console.log('JavaScript app ready and running!');
    }
);

Pebble.addEventListener('showConfiguration', function () {
    var colors = [192, 213, 255];
    function shade(id, label, key, fallback) {
        var saved = localStorage.getItem(key);
        var chosen = saved === null ? fallback : Number(saved);
        var options = colors.map(function (color, i) {
            return '<option value="' + color + '"' + (color === chosen ? ' selected' : '') +
                '>' + ['Black', 'Gray', 'White'][i] + '</option>';
        });
        return '<p><label>' + label + ' <select id="' + id + '">' + options.join('') + '</select></label>';
    }
    function toggle(id, label, key, fallback) {
        var saved = localStorage.getItem(key);
        var checked = saved === null ? fallback : saved === 'true' || saved === '1';
        return '<p><label><input type="checkbox" id="' + id + '"' + (checked ? ' checked' : '') + '> ' + label + '</label>';
    }
    var page = '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Big Shadow</title>' +
        '<style>body{font:18px system-ui;margin:24px}select,button{font:inherit}</style><h1>Big Shadow</h1>' +
        shade('c1', 'Digit face', 'KEY_BASECOLOR', 255) + shade('c2', 'Right shadow', 'KEY_RSHADECOLOR', 213) +
        shade('c3', 'Bottom shadow', 'KEY_BSHADECOLOR', 213) + shade('c4', 'Background', 'KEY_BACKCOLOR', 192) +
        toggle('c5', 'Show status screen', 'KEY_SHOWSTATUS', true) + toggle('c6', 'Vibrate on disconnect', 'KEY_BTVIBRATE', false) +
        '<p><button id="save">Save</button></p><script>document.getElementById("save").onclick=function(){' +
        'var config={};["c1","c2","c3","c4"].forEach(function(k){config[k]=Number(document.getElementById(k).value)});' +
        '["c5","c6"].forEach(function(k){config[k]=Number(document.getElementById(k).checked)});' +
        'location.href="pebblejs://close#"+encodeURIComponent(JSON.stringify(config))};</script>';
    Pebble.openURL('data:text/html;charset=utf-8,' + encodeURIComponent(page));
});

Pebble.addEventListener('webviewclosed',
    function (e) {
        if (!e.response || e.response === "cancel") return;
        var configuration = JSON.parse(decodeURIComponent(e.response));
        //console.log('Configuration window returned: ' + configuration.c1);
        localStorage.setItem("KEY_BASECOLOR", configuration.c1);
        localStorage.setItem("KEY_RSHADECOLOR", configuration.c2);
        localStorage.setItem("KEY_BSHADECOLOR", configuration.c3);
        localStorage.setItem("KEY_BACKCOLOR", configuration.c4);
        localStorage.setItem("KEY_SHOWSTATUS", configuration.c5);
        localStorage.setItem("KEY_BTVIBRATE", configuration.c6);

        //Send to Pebble, persist there
        var dictionary = {
            "KEY_BASECOLOR": configuration.c1,
            "KEY_RSHADECOLOR": configuration.c2,
            "KEY_BSHADECOLOR": configuration.c3,
            "KEY_BACKCOLOR": configuration.c4,
            "KEY_SHOWSTATUS": configuration.c5,
            "KEY_BTVIBRATE": configuration.c6
        };
        console.log(JSON.stringify(dictionary));
        Pebble.sendAppMessage(
            dictionary,
            function (e) {
                console.log("Sending settings data...");
            },
            function (e) {
                console.log("Settings feedback failed!");
            }
        );
    }
);