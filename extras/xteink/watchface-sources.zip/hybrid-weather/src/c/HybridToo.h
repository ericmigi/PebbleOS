#pragma once
#include <pebble.h>

#define SETTINGS_KEY 1225
#define LOGO_TEXT_KEY 1116        // custom texts are stored separately from ClaySettings
#define LOGO_TEXT_RIGHT_KEY 1117

// Longest custom text accepted (characters beyond what fits are clipped on screen)
#ifdef PBL_PLATFORM_APLITE
  #define LOGO_TEXT_MAX 6
#else
  #define LOGO_TEXT_MAX 25
#endif
// Buffer size in bytes: accented letters take 2 bytes in UTF-8
#define LOGO_TEXT_BYTES (LOGO_TEXT_MAX * 2 + 1)

// Dropdown values sent from the config page (as "0", "1", ...)
typedef enum {
  SLOT_STEPS = 0, SLOT_TEXT, SLOT_TEMP, SLOT_BATT_VALUE, SLOT_BATT_ICON, SLOT_NONE,
  SLOT_COUNT
} SlotOption;

enum { TOPROW_DAY_MONTH = 0, TOPROW_MONTH_DAY, TOPROW_NONE };

enum { THEME_WHITE = 0, THEME_BLACK, THEME_BLUE, THEME_PURPLE, THEME_GREEN, THEME_CUSTOM };
enum { BW_THEME_WHITE = 0, BW_THEME_BLACK, BW_THEME_GREY, BW_THEME_CUSTOM };

typedef struct ClaySettings {
  bool EnableSecondsHand;
  int SecondsVisibleTime;
  bool EnableDate;
  bool EnableBatteryLine;
  bool EnableLogo;
  uint8_t VibeMode;   // 0 = respect Quiet Time, 1 = always, 2 = never
  int Font;
  uint8_t BottomLeft;   // bottom-left slot, SlotOption
  GColor BackgroundColor1;
  GColor ShadowColor;
  GColor TextColor1;
  GColor MajorTickColor;
  GColor MinorTickColor;
  GColor HoursHandColor;
  GColor HoursHandBorderColor;
  GColor MinutesHandColor;
  GColor MinutesHandBorderColor;
  GColor SecondsHandColor;
  GColor BatteryLineColor;
  GColor FGColor;
  bool ShadowOn;
  bool RemoveZero24h;
  bool AddZero12h;
  GColor LineColor;
  bool showlocalAMPM;
  bool ShowTime;
  bool EnableLines;
  bool EnableMinorTick;
  bool EnableMajorTick;
  bool ForegroundShape;
  bool UseWeather;
  bool UseUVI;
  bool HealthOn;
  int UpSlider;
 // char WeatherTemp [8];
 // char TempFore [10];
  char moonstring[4];
  char sunsetstring[8];
  char sunrisestring[8];
  char sunsetstring12[8];
  char sunrisestring12[8];
  char tempstring[8];
  char windstring[10];
  char windavestring[10];
  char iconnowstring[4];
  char iconforestring[4];
  char icon1hstring[4];
  char windiconnowstring[4];
  char windiconavestring[4];
  char temphistring[10];
  int WeatherUnit;
  char WindUnit [8];
  //char WeatherProv [4];
  #ifndef PBL_PLATFORM_APLITE
  int rainstring;
  int popstring;
  int rainfore;
  int popmax;
  int popmin;
  int UVIndexMax;
  int UVIndexNow;
  int UVIndexDay;
  char RainUnit [8];
  char PressureUnit [8];
  int pressurenow;
  int pressure1h;
  int barotrend;
  #endif
  int Weathertimecapture;
  GColor UVMaxColor;
  GColor UVNowColor;
  GColor UVArcColor;
  GColor WeatherColor;
  GColor BTQTColor;
  uint8_t BottomRight;         // bottom-right slot, SlotOption
  bool SwapDayMonth;
  char DateLanguage[6];         // "" = match watch, else e.g. "fr_FR"
  bool ShakeWeather;
} __attribute__((__packed__)) ClaySettings;

_Static_assert(sizeof(ClaySettings) <= 256, "ClaySettings exceeds Pebble 256-byte persist limit!");