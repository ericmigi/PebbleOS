#pragma once

#include <pebble.h>

// Persistent storage for the user's uploaded background images.
//
// There are BG_IMG_SLOTS (9) slots, mirroring the nine user slots on the
// settings page. Each image is transferred ONCE and then lives in persistent
// storage, so switching between them (or applying a "My style" that uses one)
// is instant -- nothing is re-sent unless the image itself changed.
//
// The phone converts the picture to 64 colours (2 bits per channel), packs
// it 4 pixels -> 3 bytes (row-major, 6 bits per pixel: 0bRRGGBB) and streams
// it over AppMessage. Every persist value holds BG_IMG_CHUNK_BYTES of that
// stream (85 groups = 340 pixels, under the 256-byte persist value limit).
// The packed data is never held in RAM: chunks are written straight to
// storage as they arrive and decoded straight into the background cache
// bitmap (bg_image_cache.c) when it is built.
//
// Slot numbers are 1-based everywhere (1..BG_IMG_SLOTS).
//
// One more slot, BG_IMG_PLUGIN_SLOT, holds the picture of the PLUGIN background
// style. It travels with the very same messages but lives in RAM only: it is never
// written to persistent storage, so it is gone whenever the watchface restarts
// (the phone notices from the stamp, 0, that we report, and sends it again), and it
// may be any size up to the screen -- the phone has already applied fit, colour
// and dither settings, so the watch just draws what it is given, centred.
// It is allocated when a transfer starts and freed when the slot is emptied.
// Optionally (BEGIN flag, the "cache picture" setting) the plugin picture is instead written to
// persistent storage like a user slot: then it survives restarts, the stamp reported after one is
// that of the cached picture, and the phone only sends a picture that actually changed. A cached
// picture needs no RAM at all while it is drawn.

#define BG_IMG_SLOTS 9
#define BG_IMG_PLUGIN_SLOT (BG_IMG_SLOTS + 1)
// Stamps reported to the phone: the persistent slots, then the plugin slot.
#define BG_IMG_REPORTED_SLOTS (BG_IMG_SLOTS + 1)
#define BG_IMG_CHUNK_BYTES 255
#define BG_IMG_MAX_PIXELS (320 * 320)

#ifdef PBL_BW
// B&W watches: no stored pictures (compiled out, see bg_image_store.c).
static inline uint32_t bg_image_store_stamp(uint8_t slot) { (void)slot; return 0; }
static inline void bg_image_store_stamps(uint32_t out[BG_IMG_REPORTED_SLOTS]) { for (int i = 0; i < BG_IMG_REPORTED_SLOTS; i++) out[i] = 0; }
static inline void bg_image_store_set_memory_relief(void (*relief)(void)) { (void)relief; }
static inline bool bg_image_store_ram_failed(void) { return false; }
#else
// Stamp (content hash chosen by the phone) of the complete image in `slot`,
// or 0 when the slot is empty -- including while a transfer into it is half done.
uint32_t bg_image_store_stamp(uint8_t slot);

// Fills out[0..BG_IMG_REPORTED_SLOTS-1] with the stamp of slots 1..10 (0 = empty).
void bg_image_store_stamps(uint32_t out[BG_IMG_REPORTED_SLOTS]);

// Called (if set) when the plugin slot cannot be allocated for lack of free heap,
// so the app can give back memory it can rebuild (the dial cache). The allocation
// is then tried once more.
void bg_image_store_set_memory_relief(void (*relief)(void));

// True if the last transfer into the plugin slot failed for lack of memory (cleared
// by the next successful transfer or by emptying the slot). Lets the dial report it.
bool bg_image_store_ram_failed(void);

// Starts a transfer into `slot`: invalidates that slot's current image and
// records what is coming. Other slots are untouched.
// `persist` only matters for the plugin slot (cache it in persistent storage instead of RAM).
bool bg_image_store_begin(uint8_t slot, uint32_t stamp, uint16_t chunks, uint16_t w, uint16_t h, bool persist);

// Stores `len` bytes of the stream beginning at persist chunk `first_chunk`
// of the slot being transferred. Returns false if no transfer is active.
bool bg_image_store_write(uint16_t first_chunk, const uint8_t *data, uint16_t len);

// Ends the transfer. Verifies every chunk is present, then makes the image
// current. Returns false (and leaves the slot empty) if anything is missing.
bool bg_image_store_commit(uint32_t stamp);

// Empties `slot` (the image was removed on the phone); the plugin slot's memory is freed.
void bg_image_store_clear(uint8_t slot);

// Slot currently being received (1-based), or 0 when no transfer is active.
uint8_t bg_image_store_pending_slot(void);

// Number of chunks written so far in the active transfer (highest index + 1).
uint16_t bg_image_store_pending_progress(void);

// Total chunks of the active transfer, or 0.
uint16_t bg_image_store_pending_chunks(void);

// Abandons the active transfer (the slot stays empty; a half-received plugin picture is freed).
void bg_image_store_abort(void);

// Decodes the image in `slot` straight into the frame buffer, centred in
// `bounds` (layer coordinates; `origin` is the layer's position on screen).
// Nothing is allocated: pixels go from persistent storage (or, for the plugin
// slot, from its RAM copy) to the screen in 255-byte pieces. Returns false if the slot has no (readable) image.
bool bg_image_store_draw(uint8_t slot, GContext *ctx, GRect bounds, GPoint origin);

#endif // PBL_BW
