#pragma once

#include <pebble.h>
#include "../../data/watch_data.h"
#include "../../data/marker_types.h"
#include "../../fonts/font_lookup.h"

// Renders configured numeric/Roman marker labels. Font resource lifetime
// remains owned by MarkerLayerState; this module only consumes the slot.
void marker_text_draw(GContext *ctx, GPoint center, GRect screen, FontSlot *font_slot,
                      const MarkerTextConfig *text_cfg, const MarkerRingConfig *hour_cfg,
                      const MarkerRingConfig *second_cfg, GColor color,
                      bool draw_debug);
