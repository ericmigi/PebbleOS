#include <pebble.h>
#include "../data/watch_data.h"
#include "../data/watch_defaults.h"
#include "../comms/comms.h"
#include "../persistence/persistence.h"
#include "../power/battery_saver.h"
#include "../power/battery_saver_controller.h"
#include "../input/input.h"
#include "../timing/time_service.h"
#include "../rendering/dial/dial_layer.h"
#include "../rendering/dial/dial_animation.h"
#include "../rendering/status/status_label.h"
#include "../features/feature_controller.h"
#include "../features/features_layer.h"
#include "../features/primitives/startup_flip.h"
#include "../features/feature_icons.h"
#include "../features/primitives/primitive_ids.h"
#include "../hands/hands_controller.h"
#include "../timing/hourly_vibration.h"
#include "../timing/beep.h"
#include "./layout_controller.h"
#include "./watchface_ui.h"
#include "../timing/feature_refresh.h"

static Window *s_window;
static void hands_controller_invalidate(void *context) {
  (void)context;
  Layer *hands_layer = layout_controller_hands_layer();
  if (hands_layer) layer_mark_dirty(hands_layer);
}

static WatchData s_data;

// ---- phone connection -------------------------------------------------------
// The Bluetooth features read the connection state when they are drawn, but
// nothing redraws them when it changes -- so refresh them here, and give the
// optional "connection lost" vibration. While the phone is away the Bluetooth
// icon flashes (visible one second, hidden the next).
#define BT_FLASH_DURATION_S 60
static AppTimer *s_bt_flash_timer = NULL;
static bool s_bt_flash_hidden = false;
static bool s_bt_flash_done = false;   // the minute is over: icon stays steady until the next disconnect
static time_t s_bt_flash_start = 0;    // when the current disconnect began (or the app started disconnected)

static void bt_flash_apply(bool hidden) {
  if (s_bt_flash_hidden == hidden) return;
  s_bt_flash_hidden = hidden;
  feature_icons_set_bt_flash_hidden(hidden);
  Layer *features = layout_controller_features_layer();
  if (features) features_layer_refresh_primitive(features, PRIM_BLUETOOTH_ICON);
}

static bool bt_flash_wanted(void) {
  return !connection_service_peek_pebble_app_connection() &&
         feature_controller_primitive_in_use(&s_data, PRIM_BLUETOOTH_ICON);
}

static void bt_flash_tick(void *context) {
  (void)context;
  s_bt_flash_timer = NULL;
  if (!bt_flash_wanted()) { bt_flash_apply(false); return; }
  if (time(NULL) - s_bt_flash_start >= BT_FLASH_DURATION_S) {
    s_bt_flash_done = true; // flashed for a minute: become static (visible)
    bt_flash_apply(false);
    return;
  }
  uint32_t next_ms = 1000;
  if (battery_saver_phase() == BATTERY_SAVER_AWAKE) {
    bt_flash_apply(!s_bt_flash_hidden);
  } else {
    bt_flash_apply(false); // resting: keep the icon steady and poll slowly
    next_ms = 10000;
  }
  s_bt_flash_timer = app_timer_register(next_ms, bt_flash_tick, NULL);
}

// Starts or stops the flashing to match the connection state and the features in use.
static void bt_flash_update(void) {
  if (bt_flash_wanted() && !s_bt_flash_done) {
    if (!s_bt_flash_timer) s_bt_flash_timer = app_timer_register(1000, bt_flash_tick, NULL);
  } else {
    if (s_bt_flash_timer) { app_timer_cancel(s_bt_flash_timer); s_bt_flash_timer = NULL; }
    bt_flash_apply(false);
  }
}

static void app_connection_handler(bool connected) {
  Layer *features = layout_controller_features_layer();
  if (features) features_layer_refresh_values(features);
  // A new disconnect starts a fresh minute of flashing; reconnecting clears it.
  s_bt_flash_done = false;
  s_bt_flash_start = time(NULL);
  bt_flash_update();
  if (!connected) {
    switch (s_data.bt_lost_vibe) {
      case 1: vibes_short_pulse(); break;
      case 2: vibes_double_pulse(); break;
      case 3: vibes_long_pulse(); break;
      default: break;
    }
    beep_play(s_data.bt_lost_beep, s_data.beep_volume);
  }
}

// Tick subscription policy lives in time_service.c; this callback owns visual work.
// ---- tick + click ---------------------------------------------------------

static void time_service_tick_handler(struct tm *tick_time, TimeUnits units_changed, void *context) {
  (void)context;

  if (units_changed & MINUTE_UNIT) hourly_vibration_handle_minute(tick_time);

  battery_saver_controller_update();

  // Scheduled "My styles": the watch is the only clock that is reliably
  // running, so it is the one that wakes PKJS when a style is due. Runs
  // before the deep-sleep skip below so it is evaluated every minute.
  comms_maybe_request_scheduled_style(&s_data);

  // Deep sleep uses MINUTE_UNIT; process only five-minute boundaries.
  bool deep_sleep_skip = (battery_saver_phase() == BATTERY_SAVER_DEEP_SLEEP) && (tick_time->tm_min % 5 != 0);
  if (!deep_sleep_skip) {
    watchface_ui_refresh_status();
    if (battery_saver_phase() != BATTERY_SAVER_AWAKE && layout_controller_features_layer()) {
      features_layer_refresh_values(layout_controller_features_layer());
    }
  }

  // Seconds-precision feature slots use SECOND_UNIT.
  if (time_service_is_seconds() && layout_controller_features_layer()) {
    features_layer_refresh_second_slots(layout_controller_features_layer());
  }

  // Re-evaluate whether second-precision ticks are still needed.
  time_service_update();
}


// ---- window lifecycle ----------------------------------------------------

// Keep the watchface composition synchronized with Pebble OS system overlays.
// The change callback tracks the obstruction animation, while the final
// callback forces one last layout pass. Some firmware/system overlays can
// finish their transition without the last useful change frame reaching the
// app, so relying on .change alone can leave the face in its pre-obstruction
// layout until the next full app/layout initialization.
static void unobstructed_change_handler(AnimationProgress progress, void *context) {
  (void)context;
  layout_controller_handle_unobstructed(progress);
}

static void unobstructed_did_change_handler(void *context) {
  (void)context;
  // Re-read layer_get_unobstructed_bounds() after the system has committed
  // the final obstruction state. This also corrects any rounding/frame
  // differences left by the animated .change callbacks.
  layout_controller_handle_unobstructed(0);
}

static UnobstructedAreaHandlers s_unobstructed_handlers = {
  .change = unobstructed_change_handler,
  .did_change = unobstructed_did_change_handler
};

static void window_load(Window *window) {
  Layer *root = window_get_root_layer(window);
  GRect bounds = layer_get_bounds(root);

  // Create the status label once; layout changes re-parent it as needed.
  status_label_create(root, GRect(0, 0, bounds.size.w, 20));

  layout_controller_apply();

  watchface_ui_refresh_status();
  hands_controller_start_startup_animation();
  dial_animation_start(&s_data, layout_controller_dial_layer());
  startup_flip_start(&s_data, layout_controller_features_layer());
}

static void window_unload(Window *window) {
  startup_flip_deinit();
  status_label_destroy();
  layout_controller_unload();
  feature_controller_unload_fonts();
}

static void comms_data_applied(CommsChangeFlags changes, void *context) {
  (void)context;

  if (changes == COMMS_CHANGE_BG_PROGRESS) {
    Layer *progress = layout_controller_bg_progress_layer();
    if (progress) layer_mark_dirty(progress);
    return;
  }

  if (changes & COMMS_CHANGE_LAYOUT) layout_controller_apply();
  if (layout_controller_dial_layer()) dial_layer_set_data(layout_controller_dial_layer(), &s_data);
  // The user applied an indices style in the settings: build the drawn indices up like the launch animation does.
  static uint32_t s_last_apply_tick;
  static bool s_have_apply_tick;
  if (s_have_apply_tick && s_data.marker_apply_tick != s_last_apply_tick && layout_controller_dial_layer()) {
    dial_animation_replay(&s_data, layout_controller_dial_layer());
  }
  s_last_apply_tick = s_data.marker_apply_tick;
  s_have_apply_tick = true;
  if (layout_controller_bg_progress_layer()) layer_mark_dirty(layout_controller_bg_progress_layer());
  if (layout_controller_hands_layer()) layer_mark_dirty(layout_controller_hands_layer());
  if (layout_controller_features_layer() && (changes & COMMS_CHANGE_FEATURES)) {
    features_layer_set_data(layout_controller_features_layer(), &s_data);
  }

  bt_flash_update(); // the Bluetooth feature may have been added or removed

  // Apply early settings, but defer tick-policy changes until valid data exists.
  if (!s_data.valid) {
    persistence_save(&s_data);
    watchface_ui_refresh_status();
    return;
  }

  battery_saver_controller_apply_enabled(s_data.battery_saver_enabled);
  time_service_update();
  persistence_save(&s_data);
  watchface_ui_refresh_status();
}

void app_controller_init(void) {
  // The MESSAGE_KEY_MESSAGE_TYPE + MK_* assumption the decoder relies on
  // is verified where it can be checked for free: at generation
  // time, in scripts/generate-message-keys.js.
  //
  // Stored settings win; a watch that has never been configured (or whose
  // stored layout is from another version) starts from the built-in
  // defaults -- the Modern dial -- before the phone has sent anything.
  if (!persistence_load(&s_data)) watch_defaults_apply(&s_data);
  battery_saver_controller_init(&s_data);

  // Initialize time service before pushing the window; window_load() may run synchronously.
  time_service_init(&s_data, time_service_tick_handler, NULL);
  hands_controller_init(&s_data, hands_controller_invalidate, NULL);
  status_label_init(&s_data);
  hourly_vibration_init(&s_data, hands_controller_invalidate, NULL);

  s_window = window_create();
  window_set_window_handlers(s_window, (WindowHandlers){
    .load = window_load,
    .unload = window_unload,
  });
  layout_controller_init(&s_data, s_window);
  watchface_ui_init(&s_data);

  // Subscribe before the window enters the stack so an obstruction that is
  // already active (or begins during the push/load transition) cannot be
  // missed by the UnobstructedArea service.
  unobstructed_area_service_subscribe(s_unobstructed_handlers, NULL);
  window_stack_push(s_window, true);

  input_init(&s_data, *watchface_ui_input_callbacks(), NULL);
  feature_refresh_init();
  feature_refresh_start();

  comms_init(&s_data, comms_data_applied, NULL);
  connection_service_subscribe((ConnectionHandlers){ .pebble_app_connection_handler = app_connection_handler });
  s_bt_flash_start = time(NULL); // started while already disconnected: flash for the first minute
  bt_flash_update();
  battery_saver_controller_update();
}

void app_controller_deinit(void) {
  connection_service_unsubscribe();
  if (s_bt_flash_timer) { app_timer_cancel(s_bt_flash_timer); s_bt_flash_timer = NULL; }
  battery_saver_controller_deinit();
  time_service_deinit();
  input_deinit();
  watchface_ui_deinit();
  unobstructed_area_service_unsubscribe();
  feature_refresh_deinit();
  comms_deinit();
  dial_animation_deinit();
  hands_controller_deinit();
  hourly_vibration_deinit();
  status_label_deinit();
  layout_controller_deinit();
  window_destroy(s_window);
}
