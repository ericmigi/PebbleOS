#pragma once

#include <pebble.h>
#include "./feature_slot.h"

// Shared feature rendering primitives.  This module owns the pixel-level

GColor feature_render_contrasting_outline_color(GColor c);

void feature_render_draw_text_outlined(GContext *ctx, const char *text, GFont font, GRect box,
                                       GTextOverflowMode overflow, GTextAlignment alignment,
                                       GColor color, uint8_t outline_style);

// Separate outline and content passes used by the primitive renderer.
void feature_render_draw_text_outline_only(GContext *ctx, const char *text, GFont font, GRect box,
                                           GTextOverflowMode overflow, GTextAlignment alignment,
                                           GColor color, uint8_t outline_style);
void feature_render_draw_text_content_only(GContext *ctx, const char *text, GFont font, GRect box,
                                           GTextOverflowMode overflow, GTextAlignment alignment,
                                           GColor color);


void feature_render_draw_slot(GContext *ctx, GRect bounds, const FeatureSlot *slot, IconAnim *icon_anims,
                              GFont font, int16_t font_h, int16_t font_offset,
                              uint8_t outline_style, uint8_t icon_style,
                              bool draw_debug);
