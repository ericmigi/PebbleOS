var appinfo = {
  "uuid": "34624378-9ddd-44d0-a3be-80adcf8c045b",
  "shortName": "4pop",
  "longName": "4pop",
  "companyName": "frogamic",
  "versionLabel": "1.0",
  "sdkVersion": "3",
  "targetPlatforms": ["basalt"],
  "capabilities": ["configurable"],
  "watchapp": {
    "watchface": true
  },
  "appKeys": {
      "tlb": 0,
      "trb": 1,
      "blb": 2,
      "brb": 3,
      "tld": 4,
      "trd": 5,
      "bld": 6,
      "brd": 7,
      "tlh": 8,
      "trh": 9,
      "blh": 10,
      "brh": 11,
      "vibe": 12
  },
  "resources": {
    "media": []
  }
}
;

function pcolor_from_hex(hex) {
    hex = hex.toLowerCase();
    hex = hex.replace(/0/g, "00").replace(/5/g, "01").replace(/a/g, "10").replace(/f/g, "11").replace("#", "11");
    return parseInt(hex, 2);
}

function replace_colors(config) {
    for (var key in config) {
        if (typeof config[key] === "string") {
            if (config[key] === "bluetooth")
                config[key] = 0;
            else if (config[key] === "battery")
                config[key] = 1;
            else
                config[key] = pcolor_from_hex(config[key]);
        }
    }
}

Pebble.addEventListener('showConfiguration', function () {
    Pebble.openURL('data:text/html;charset=utf-8,' + encodeURIComponent("<html><head>\n        <title>4pop settings page</title>\n        <style type=\"text/css\">\n            #colorpicker {\n                position: fixed;\n                width: 100%;\n                height: 100%;\n                top: 0;\n                left: 0;\n                overflow: scroll;\n            }\n            .extitem {\n                width: 50vw;\n                display: inline-block;\n                text-align: center;\n                color: White;\n                text-shadow:\n                    -1px -1px 0 Black,  \n                    1px -1px 0 Black,\n                    -1px 1px 0 Black,\n                    1px 1px 0 Black;\n            }\n            #cc {\n                width:100vw;\n                display: inline-block;\n                text-align: center;\n                background: White;\n            }\n            #bluetooth {\n                background: linear-gradient(to right, #005, #a00);\n            }\n            #battery {\n                background: linear-gradient(to right, #f00, #fa0, #0f0);\n            }\n            .coloritem {\n                width: 25vw;\n                height: 25vw;\n                display: inline-block;\n            }\n            button {\n                width: 45%;\n                height: 50;\n            }\n            body {\n                text-align: center;\n            }\n        </style>\n        <script>\n            var nColors = 64;\n            var nExt = 2;\n            var colors = [\"bluetooth\", \"battery\", \"#000\", \"#005\", \"#00a\", \"#00f\", \"#050\", \"#055\", \"#05a\", \"#05f\", \"#0a0\", \"#0a5\", \"#0aa\", \"#0af\", \"#0f0\", \"#0f5\", \"#0fa\", \"#0ff\", \"#500\", \"#505\", \"#50a\", \"#50f\", \"#550\", \"#555\", \"#55a\", \"#55f\", \"#5a0\", \"#5a5\", \"#5aa\", \"#5af\", \"#5f0\", \"#5f5\", \"#5fa\", \"#5ff\", \"#a00\", \"#a05\", \"#a0a\", \"#a0f\", \"#a50\", \"#a55\", \"#a5a\", \"#a5f\", \"#aa0\", \"#aa5\", \"#aaa\", \"#aaf\", \"#af0\", \"#af5\", \"#afa\", \"#aff\", \"#f00\", \"#f05\", \"#f0a\", \"#f0f\", \"#f50\", \"#f55\", \"#f5a\", \"#f5f\", \"#fa0\", \"#fa5\", \"#faa\", \"#faf\", \"#ff0\", \"#ff5\", \"#ffa\", \"#fff\"];\n            var settings = {'tlb':'#00f','trb':'#f0f','blb':'#fa0','brb':'bluetooth','tld':'#f50','trd':'#ff0','bld':'#f00','brd':'battery','tlh':'#fff','trh':'#fff','blh':'#fff','brh':'#fff','vibe':1};\n            var chosenColor;\n            var extitems = [];\n            var colorpicker = document.createElement(\"div\");\n            colorpicker.id = 'colorpicker';\n            colorpicker.style.display = 'none';\n            for (var i = 0; i < nColors + nExt; i++)\n            {\n                var colorbox = document.createElement(\"div\");\n                colorbox.style.background = colors[i];\n                colorbox.id = colors[i].replace(\"#\", \"c_\");\n                if (i < nExt){\n                    extitems.push(colorbox);\n                    colorbox.setAttribute(\"class\", \"extitem\");\n                    colorbox.innerHTML=\"<h3>\"+colors[i]+\"</h3>\";\n                } else {\n                    colorbox.style.background = colors[i];\n                    colorbox.setAttribute(\"class\", \"coloritem\");\n                }\n                colorbox.onclick = select_color;\n                colorpicker.appendChild(colorbox);\n            }\n            var cancel = document.createElement(\"div\");\n            cancel.id = \"cc\";\n            cancel.innerHTML=\"<h3>Cancel</h3>\";\n            cancel.onclick = select_color;\n            colorpicker.appendChild(cancel);\n            function hide_extitems() {\n                extitems[0].style.display=\"none\";\n                extitems[1].style.display=\"none\";\n            }\n            function show_extitems() {\n                extitems[0].style.display=\"inline-block\";\n                extitems[1].style.display=\"inline-block\";\n            }\n            function show_popup() {\n                if (this.id.charAt(2) === 'h')\n                    hide_extitems();\n                else\n                    show_extitems();\n                chosenColor = this.id;\n                colorpicker.style.display = 'block';\n            }\n            function send_settings() {\n                settings.vibe = document.getElementById(\"vibe\").checked;\n                for (var key in settings) {\n                    window.localStorage.setItem(\"config_4pop_\"+key, settings[key]);\n                }\n                document.location = \"pebblejs://close#\" + encodeURIComponent(JSON.stringify(settings));\n            }\n            function select_color() {\n                if (this.id !== \"cc\") {\n                    settings[chosenColor] = this.id.replace(\"c_\", \"#\");\n                    var canvas = document.getElementById(chosenColor);\n                    canvas.c = settings[chosenColor];\n                    draw_canvas(canvas);\n                }\n                colorpicker.style.display = 'none';\n            }\n            function draw_canvas(canvas) {\n                var ctx = canvas.getContext(\"2d\");\n                var cy = canvas.height * (canvas.id.charAt(0) == 't' ? .25 : .75);\n                var cx = canvas.width * (canvas.id.charAt(1) == 'l' ? .25 : .75);\n                ctx.fillStyle = \"DimGray\";\n                ctx.fillRect(0, 0, canvas.width, canvas.height);\n                ctx.lineWidth = 1;\n                ctx.strokeStyle = \"Black\";\n                ctx.beginPath();\n                ctx.moveTo(0, canvas.height/2);\n                ctx.lineTo(canvas.width, canvas.height/2);\n                ctx.moveTo(canvas.width/2, 0);\n                ctx.lineTo(canvas.width/2, canvas.height);\n                ctx.stroke();\n                ctx.lineCap = ctx.lineJoin = \"round\";\n                var b = 1;\n                var c = [canvas.c];\n                if(canvas.c === \"battery\") {\n                    b = 3;\n                    c = [\"#f00\", \"#fa0\", \"#0f0\"];\n                } else if(canvas.c === \"bluetooth\") {\n                    b = 2;\n                    c = [\"#005\", \"#a00\"];\n                }\n                switch (canvas.id.charAt(2)){\n                    case 'b':\n                        var y = cy - canvas.height/4;\n                        var h = canvas.height/2;\n                        var x = cx - canvas.width/4;\n                        var w = canvas.width/2;\n                        for (var i = 0; i < b; i++) {\n                            ctx.fillStyle = c[i];\n                            ctx.fillRect(x + i * w/b , y, w/b, h);\n                        }\n                    break;\n                    case 'd':\n                        ctx.shadowBlur = 0;\n                        ctx.shadowOffsetY = 2;\n                        ctx.shadowOffsetX = -2;\n                        ctx.shadowColor=\"black\";\n                        ctx.lineWidth = canvas.width / 20;\n                        for (var i = 0; i < b; i++) {\n                            ctx.beginPath();\n                            ctx.strokeStyle=c[i];\n                            ctx.arc(cx, cy, canvas.width / 5, i*(2*Math.PI/b), (i+1)*(2*Math.PI/b));\n                            ctx.stroke();\n                        }\n                    break;\n                    case 'h':\n                        ctx.strokeStyle = canvas.c;\n                        ctx.shadowBlur = 0;\n                        ctx.shadowOffsetY = 2;\n                        ctx.shadowOffsetX = 2;\n                        ctx.shadowColor=\"black\";\n                        ctx.lineWidth = canvas.width / 30;\n                        ctx.beginPath();\n                        ctx.moveTo(cx - canvas.width / 10, cy - canvas.width / 8);\n                        ctx.lineTo(cx, cy);\n                        ctx.lineTo(cx + canvas.width / 5, cy - canvas.width / 18);\n                        ctx.stroke();\n                }\n            }\n            window.onload = function() {\n                for (var key in settings) {\n                    var val = window.localStorage.getItem(\"config_4pop_\"+key);\n                    if (val) {\n                        settings[key] = val;\n                    }\n                }\n                document.body.appendChild(colorpicker);\n                for (var id in settings) {\n                    var i = document.getElementById(id);\n                    if (id === \"vibe\") {\n                        i.checked = settings[id];\n                    }else{\n                        i.c = settings[id];\n                        i.width = window.innerWidth * .3;\n                        i.height = window.innerWidth * .35;\n                        i.onclick = show_popup;\n                        draw_canvas(i);\n                    }\n                }\n                var ver = document.createElement('p');\n                ver.innerHTML = \"4pop version \" + \"1.0\";\n                document.body.appendChild(ver);\n            };\n        </script>\n    </head>\n    <body>\n        <p>\n            <canvas id=\"tlb\"></canvas>\n            <canvas id=\"tld\"></canvas>\n            <canvas id=\"tlh\"></canvas>\n        </p>\n        <p>\n            <canvas id=\"trb\"></canvas>\n            <canvas id=\"trd\"></canvas>\n            <canvas id=\"trh\"></canvas>\n        </p>\n        <p>\n            <canvas id=\"blb\"></canvas>\n            <canvas id=\"bld\"></canvas>\n            <canvas id=\"blh\"></canvas>\n        </p>\n        <p>\n            <canvas id=\"brb\"></canvas>\n            <canvas id=\"brd\"></canvas>\n            <canvas id=\"brh\"></canvas>\n        </p>\n        <p>\n            <input type=\"checkbox\" id=\"vibe\">Vibrate on bluetooth disconnect</input>\n        </p>\n        <p>\n            <button type=\"submit\" onclick=\"send_settings();\">Save</button>\n            <button type=\"cancel\" onclick=\"document.location = 'pebblejs://close#cancel'\">Cancel</button>\n        </p>\n    </body>\n</html>\n"));
});

Pebble.addEventListener('webviewclosed', function(e) {
    if (e.response !== "cancel") {
        var config = JSON.parse(decodeURIComponent(e.response));
        config.vibe = (config.vibe) ? 1 : 0;
        window.localStorage.setItem("config_4pop", e.response);
        replace_colors(config);
        Pebble.sendAppMessage(config);
    }
});

